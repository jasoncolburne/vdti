# vdti — area note: Multi-party documents (collaborative, evolving, membership-governed)

**Status: SECOND CUT — crystallized with Jason 2026-07-03; dual-pass returned 2026-07-04 (warm HOLD-4 /
cold HOLD-with-findings — no BLOCKERs, the model verifies) and the findings are FOLDED here.** A **feature** over the SAD + SEL primitives: a
document several parties co-author, whose **membership and sharing evolve under a creator**, fully
end-verifiable — decentralized Google-Docs-with-sharing. **No new primitive.** **Supersedes the
first cut** (immutable `authors[]` + a per-author V0-content leg + folds + anchored-set attribution —
all retired); the review-hardened insights (claimed-vs-consent crediting, the size caps, the
residuals, the T1/T2 posture) **carry, re-homed**. The three prior review rounds reviewed the _first
cut_ — **this cut's fresh dual-pass is folded (2026-07-04).** Lands at
`docs/design/features/multi-party/documents.md`.
**Invariants:** [inv 4] manifest roles / the `Kil` topic→slot total rule / anchor-monotonicity,
[inv 5] as-of = the anchoring position, [inv 8] the multi-source freshness bar (loss-of-trust reads),
[inv 10] negative-check-as-lookup, [inv 12] IEL self-pricing (grant tier), [inv 13] rescission `bound`
/ grandfather boundary / deadness-descends, [inv 15] inception + attribution, [inv 16] addressing by
prefix + the custody `owner`+`topic`+SEL-anchor note (2026-07-03). Feature-layer precedent:
`document-policy §F` (the to-tip freshness step is mandatory for any trust-granting acceptance).

## Sources

- This session's design conversation (the collapse onto attributed SADs; membership-as-access-list;
  the backdate resolution via a member-IEL honored window; period-scoped re-add).
- The first-cut model + its three review rounds — `archived/vdti-multi-party-review-*`,
  `archived/vdti-document-authorship-thoughts-*`. Those reviewed the retired V0-leg model; the
  surviving insights are carried below, re-homed. The obsolete findings (V0-leg, folds, anchored-set)
  do not.
- Grounded in the landed SAD layer (`sad/{sad,custody,said,compaction}.md`), the SEL primitive
  (event-shape / area-sel), the delegation `bound` (delegation §5 / inv 13).

## The model in one paragraph

A multi-party document is **a DAG of _attributed_ SADs (versions), authored by members whose
membership is a _creator-governed, per-period access list_.** Each version is a primitive attributed
SAD — `custody { owner, topic, readPolicy }`, owner-rooted by its own
`derive(owner, DOC_TOPIC, version_said)` SEL exactly like any bare SAD, so authorship is **provable
and non-repudiable** (only the member's `t_use` produces it). **Membership is not delegation** — a
member acts as _itself_, never with the creator's authority — it is an **access list** the creator
maintains on a doc-governance SEL: a **grant** opens a validity _period_ on the member's own IEL
(`from` = the member's IEL tip at grant), and a **rescission** — a period-scoped lookup-SEL carrying
a `bound` on the member's IEL — closes it. A version by member X (anchored at X-IEL position `V_x`) is
**honored iff `V_x` falls in some open period on X's own IEL** — `F ≤ V_x`, and `V_x ≤ B` when the
period is closed at a rescission bound `B` (else unbounded above) — an **intra-chain, append-only,
clock-free** test, so a removed or compromised member **cannot backdate** into an old membership
state. Because rescissions are keyed **per-period** by `derive(creator, DOC_RSC_TOPIC, hash(G | said_b))`
— `G` the grant-doc's canonical SAID, `said_b` the nonce'd member-entry SAID — and **never** the member
prefix, a removed member **can be re-added** (a fresh grant → a new period) and the key is
**member-blind AND grant-blind** (§5). Freeze = the creator
bounds every member **and** `Dec`s the governance SEL (structural, hard — §1). The feature is a
**verification layer** over primitives: primitive-verify each version, then check period-membership
(with the loss-of-trust freshness bar, inv 8) + DAG placement + read-invariance.

## 1. The construct

- **V0 → the doc prefix (the constitution + the doc's identity).** V0 is the genesis SAD (the DAG
  root), and — like a chain inception — it **derives a doc `prefix`** (nonce'd → unguessable for a
  private doc). **The doc is a DAG feature identified by that prefix, not a chain**; everything
  references the **doc prefix**, and event SAIDs are **uncorrelatable** to it (the prefix ≠ said
  discipline, `said.md` — the correlation a shared KERI-style identifier does not avoid). V0 carries:
  - **`creator`** — the creator IEL **prefix** [inv 7]: governs membership + sharing (may be
    multi-device/threshold; multi-admin is §7).
  - **the reserved topics** — a holder derives the governance chains from the **doc prefix**: the
    governance SEL `derive(creator, DOC_GOV_TOPIC, doc_prefix)`, per-period rescissions
    `derive(creator, DOC_RSC_TOPIC, {doc_prefix, grant_said})`.
  - **`readPolicy₀`** — the initial read/sharing gate (custody; evolution §5).
  - **`nonce`** — high-entropy so the doc prefix (hence the governance / version chains) is unguessable
    for a **private** doc; a public doc may omit it.
  - V0 is **anonymous-write** (the shared constitution; no `owner`), so its legitimacy is
    social/out-of-band — a competing V0′ is always mintable (§4).
- **Membership is hard-capped.** A verifier rejects a doc whose **live** membership exceeds
  `MAX_MEMBERS` (small — Jason 2026-07-03: 64 is an upper bound, likely smaller). **What it actually
  bounds (warm F11 / cold N4):** the live set and per-step grant width — **not** the governance-SEL
  length (periods + sharing changes accumulate over the doc's life; that walk rides ordinary SEL
  machinery — folds, pages, `resume`), nor the per-member period count (re-adds accumulate; each
  candidate period is one O(1) rescission lookup — practically small, structurally uncapped; a
  periods-per-member cap is a §7 option). The honest bound elsewhere is cost-symmetry: every
  grant/rescission grows the creator's own chains.
- **Member names live in gated content, never in public structure (the core privacy discipline).** A
  SEL's structural fields (`owner` / `data` / manifest-role values) are witnessed → **public**, so a
  member prefix in any of them leaks. Every member reference is therefore a **readPolicy-gated content
  SAD** named by an **opaque SAID** from the event's `manifest`; the public chain carries only the
  opaque commitment (the inv-16 private-data pattern).
- **Governance SEL — the creator's access-list + sharing log.**
  `derive(creator, DOC_GOV_TOPIC, doc_prefix)`, owner = creator, `Icp` data = doc_prefix. Records:
  - **grants** — a grant `Ixn` whose `manifest` names a **gated grant-doc** `G`, submitted as
    **compacted chunks** (top level all canonical SAIDs — the canonical/fully-compacted form is the one
    everyone commits to, always re-derivable by compacting down; `project_vdti_compacted_only_submission`):
    `G = { said, custody, roster: { said, add: [said_a, said_b, …] } }`, each member entry a nested SAD
    `{ said, nonce, prefix }`. The **`nonce` (high-entropy) makes the member-entry SAID `said_b`
    unguessable** on public structure — a member-blind commitment (the area-sel data-entropy rule at the
    feature layer; a low-entropy entry would be a brute-force oracle — §5). The **grant event's SAID
    `G_x`** (the public governance `Ixn`) **identifies the validity period** — it commits the members,
    from-positions, and sharing context at grant. Multiple grants for a member = multiple periods
    (re-add). **One uniform rule for per-member and batch grants:** the rescission handle is the nonce'd
    member-entry SAID `said_b` (below), so a batch grant needs no separate handle scheme.
  - **sharing changes** — `readPolicy` updates (§5).
  - A grant is a **creator-governance act** — not a bare T1 a **compromised creator signing key** could
    mint (cold N2: SELs are not secret-bearing; the minter is a compromised T1 key, not a "leaked SEL").
    Pinning the exact tier/kind is a real open (§7): the SEL taxonomy has no tier-elevated content kind
    and inv 12 forbids per-event count elevation, so the resolution space is hardening the creator
    identity by config, not a new kind.
- **Rescission — period-scoped membership removal (reuses the §5 `bound` mechanism, not `Del`).** To
  remove member b's period: a rescission SEL keyed `derive(creator, DOC_RSC_TOPIC, hash(G | said_b))` —
  `G` the grant-doc's canonical SAID, `said_b` the nonce'd member-entry SAID — `{Icp, Dec}`, the `Dec`
  carrying **`bound = b-IEL@B_b`** in a **gated rescind-doc** (member + bound behind the read gate).
  Present → that period is closed at `B_b`; absent → open. A negative-check-as-lookup (inv 10): O(1),
  per-period. **The key is member-blind AND grant-blind, computable, non-reversible (folds cold F1 /
  warm F1 — the earlier "unguessable to a witness" claim was false):**
  - **member-blind** — the member prefix is **never** a derivation input; the input is `hash(G |
    said_b)`, and `said_b = said({nonce_b, prefix_b})` is unguessable via `nonce_b`. So a witness (which
    _does_ hold member prefixes — the version-SEL v1 anchors on the member's IEL, §5) **cannot
    brute-force candidate members** to confirm one. This is the property the review found load-bearing.
  - **grant-blind** — a witness **holds `G` and `G_x`** (both public — the grant-doc SAID and the
    governance `Ixn` SAID it witnesses), so "a witness can't derive it" was false as first written; but
    it does **not** hold `said_b` (nonce'd, inside the gated grant-doc), so it **cannot compute `hash(G |
    said_b)`** → can't even link the rescission to its grant. This **beats** a bare `{doc_prefix, G_x}`
    key, which a witness _could_ recompute for every `G_x` → leaking which grant each rescission closed.
  - **computable by a reader** — an authorized reader holds `G` (public) and `said_b` (from the gated
    grant-doc it can read) → derives and looks up. **Re-add** rides for free: a fresh grant → new `G` →
    new `said_b` → a new period key.
  _(Per-period keying is the deliberate divergence from `Del`-rescission's permanent-prefix cap (inv 15
  R3-3) — it is what lets a removed member be **re-added**. Two encoding notes vs delegation: (1) the
  `bound` rides **gated content**, not delegation's public `manifest.bound` role — because a bound SAID
  is **member-identifying by matching** (a witness holding the member's IEL matches the SAID against its
  events, no inversion), so it can't sit on public structure (warm F8). (2) the `Dec` seals at
  `Kil`@`govern`, not `@delegate`: inv 4's total rule reserves `delegate` for a lookup-SEL keyed on a
  **delegate prefix** — this is keyed on `hash(G | said_b)`, so `govern` — and a `Kil` forces a `Rot`, so
  each removal is a `t_govern` ceremony, the expensive side of a cheap-grant / expensive-kill asymmetry,
  cold F8 / warm F7.)_
- **Version — a primitive attributed SAD (the custody primitive, not a bespoke shape — Q2/F5).**
  `custody { owner = the member IEL prefix, topic = DOC_TOPIC, readPolicy = the current gate }` — and
  because custody lives **only** on standalone SADs (`custody.md`: chain events carry no custody slot), a
  version _is_ a custody-attributed standalone SAD, so the primitive fixes its shape: owner-rooted by its
  `derive(owner, DOC_TOPIC, version_said)` SEL (`data = version_said`), a short **`{Icp, Pin}`** SEL
  whose **`Pin` (the serial-1 v1) is anchored** by the member's IEL `Ixn` at position `V_x` — the
  version's **as-of** (append-only). _(The `Icp` is never anchored — it rides `v1.previous`, inv 15; the
  `Pin` is the anchored v1, not a redundant floor. No `{Icp, Ixn}` content-on-a-log variant — that
  couldn't carry `custody`; no `{Icp, Dec}` seal variant — nothing consumes a version SEL past v1, and a
  `Dec` would move the as-of onto a `Kil`@`t_govern` position, defeating the cheap-`t_use` authorship.)_
  The version SAD carries: a high-entropy **`nonce`** (private docs — so `version_said` is unguessable on
  public structure, §5), the **doc prefix** (doc-scoping + governance lookup, direct — no `ancestors[]`
  walk to root), the **authorizing grant `G_x`** (the period this version claims — reveals nothing new,
  the reader already holds `owner`; it lets the honored-check name a specific period, §Period-lifecycle),
  **`ancestors[]`** (parent version SAID(s), the DAG), and an advisory **`edited`** timestamp (feature,
  on the SAD, never the chain — inv 6). Nothing grows, no folds.
- **The honored predicate — the load-bearing check.** A version by X at `V_x` is **honored iff** its
  **pinned grant `G_x`** names a period with `from = F_x` and — letting `B_x` be that period's rescission
  bound (or open) — **`F_x ≤ V_x ≤ B_x`**. `F_x`, `V_x`, `B_x` are **all positions on X's own IEL**, so
  the test is **intra-chain, append-only, structural — no clock, no self-asserted pin.** _Backdate closed
  both ways: X can only append forward on its own IEL, so a post-removal version is past `B_x`; and X
  cannot make an old, immutable IEL event anchor a new version._
  - **Endpoint provenance (cold F3):** `F_x` and `B_x` are **creator-chosen referents into X's chain** —
    the membership authority's dial, _not_ structurally the tip-at-grant. The backdate argument rests on
    X's append-only chain, not on where `F`/`B` sit, so it holds regardless: a garbage `F_x` matches no
    version (fail-secure); a deep `F_x` retro-honors within creator authority.
  - **The open-by-absence read needs the freshness bar (warm F4).** `B_x` **absent → open** is a **to-tip
    loss-of-trust read** — a stale view of the rescission locus hides a closure and would honor a
    rescinded member's _new_ versions. So honoring an open-period version requires the **multi-source /
    witnessed bar (inv 8)** on the rescission locus **and** the grant's governance SEL, **REFUSE** on an
    unconfirmable read — the same mandatory to-tip step creds run (`document-policy §F`). Asymmetry worth
    stating: once `B_x` exists it is set-once / sealed, so **closed periods are freshness-insensitive** —
    only the absence read is.
- **Periods for a member must be disjoint — enforced at doc-validation, not the SEL walk (Q1, folds cold
  F3's retroactive-`from` + the double-grant open).** A version pins its authorizing grant; the creator
  **may author** a retroactive or overlapping grant (a structurally-valid SEL event — the SEL walk does
  not reject it), but **doc-validation rejects a doc whose member's periods overlap** on that member's
  IEL. So a retroactive `from` (re-covering a rescinded window) or a plain double-grant (a fresh grant
  while a period is still open) makes the doc **invalid** — the creator _can_ author it, they just
  **break the doc**. Re-add stays valid because its periods are **disjoint** (`F₂ > B₁`,
  rescind-then-regrant). The "end-verifiability, not pristine data" posture: don't prevent the authoring,
  catch the broken state deterministically at validation (Jason 2026-07-04).
- **State = the version DAG** — possibly multiple tips; forks are legal and **presented**, never
  picked. Convergence = a multi-parent merge (a version whose `ancestors[]` names competing tips).
  Canonical = a **tag** (a feature assertion, itself an edit — tags can conflict; the app arbitrates).
- **Freeze — hard, structural.** Two distinct jobs: the creator **bounds every member** (closes all
  open periods → no `V_x` can fall in an open window → no new version honored — the version-stopper,
  per-member intra-chain) **and** `Dec`s the governance SEL (blocks re-grant → makes it **permanent**,
  the irreversibility). Bound-all alone stops versions; `Dec`-governance alone does **not** (open
  periods stay open). Unfreeze = reincept to V0′.
- **Crediting is claimed-vs-consent (carried, cold-2 F5).** A grant _names_ a member, but credit only
  a member with ≥ 1 **honored** version — a malicious creator can _grant_ a non-consenting party but
  can't manufacture their `t_use`-signed versions. The grief of being _named_ is unmitigable (social,
  not structural); the rule gates _crediting_, not _naming_.

## 2. Attribution, self-location, and the work cap

- **Provable authorship (the point of the collapse).** Each version is `owner`-committed and
  owner-rooted by the member's own SEL, so authorship is non-repudiable — anchoring proves
  _authorship_, not mere endorsement. (The first-cut anchored-set walk couldn't tell originator from
  endorser; this can.)
- **Self-location — inv-16-clean, all by-prefix (with V0 in hand — cold F6 / warm F10).** A **holder
  holds V0** (the constitution — it derived the doc prefix, so any V0-claimant self-authenticates against
  it), and V0 supplies `creator` + the reserved topics. The doc prefix **scopes**; V0 supplies the
  derivation inputs — the prefix alone is an opaque hash and yields nothing (the earlier "doc prefix →
  creator" arrow implied a derivation that doesn't exist). Then derive the governance SEL
  `derive(creator, DOC_GOV_TOPIC, doc_prefix)` (walk for the version's grant + `F_x`) and the period
  rescission `derive(creator, DOC_RSC_TOPIC, hash(G | said_b))` (→ `B_x` or open). No SAID is inverted;
  "no walk to the DAG root" means governance needs no `ancestors[]` resolution.
- **Work cap — per-version + hard size caps (carried, cold-2 F2 / cold-3 B1).** Attribution is
  per-version primitive verification (real author work, one `t_use`/version — not amplifiable). The
  floodable cost is `ancestors[]` resolution (an inline list): **O(1) set-membership** of each parent
  against the **built version set** (the versions the verifier holds — discovery is peer/availability-side,
  there is no registry, so completeness is availability, not structure; cold N5), never a recursive
  ancestor walk; dangling-parent fetches **bounded** (backoff → give-up → flag deferred). Hard size caps
  (inv-14 pattern, verifier rejects over-cap):
  **`|ancestors|`/version**, **grants/governance-step**. A junk flood denies **only the flooder's own
  placement**.

## 3. Two "forks" — don't conflate them

- **SEL-chain fork** (two events at one SEL serial) — forbidden/detected by the divergence model; each
  version SEL and the governance SEL are strictly **linear**.
- **Version fork** (two versions naming the same `ancestors` parent) — **allowed/presented**; the DAG
  branches at the document layer over linear SELs. Acyclic by SAID (a cycle = a Blake3 preimage
  cycle).
- **A member's IEL divergence is handled by two composed rules, not one (cold F2 / warm F3).** A
  divergent member's IEL **reads suspect** — _not_ "is compromised" (the data can't diagnose intent; a
  benign two-device race is inert by anchor-monotonicity, area-iel §5) — and a version anchored above
  that IEL's seal reads suspect until the IEL resolves (the seal-boundary rule, inv 13).
  - **The anchor edge is genuine inv 13 reuse.** If the IEL resolves with the version's v1 anchored in a
    **non-canonical** member event, the version SEL dies by **cross-layer deadness-descends** across the
    **IEL→SEL anchor edge** (the repair proof's §Cross-layer — that edge is exactly what inv 13 provides).
  - **DAG descent is _this feature's own_ rule, derived as a placement consequence — not inv 13/17.**
    `ancestors[]` is a feature-layer, **multi-parent** edge; deadness-descends is defined only over
    `previous`-linkage and the IEL→SEL anchor edge, so claiming the primitives provide descent down the
    DAG over-reaches. The semantics still hold, by **placement**: a version places only against **live
    parents in the built version set** (§2), so a dead parent is not in that set → its descendants are
    **unplaceable**. `ancestors[]` is SAID-committed, so re-parenting = **re-authoring** on a live version
    — the content re-issue analog. On a merge with one dead and one live parent, the child is unplaceable
    (**any dead parent drops it**) and editing **re-authors from a live (canonical) version** — Jason
    2026-07-03: "their tails also die; they re-edit from a live part of the dag." Structural language
    throughout — canonical / non-canonical / dead, never "adversary."

## 4. Trust posture

- **External parties** can't inject/alter versions (owner-rooting + the honored window) or brick the
  doc (a junk flood denies only its own leg, §2).
- **A member's T1 (signing-key) compromise is bounded + recoverable — and the bound is the operator dial
  (cold F4).** The attacker authors valid attributed versions **as that member** within its open period;
  they linger (durable, route-around-able). Recovery: the **creator rescinds the compromised period**,
  and **where the `bound` cuts is the operator's choice, not forced by inv 13.** The `bound` is the
  sanctioned wholesale retroactive lever (inv 13: "nothing past the bound is honored — grants _and_ kills
  alike"), so the creator chooses along the member's chain:
  - `bound = detection tip` grandfathers **all** honored work including the attacker's in-window versions,
    stopping only future ones;
  - `bound = last-good event` (inv 4's own recipe — "the last honoured event") un-honors the malicious
    window at the cost of any honest same-window versions.
  That trade — honest collateral vs malicious survival — **is** the recovery decision, not something inv
  13 forecloses; "no retroactive distrust" is reserved for what inv 13 actually forbids (a quorum's
  **per-event self-history** un-trust, the backdate kill-switch). After the bound, the creator **re-adds**
  the member on a fresh **disjoint** period once it rotates the bad device out of its own IEL. Bounded,
  recoverable, **no whole-doc reincept.**
- **Creator-side divergence is the symmetric leg — Kill-sealing gives it a clean asymmetry (cold F5).**
  During the creator IEL's own divergence the doc reads suspect by the same seal-boundary rule. **Grants
  are T1 content `Ixn`s** — archivable by a creator-IEL repair (inv 13 rule 1), so an archived grant's
  periods evaporate and versions honored under them silently un-honor (fail-secure, standard content
  semantics). But **rescission and governance `Dec`s are `Kil`-sealed → repair-proof** (inv 13: a
  privileged event is never archived), so the monotone acts (a removal, a freeze) **cannot be un-done by
  any repair** — exactly the right asymmetry: a grant can be walked back, a kill cannot. _(Re-granting
  after an archived grant is the retroactive-`from` case — caught by the disjoint-periods rule at
  validation, §1.)_
- **Creator (governance) compromise, or a rogue/unrecoverable creator → reincept the whole
  document.** A compromised creator can grant rogues, rescind honest members, or freeze — the
  governance locus is captured. Action: honest parties **abandon and reincept a fresh V0′** (new
  creator/constitution) seeded from the last good version; the old DAG stays verifiable.
  **Successor-auth is out-of-band** — nothing structural links V0′ to V0 (by design; a competing V0″
  is always mintable; legitimacy is social). Only the creator's compromise is whole-doc; members'
  are member-local (above).

## 5. Custody, sharing, and privacy

- **`readPolicy` = the read/sharing gate** — evaluated current-mode at fetch by the store. It is
  **read-set invariance (integrity), not confidentiality** (carried, cold-2 F1 / cold-3 S2): a
  co-author can always read + exfiltrate; the rule keeps the _canonical_ DAG's read-set uniform, it
  does not hide bytes. **For confidentiality, encrypt** (a forward direction). **Sharing evolves** via
  governance-SEL `readPolicy` changes (the creator re-shares); a version is checked against the gate
  **as of its authoring period** — the same period-window discipline as membership _(exact mechanism:
  §7)_.
- **Attribution is opt-in-visible; privacy via the read gate.** A version carries `owner` (provable
  authorship) but read-gated — so `owner` is exposed only to authorized readers. Revealing authorship
  is the deliberate cost of _proving_ it; the private default hides it behind `readPolicy`.
- **The co-authorship + membership graphs close for a private doc.** A version SEL `Icp` carries
  `data = version_said` (a nonce'd, gated reference), and the version→V0 linkage rides read-gated
  `ancestors[]` — so a witness sees `(member, version_said)` pairs but **cannot group them by document**
  for a **private** doc; the strong on-chain co-authorship graph is **closed** (a public doc's graph is
  readable anyway). The **membership graph closes** because the rescission key is `hash(G | said_b)` —
  **member-blind** (no member prefix as input) **and grant-blind** (a witness can't compute it without
  the gated `said_b`), so a witness can't even link a rescission to its grant, let alone its member.
  Given the grant records are read-gated for a private doc, a witness sees only **`creator ↔ doc`**
  (unavoidable — the governance SEL derives from `doc_prefix`) plus grant/rescission **volume-timing**.
- **The stated residual, completed (cold F9 / warm F9).** For a mesh witness the residual is
  `creator ↔ doc` **plus**: (a) **per-member `DOC_TOPIC` volume-timing** — the `(member, version_said)`
  pairs above, and the **topic** itself (a version SEL `Icp` is recomputable content carrying
  `(owner, topic, data)`, so a witness learns _"member X authors multi-party-doc versions"_, unlinkable
  to a doc absent an oracle); (b) **cross-member timing correlation** of version-SEL activity (co-editing
  clusters — the same inv-16 volume-timing class); (c) grant/rescission volume-timing. It is **never
  _who_ the members are** — the same inv-16 residual class accepted everywhere else, not the graph.
- **Every gated doc on public structure needs its own `readPolicy` AND a high-entropy nonce (warm F2 —
  the offline confirmation-oracle, a MAJOR the review found missable).** A parent's `readPolicy` does
  **not** transitively protect its referenced sub-SADs (`compaction.md` §Privacy contract). So the
  grant-doc's member entries `{said, nonce, prefix}`, the rescind-doc `{member, bound}`, and a private
  doc's version SADs each carry **their own `readPolicy`** (else the content is publicly fetchable by
  SAID regardless of the parent's gate) **and a high-entropy `nonce`** (else the SAID is a **hash-match
  confirmation oracle** — compose candidate content, hash, compare the committed SAID; a member prefix +
  known `G` is candidate-composable). The store-side `denied ≈ absent` **cannot** defend a SAID already
  public on the chain — the entropy must be in the _input_ (the area-sel data-entropy rule at the
  feature layer; V0 already has its nonce by design). App-builder responsibility; the framework provides
  the per-SAD `readPolicy` + the nonce slot.
- **Content off-node — submit the SELs, hold the content (the sovereignty mode).** A participant may
  submit only the **SEL chains** (version, governance, rescission — pure opaque structure, witnessed)
  and **never land any content SAD** (versions, grant/rescind docs) on the node; the content is held
  on-device and shared peer-to-peer (exchange/mail, §9). This composes because **the node's role is
  chain-only** — chain validity + witnessing are content-independent (inv 17), and every feature check
  (membership window, DAG placement, the honored predicate) is **participant-side**, run by whoever
  holds the content. So the node hosts a fully opaque chain and **nothing content-readable** (the
  governance `Icp`'s `data = doc_prefix` and the version-SEL `(owner, DOC_TOPIC, version_said)` are
  structural — cold N1). Two tiers, a per-doc choice: **content off-node** (max privacy; participants
  bear availability) or **content on-node but gated** (`readPolicy` + nonce'd SADs — node availability,
  the mesh-correlation residual). **Feature invariant: no node operation may require a content SAD**
  (§7) — and the encode must add an **off-node carve-out to deferred-deps (warm F12):** a
  permanently-off-node anchored SAD is an **opaque commitment, never a pending dependency** (the existing
  `MissingSadObject` park/drain, vdtid-services §1h, predates off-node mode and would park-forever
  otherwise).

## 6. Credentials vs multi-party documents — two types, one substrate

|            | Credential (policy layer)                        | Multi-party document (this feature)                       |
| ---------- | ------------------------------------------------ | --------------------------------------------------------- |
| parties    | `issuer`(s) + an `issuee` — **asymmetric**       | a **creator** + **members** — governed, symmetric members |
| membership | fixed at issuance                                | **creator-governed, evolving** (grant / bound / re-add)   |
| policy     | authorizing + acceptance conditions              | none except `readPolicy` (the read/sharing gate)          |
| content    | frozen (single version)                          | evolves (the version DAG)                                 |
| kill       | revocation `Dec` (`Kil`@`govern`)                | per-member period-bound; **freeze** = bound-all + `Dec`-gov |
| home       | `primitives/policy/documents.md`                 | `features/multi-party/documents.md`                       |

Shared substrate: documents are **attributed SADs** (`owner`+`topic`+SEL-anchor), located by
`derive`, in a DAG; membership reuses the §5 grandfather-`bound` mechanism. They specialize
differently and are **not** merged.

## 7. Open / for the adversarial pass

_(2026-07-04 dual-pass folded above: the rescission-key member+grant-blindness, the gated-doc
entropy-nonce rule, the DAG-descent placement derivation, the honored-window freshness bar, the
recovery-bound operator dial, and the disjoint-periods lifecycle rule are **resolved** in §1/§3/§4/§5.
What remains open:)_

- **Grant tier + sealing — the resolution space is narrower than it reads (warm F13).** A grant changes
  who is honored, so it is creator-governance, not bare T1. But the SEL taxonomy has **no tier-elevated
  content kind** (`Ixn` is the only content event; `Fld` re-seals, `Dec` kills — area-sel §1), and inv 12
  self-pricing **forbids per-event count elevation**. So the honest space is (a) accept T1 grants +
  **harden the creator identity by config** (a governance IEL with high `t_use` — the cred issuance-is-T1
  precedent), the real threat being a **creator-`t_use` compromise** minting grants, not a "leaked SEL"
  (owner-rooting already stops non-creators); or (b) a new structural surface — which contradicts the
  **No new primitive** banner. Pin (a) or justify (b) at encode.
- **Sharing (`readPolicy`) evolution + read-invariance outcome (warm F14).** The period-window discipline
  for the read gate (which `readPolicy` a version is checked against, backdate-resistance), mirroring
  membership; **and** what a read-invariance violation _does_ — un-honored (a fourth conjunct in the
  honored predicate) or presented-but-flagged (app contract). Work both together.
- **Reserved topics** — `DOC_TOPIC` (version attribution), `DOC_GOV_TOPIC` (governance), `DOC_RSC_TOPIC`
  (period rescission); fix names at encode (parallel to `CRED_TOPIC` / `RSC_TOPIC`), and add the
  `DOC_RSC_TOPIC` row to inv 4's `Kil` topic→slot total rule (**`govern`** — its key is not a delegate
  prefix; §1 rescission).
- **Gated-doc shapes — mostly resolved (§1), pin the field layout at encode.** Settled: the grant-doc
  compacted-chunk graph (`G = {said, custody, roster:{add:[{said, nonce, prefix}, …]}}`), the rescind-doc
  `{member, bound}`, the rescission key `hash(G | said_b)`, and the every-gated-doc-carries-a-nonce +
  its-own-`readPolicy` rule (§5). Remaining: the exact field layout.
- **Node-never-needs-content + the off-node deferred-deps carve-out (warm F12).** Verify no node
  operation requires a content SAD (so off-node holds), **and** make the drain loop treat a
  permanently-off-node anchored SAD as an opaque commitment, never a park-forever `MissingSadObject`
  (vdtid-services §1h). A checked property.
- **Multi-admin** — a single `creator` IEL governs; a governance _threshold_ (co-admins) is an extension.
- **Membership cap** — set `MAX_MEMBERS` (small; §1), and decide **periods-per-member** — a cap (inv-14
  pattern) vs an explicit "unbounded but per-lookup-O(1)" note (warm F11).
- **Doc-prefix derivation** — pin how V0 derives the doc prefix (nonce'd, inception-style) and the
  uncorrelatable event-SAID discipline (§1).
- **`compaction.md` is wrong on SAID-invariance (found 2026-07-04; fix at encode, per Jason).** The
  landed `compaction.md` (and `said.md` §Canonical-form Rule 1) claim the SAID is preserved across
  expanded/compacted wire forms; the `../kels` code (`lib/creds/src/compaction.rs` — compute-SAID over
  the current value, bottom-up) shows it is **form-dependent**. Truth: one **canonical (fully-compacted)
  SAID**, references commit to it, a verifier re-derives it by compacting any form down (it must stay
  derivable from the data — you can't hardcode it in a body). Fix the SAD-primitive docs at the
  multi-party encode; the `.working/` canon carries no such claim (grep-clean 2026-07-04).

## 8. Drift → land

- Write `docs/design/features/multi-party/documents.md` fresh from this note (greenfield voice;
  credentials as the _contrast_). Forward-ref from `primitives/policy/documents.md` + the SEL
  primitive.
- Depends on the landed custody `owner`+`topic`+SEL-anchor model (inv 16 note) and the §5
  rescission-`bound` mechanism.
- **Encode-voice (cold N3 / warm N3):** the §5 first-cut-relative framing and the `cold Fn`/`warm Fn`
  citations throughout are working-note bookkeeping — restate every property in **absolute** greenfield
  terms at encode; drop "decentralized Google-Docs-with-sharing" (brand analogy).
- **Landed backport (warm F5, folded 2026-07-04):** `custody.md`'s "the SEL's inception is anchored"
  spans are corrected to "the v1 (`Pin`) is anchored, the `Icp` rides `v1.previous`" (inv 15) — same
  change, landed-docs-current rule. And the `compaction.md`/`said.md` SAID-invariance fix (§7).

## 9. Ideas / forward (exchange-layer — not settled, captured so the thread isn't lost)

- **Content confidentiality via a KEM-wrapped group key.** Off-node / private content is encrypted
  under a per-doc symmetric key (AES-256-GCM); the key is distributed to each member by
  **KEM-wrapping it to that member's per-device KEM key**. **Correction (warm F15):** canon publishes
  KEM keys for **witnesses only** (a per-witness key SEL owned by a degenerate per-device IEL derived
  from the _witness_ KEL — impl-notes:100-110); **user member devices publish no KEM key today**, so
  extending that key-SEL pattern to user devices is **new (reasonable) machinery, not reuse**. This is
  the "encrypt for confidentiality" layer (`readPolicy` is access-integrity; the encryption hides bytes).
- **Re-key on removal (forward secrecy).** A removed member keeps the old key, so rotate: a new key
  wrapped to the **remaining** members, future content under it. Forward secrecy for new versions; the
  past can't be un-shared (consistent with "a co-author keeps what they already read").
- **Key epochs align with membership periods.** A newly-added member gets the **current** epoch key →
  reads from join forward, mirroring its `[from, bound]` window; a removed member is cut at the next
  re-key, mirroring its `bound`. The crypto epochs and the honored windows are the same shape — one
  notion of "since when," not two.
- **Tiered post-quantum crypto (kels precedent).** Infrastructure (witnesses) is bound to
  **ML-DSA-87 / ML-KEM-1024**; users may drop to **ML-DSA-65 / ML-KEM-768**. The algorithms are
  integration-identical (same call shape), so the tier is a parameter choice, not a code path — as
  done in `../kels`.
- **Home:** all exchange/mail feature territory (forward — inv 16 flags multi-party exchange as needing
  an extension); a feature layer over the primitives, not primitive work.
