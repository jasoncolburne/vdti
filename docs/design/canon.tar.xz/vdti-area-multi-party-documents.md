# vdti — area note: Multi-party documents (collaborative, evolving)

**Status: FIRST CUT + three review rounds folded (2026-06-27).** A **feature** over the SEL + SAD primitives: a document several parties
co-author and that **evolves** over time, fully end-verifiable. Worked out in conversation with Jason this
session. **Distinct from credentials** — a credential is the policy-bearing, frozen, `issuers[]`/`issuee` shape in
the policy layer (`primitives/policy/documents.md`); this is a separate document type with symmetric co-authors.
We deliberately **do NOT subsume** one into the other (the axes differ — a co-author is not an issuer, an issuee
is not a co-author). Lands at `docs/design/features/multi-party/documents.md`.
**Invariants referenced:** [inv 2] single-locus, [inv 5] pin-floored / anchoring-position, [inv 6]
no-timestamps-on-primitives, [inv 15] inception/pin, [inv 16] addressing-by-prefix.

## Sources
- This session's design conversation (the version-DAG model, the trust posture, the policy/custody scoping).
- The dual-pass review of the *model* (`archived/vdti-document-authorship-thoughts-warm.md` / `…-cold.md`) and two
  rounds on *this note* (`archived/vdti-multi-party-review-*`) — **all findings through round 3 folded** (round-1
  cold blockers resolved with Jason: fold-cost operational, per-version `ownerPin` dropped; round-2 F1–F8 folded;
  round-3 warm MERGE, cold HOLD-narrow folded — **B1** breadth hard-caps, **S1** graph-leaks-structurally-not-by-
  content, **S2** readPolicy = read-set invariance not confidentiality, **S3** denied≈absent + mesh-member, **S6**
  out-of-band successor-auth; **S4** resolved by the `issues`/`revokes`/`rescinds` → `anchors` collapse; **S5**
  mis-framed — the re-seal `Evl` *is* blessed in `area-iel`).
- Grounded in the landed SAD layer (`sad/{sad,custody,compaction}.md`), the SEL primitive (area-sel / event-shape),
  and the policy layer (`policy/{documents,policy,evaluation}.md`).

## 1. Locked-candidate — the construct

The use case is **collaborative editing** (a shared spreadsheet, a co-authored record) — parties who *want*
well-formed shared data and coordinate; an attacker is still in scope, but a named co-author is **honest for
liveness**. No new primitive: the whole thing is SELs + standalone SADs plus feature-level conventions.

- **V0 = the immutable constitution** — a standalone SAD carrying:
  - **`authors[]`** — the author IEL **prefixes** [inv 7]. Content-bound, so the author set is immutably fixed to
    the document's identity (its SAID). A listed prefix is the **claimed** set, **not consent** — an author
    actually participates only by standing up its own **owner-rooted** SEL `Icp` (`data = V0.said`), the real
    per-author endorsement (cold C7). This is the **same pattern the policy layer already locks** for multi-issuer
    authorization (`policy/documents.md`: an issuer that has **not** attested contributes no anchored position and
    is **not credited** — a malicious co-issuer can't manufacture another's attestation). So make it an explicit
    **verifier rule:** a prefix in `authors[]` is **credited as an author only if it has a valid owner-rooted leg
    with versions** — else a malicious V0 that lists non-consenting honest parties as "authors" (of, say, a
    defamatory doc) is an attribution/UX trap (harmless to **integrity** — forging a leg needs that author's
    `t_use` — but real to **attribution**, cold-2 F5). The **grief itself (being *named*) is unmitigable** (cold-3):
    the rule gates *crediting*, not *naming* — a malicious V0 can always list you; that legitimacy is social, not
    structural.
  - **`custody.readPolicy`** (optional) — the document's read gate (current-mode, [`custody.md`](../docs/design/primitives/data/sad/custody.md)). **Immutable across the DAG** (§4).
  - **`nonce`** (optional) — high-entropy for a **private** document (unguessable V0.said → unguessable per-author
    SEL prefixes, the private-cred parallel); omit for a **public/discoverable** one (area-sel §1 entropy rule).
  - **No authorizing / acceptance policy** — this is not a credential; nobody "presents" a spreadsheet. Write
    authorization is **membership** (structural — a named author signing under its IEL `t_use`).
- **Per-author SEL** — each author runs **one** SEL for the document: `derive(author, DOC_TOPIC, V0.said)` (a
  feature topic constant, like `CRED_TOPIC`), so a verifier holding V0 locates **every** author's chain. `Icp`
  (`owner` = the author IEL prefix, `data` = `V0.said`) **+ a serial-1 `Pin`** that floors the endorsement (inv 15).
  An author **endorses first** — stands up `{Icp, Pin}` to join V0 — and **edits later**: there's no moment where
  every author has a first version ready *during* V0-authoring, so the serial-1 event is a bare **`Pin`**
  (incept-and-sit), not an immediate edit `Ixn`. The IEL `Ixn` anchors the **serial-1 `Pin`** (the *v1* —
  `manifest.anchors` → the `Pin`; `Pin.pin == anchor.previous` floors it), **not** the `Icp`; the `Icp` rides via
  `Pin.previous`. Edits follow as content `Ixn`s, each its own anchored event. One SEL per **(document, author)**.
  - An **edit** = a SEL **`Ixn`** whose **`manifest.content`** names the version SAD (NOT `data` — that is
    `Icp`-only; the content `Ixn` carries the `content` role, inv 4). Each `Ixn` re-pins. **`manifest.content` is an
    inline *list*** (inv 4), so the feature **constrains one edit to one version SAD per `Ixn`** (a batched-multi
    `Ixn` would need defined per-leg version-sequence semantics; keep it one — cold-2 F8).
  - The SEL **re-seals** via **`Fld`** (≈ every 64 edits), which rides an owner
    IEL `Evl` via that `Evl`'s `anchors` (the C7 fix, 2026-06-27). A **quiet** author (no pending roster/threshold
    change) authors a **pure-reseal roster-less `Evl`** (no roster/threshold change — **omits `roster`** per inv 18;
    the KEL `Rot` / IEL re-seal-`Evl` analog, area-sel §4) purely to carry the `Fld`'s `anchors`; this is **permitted** — `area-iel`
    states it explicitly ("the re-seal `Evl` is **valid**… must **accept**" — it closed a round-5 IEL
    cold-review finding), the `roster` role is **omitted** (inv 18 — omit-when-unchanged; the re-seal is identified by `previousSeal`+`folds`), so a quiet document
    still grows past the seal-cap. Repairs via **`Rpr`**, freezes via **`Dec`**. A busy author's SELs are **witnessed like any SEL**.
  - **The fold cost is operational, not structural (Jason 2026-06-27, resolving cold's blocker).** The owner IEL is
    a **single identity — the same person** — governing its own SEL, so a fold is that person re-sealing their own
    chain, **not** a multi-party ceremony. A **sustained** leg needs **fold capability** (its `t_govern` quorum),
    not just `t_use` — a solo author (1 device → `t_govern = 1`) folds trivially; a multi-device author must muster
    the devices it set `t_govern` for every ~64 edits. A high-edit-rate doc tunes `t_govern` / device count to taste
    (and frequent folding is a forward-secrecy *upside*) — no cheap-fold primitive is needed; the SEL/IEL reuse stands.
- **Version SAD** — a standalone SAD (the `Ixn`'s `manifest.content`) carrying:
  - the document content (cells / payload),
  - **`ancestors[]`** — the parent version SAID(s), **multi-parent** (a DAG), held **in the SAD content** so the
    head cryptographically commits to its whole history (renamed off the SEL-chain `previous` to avoid conflating
    the two — §3),
  - an advisory **`edited`** timestamp — **feature-level, on the SAD, never on the chain event** [inv 6]; the
    **feature-layer** walk (the primitive SEL walk sees only the `manifest.content` SAID, never the SAD's `edited`
    field) checks per-author monotonicity and **reports** (advisory, never decides),
  - **`custody.readPolicy`** — V0's readPolicy SAID, carried unchanged (§4); **no `custody.ownerPin`** — the version
    is attributed by the owner-rooted SEL `Ixn` that anchors it, so a self-asserted writer field would be redundant
    *and* a forgery surface (inv 5 spirit), and omitting it keeps the **author's identity out of the version
    content** (a privacy gain — attribution needs the by-prefix SEL walk, cold C5).
  - V0 is the **root version** (`ancestors[]` empty/absent).
- **State = the version DAG** — possibly **multiple tips**. Forks are legal and **presented** (never picked).
  - **Convergence** = a multi-parent merge: an author authors a version whose `ancestors[]` names the competing
    tips, re-narrowing the DAG. The *mechanism* for canonical, **not** a guarantee (competing merges → competing
    tips; nothing forces uniqueness without consensus).
  - **Canonical** = a **tag** (a feature-level assertion, itself just another edit — tags can conflict too; that's
    the application's problem to arbitrate).
  - **Freeze** = **every** author closes its leg with `Dec` (the leg-close `Dec` rides an IEL `Kil`@`govern` via
    `anchors` — closure, *not* the `delegate` rail — inv 4) — **all-or-nothing**; one open leg means not frozen. A
    static multi-author document is this all-closed case. Freeze is **irreversible** — a `Dec`'d leg can't rejoin
    (the kill is monotone); "unfreezing" = reincept to V0′.
- **Structural validity vs. lineage — keep them separate (cold C2; the document is never globally invalid).** A
  version is **structurally valid** iff it is **owner-rooted**: anchored by a named author's SEL `Ixn` (signed under
  that author's `t_use`) whose SEL `owner ∈ V0.authors[]`, on a SEL that derives from **this** V0. That is the
  **load-bearing** check (cold C6 — without it anyone mints a SEL claiming an honest author's prefix and the model
  is forgeable); it belongs in the validity predicate, not an afterthought. **Lineage resolution is a separate,
  provisional question:** whether a valid version's `ancestors[]` resolve within this document's DAG. A **dangling**
  `ancestors` entry does **not** invalidate the version — it **defers its DAG placement** (an availability gap).
  **The per-leg work cap — the mechanism (cold-2 F2):** separate the two costs. Building the **anchored-version
  set** is a per-leg chain walk bounded by each leg's length — real author work (each `Ixn` costs a `t_use` + a fold
  every ~64), so it is **not** amplifiable. The floodable cost is **`ancestors[]` resolution**, because `ancestors`
  is an inline list in SAD content — unbounded per version and ~free to author (one `Ixn` → 10⁶ junk SAIDs). So
  **placement is O(1) set-membership** of each parent SAID against the already-built anchored set (a version places
  **relative to its parents**; you do **not** recursively walk a parent's ancestors to place a child),
  **attributed to the authoring leg** and capped there — a flood denies only the flooder's **own** DAG placement;
  honest legs (small `ancestors`, real parents) resolve regardless. And **"keep fetching" a dangling parent is
  bounded** — retry with backoff → give-up → flag the version **deferred** (a junk SAID is indistinguishable from a
  not-yet-available one, so an unbounded retry under a 10⁶-entry flood is itself a network-amplification). With both
  bounds a junk-`ancestors` flood denies **that leg only**, never the whole document, fail-secure. **But that caps
  *depth*, not *breadth* (cold-3 B1):** three attacker-controlled *sizes* still need **hard caps** (the inv-14
  roster-cap pattern — a fixed bound, verifier rejects over-cap): `|ancestors|` **per version** (else one ~free `Ixn`
  names 10⁶ junk SAIDs → 10⁶ membership tests + 10⁶ dangling-fetches, the 1-sig-to-millions amplification),
  `|authors|` **in V0**, and **one version SAD per `Ixn`** (the `manifest.content`-is-a-list rule is *load-bearing*
  for the cap — a verifier rule, not a convention). With the size caps the cap is genuinely per-leg-bounded; without
  them "pinned" is over-claimed.

## 2. Trust posture

- **External parties** can't inject or alter versions (owner-rooting), and no writer can make the document
  *globally invalid* or brick it (a junk flood denies only its own leg, §1).
- **A signing-key (T1) compromise is NOT powerless — "worst is an ignorable tip" is false (cold C3).** With the
  author's **signing key** (`t_use`) the attacker authors **valid, attributed, non-dangling** versions on that
  leg — real versions in the DAG, and (no retroactive distrust, inv 13) they **stay valid** after recovery. But the
  **reserve is intact**, so the action is **recover in place:** the author rotates its IEL (evicting the compromised
  device) — new malicious versions stop, and the ones already written linger as **durable-but-route-around-able**
  (consumers don't tag/merge them). The **seal-cap even bounds** the pollution to ~one fold-window per leg before
  the leg can't extend without a `t_govern` fold. So a T1-compromised author **pollutes** the shared DAG until
  rotated out — bounded and recoverable, but not nothing. (If the compromised *device's* KEL goes terminal — a clean
  `{Rot, Rot}` — the author evicts it at the IEL via an `Evl` and leans on the quorum (inv 13) — **no** whole-document
  V0′; that's reserved for the T2 case below.)
- **A reserve (T2) compromise, or a rogue / unrecoverable author → reincept the whole document.** If the **reserve**
  is compromised the attacker races any rotation (`{Rot, Rot}` → terminal → reincept, inv 13) **and** can author a
  leg-closing SEL **`Dec`** (T2, `Kil`@`govern`) that **permanently closes that leg** (sealed, terminal,
  monotone). Because `authors[]` is **immutable** and the leg prefix is **deterministic** (`derive(author,
  DOC_TOPIC, V0.said)` — exactly one SEL per author, no in-place replacement), a closed or captured leg can't be
  evicted in-document. The action is the **standard reincept-to-recover:** the honest authors **abandon and
  reincept** a fresh **V0′** excluding the lost author, seeded from the last good version; the old DAG stays
  verifiable. **Successor-authentication is out-of-band (cold-3 S6):** nothing structural links V0′ to V0 (by
  design — V0′ is a fresh identity), so the honest authors must agree on and authenticate V0′ **app-level** — the
  same trust basis on which they agreed the original V0's author set (a competing V0″ is always mintable; legitimacy
  is social, not structural). The only cost is the standard one (V0′ is a new identity, re-pointed to).

## 3. Two "forks" — don't conflate them

- **SEL-chain fork** — two events at one SEL serial — stays **forbidden / detected** by the divergence model; each
  author's SEL is strictly **linear**.
- **Version fork** — two version SADs naming the same `ancestors` parent — is **allowed / presented**. The DAG
  branches at the **document** layer, built over linear SELs. (`ancestors[]` is named distinctly from the SEL's own
  `previous` precisely so this distinction stays visible.)
- The version DAG is **acyclic by SAID** — a cycle would be a Blake3 preimage cycle, infeasible (the same argument
  as documents.md non-circular pinning and the `pol` reference graph).

## 4. Policy & custody — policy-free except `readPolicy`

The credential policy story (authorizing + acceptance conditions, the two eval modes, `issuers[]` multi-identity)
is **already fully designed** in the policy layer and is **untouched** — it does not apply here.

- The multi-party document carries **no** authorizing/acceptance policy. Its only policy surface is
  **`custody.readPolicy`** — who may read it — reused verbatim.
- **`readPolicy` is immutable across the DAG — a checked feature-validity rule, honestly bounded (Jason 2026-06-27;
  cold-2 F1).** The document's read gate is fixed at **V0**; **every version must carry V0's exact `readPolicy`
  SAID** (changing it = reincept to V0′, never a mid-document edit). Make `version.readPolicy == V0.readPolicy` an
  explicit **feature-validity rule** (parallel to owner-rooting in §1) — **but be honest about its reach:** it
  **can't** be enforced at the storage layer (the SAD store doesn't know V0), and a verifier can only check it at
  consume time, *after* satisfying `readPolicy` to read the version. So it is **detection by authorized readers, not
  storage-side prevention** — an honest consumer rejects (won't tag/merge) a version whose `readPolicy` doesn't match
  V0's, but a **co-author can always read the whole document**, so out-of-band exfiltration is **unavoidable** in any
  collaborative model. **So the rule gives no confidentiality at all (cold-3 S2): it is read-set *invariance*
  (integrity)** — the canonical DAG's `readPolicy` stays uniform, so honest consumers won't treat a weaker-policy
  version as canonical (won't tag/merge it). A co-author can still *publish* a weak-policy side-version (stored,
  addressable, persistent before any detection) — that leak is structural and **unpreventable**. Claim it as
  integrity (read-set invariance), never as confidentiality / leak-prevention.
- **`readPolicy` must ride every owned sub-SAD — load-bearing against a confirmation oracle.** Per `compaction.md`'s
  privacy contract a parent's `readPolicy` does **not** transitively protect nested sub-SADs, so the same
  `readPolicy` must **also ride each version's content sub-SADs** (a spreadsheet's cells). The teeth: a cell's
  content is **low-entropy**, so its **SAID is guessable** — an attacker enumerates likely cell values, computes
  their SAIDs, and **fetch-by-SAID confirms** the value (a brute-force confirmation oracle — exactly the area-sel §1
  entropy-is-load-bearing argument). `readPolicy` on the cell defeats it **only if the store returns "denied"
  indistinguishably from "absent" (cold-3 S3)** — otherwise the denied/absent split *is* the oracle (denied ⇒ the
  guessed value exists). And it does **nothing** against a mesh-member who can read. This is the **app-builder
  responsibility** the privacy contract names — **enforced by the feature, not structurally rejected** by the
  primitive, and **a read-gated verifier cannot even detect** a content sub-SAD that omits its `readPolicy` (so the
  propagation is an honest-app guarantee — sound against *outsiders*, not against a *malicious author* who wants to
  leak). State it as the feature's contract, not an over-claimed structural rule.
- **No per-version `ownerPin`; attribution is the *set* of anchoring legs (cold C5 / cold-2 F6).** A version's
  custody is just `{ readPolicy }` (an *anonymous-write, controlled-read* shape, `custody.md`); **V0 itself likewise
  carries no `ownerPin`** (the constitution is anonymous-write — the author set is validated by who shows up, §1).
  Attribution is the **owner-rooted SEL anchoring**, not a self-asserted field (dropping it is also a privacy gain,
  §1). Because the version SAD doesn't name V0, attribution is the **set** of legs that anchor a given version
  SAID — the same SAID can be anchored by **multiple** legs (co-endorsement of a merge) and can even occur in
  **multiple documents**; so a verifier must always resolve a version SAID **within a specific document's anchored
  set** and **never cache "version X belongs to document D" globally**. (This is also the real reason
  cross-document replay is closed, §6: a foreign version simply isn't in *this* doc's anchored set.)
- **Immutable constitution / mutable content** is the through-line: V0 (authors + custody) is immutable; only the
  version content evolves; changing the constitution = reincept.
- **Confidentiality boundary — the co-authorship graph (cold C4b / cold-2 F7).** For a *private* doc the read gate
  hides content, but the **co-authorship *graph* leaks to federation witnesses**: each author's SEL `Icp` carries
  **both `owner` (the author prefix) and `data` (= V0.said)** in cleartext, so a **witness** (which validates the
  event) reads both directly and can assemble the **complete co-authorship graph — who collaborates with whom** —
  grouping every author by `V0.said`. Passive, undetectable, the **same class as inv 16's** issuer↔prefix residual
  (a standing property of mesh membership) but **qualitatively more sensitive** (a social graph, not just issuance
  volume/timing) and over the whole author set. The boundary that **holds**: an **outside (non-mesh) party** can't discover the
  authors — locating a leg needs `derive(author, DOC_TOPIC, V0.said)`, i.e. the **author prefixes** (the other half
  of the key), an infeasible enumeration without them. **But encryption does NOT hide the graph (cold-3 S1):** the
  co-authorship graph leaks through the `Icp`'s **structural** `owner` + `data` (cleartext on-chain), not the
  content — so encrypting the version content hides *content* and leaves the *graph* fully exposed to witnesses. The
  graph is a **standing structural residual** (inv 16 class), full stop; closing it would need to hide `owner`/`data`
  themselves, which the primitive can't. Encrypting content via the exchange/mail features is worth doing for
  content confidentiality — a forward direction, not a current guarantee (multi-party exchange may need an
  extension) — but **don't claim it hides the graph**.

## 5. Credentials vs multi-party documents — two types, one substrate

| | Credential (policy layer) | Multi-party document (this feature) |
|---|---|---|
| parties | `issuer` (or `issuers[]`, multi-issuer) + an `issuee` — **asymmetric** | `authors[]` (co-author) — **symmetric** |
| policy | authorizing + acceptance conditions | none except `readPolicy` |
| content | frozen (single version) | evolves (the version DAG) |
| kill | revocation `Dec` (`Kil`@`govern`) | freeze = every author `Dec`s |
| home | `primitives/policy/documents.md` | `features/multi-party/documents.md` |

Shared substrate: documents are SADs anchored in single-owner SELs, located by `derive`, floored by their
serial-1 event, witnessed. The constructs **specialize differently** and are not merged.

## 6. Open / for the adversarial pass

- **★ Owner-rooting is now the §1 structural-validity predicate (hoisted, cold C6).** `SEL.owner ∈ V0.authors[]`
  on a SEL that derives from this V0 — the load-bearing check (the model is forgeable without it). The encode must
  make it an **explicit verifier rule**, not prose.
- **Work cap = per-leg O(1) resolution + hard size caps (cold C3 / cold-2 F2 / cold-3 B1)** — O(1) set-membership
  against the anchored set (no recursive parent-ancestor walk), attributed to the authoring leg, bounded retries on
  a dangling parent (backoff → give-up → flag deferred), **plus hard caps on `|ancestors|`/version, `|authors|`/V0,
  and one-version-per-`Ixn`** (the inv-14 pattern — caps *breadth*, which the per-leg attribution alone does not).
  A junk flood denies **that leg only** (§1).
- **`DOC_TOPIC` constant** — the feature's SEL topic discriminator (parallel to `CRED_TOPIC` / `RSC_TOPIC`); fix the
  exact name at encode time.
- **Cross-document replay** — a version's `ancestors[]` reference versions in **this** document's DAG only; an
  ancestor from another document's DAG **isn't in this doc's anchored set** (§4, attribution-as-set) and doesn't
  resolve here (the SEL derives from this V0.said + owner-rooting ties versions to V0). Confirm the verifier scopes
  the DAG walk to this document.
- **Clock monotonicity reporting** — the per-author `edited` non-decreasing check is advisory/reported; a regression
  is surfaced, not fatal.
- **All-authors vs threshold for V0 "fully constituted"** — with fork-is-legal this is no longer load-bearing, but
  decides when the document is fully-constituted vs usable with partial attestation. Light; pick at encode.

## 7. Drift → land

- Write **`docs/design/features/multi-party/documents.md`** fresh from this note (greenfield voice; credentials as
  the *contrast*, not the subsumer). Forward-ref it from `primitives/policy/documents.md` and/or the SEL primitive.
- The `ownerPin` rename (custody) is **landed** (2026-06-27) as a general SAD-layer field; this feature **does
  not** put it on versions (attribution is the SEL anchoring — §1).
- The C7 `Evl.anchors` fix is **landed** (2026-06-27); the per-author SEL `Fld` depends on it.

## 8. Confidence
- §1–§5 — high. Worked out with Jason and **dual-pass-reviewed across three rounds**, all folded (r1: fold-cost
  operational, `ownerPin` dropped; r2: F1–F8; r3: warm MERGE, cold HOLD-narrow → **MERGE after the B1/S1/S2/S3/S6
  folds**, S4 dispatched by the `anchors` collapse, S5 mis-framed). Net claim-honesty after r3: the work cap is
  **depth-O(1) + hard breadth caps** (not "pinned"); `readPolicy` is **read-set invariance (integrity), not
  confidentiality**; the co-authorship graph leaks **structurally** (encryption doesn't close it); the
  confirmation-oracle defense needs **denied≈absent**; successor-auth on reincept is **out-of-band**. Reuses locked
  primitives wholesale; **no new primitive**.
- §6 — encode-time details (the `DOC_TOPIC` name, cross-document-replay scoping, the all-vs-threshold-V0 question).
