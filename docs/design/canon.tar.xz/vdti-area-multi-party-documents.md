# vdti — area note: Multi-party documents (collaborative, evolving, membership-governed)

**Status: SECOND CUT — crystallized with Jason 2026-07-03 (creator-governed evolving membership +
attributed-version DAG). NOT yet review-passed.** A **feature** over the SAD + SEL primitives: a
document several parties co-author, whose **membership and sharing evolve under a creator**, fully
end-verifiable — decentralized Google-Docs-with-sharing. **No new primitive.** **Supersedes the
first cut** (immutable `authors[]` + a per-author V0-content leg + folds + anchored-set attribution —
all retired); the review-hardened insights (claimed-vs-consent crediting, the size caps, the
residuals, the T1/T2 posture) **carry, re-homed**. The three prior review rounds reviewed the _first
cut_ — **this cut needs a fresh dual-pass.** Lands at `docs/design/features/multi-party/documents.md`.
**Invariants:** [inv 5] as-of = the anchoring position, [inv 10] negative-check-as-lookup, [inv 13]
rescission `bound` / grandfather boundary, [inv 15] inception + attribution, [inv 16] addressing by
prefix + the custody `owner`+`topic`+SEL-anchor note (2026-07-03).

## Sources

- This session's design conversation (the collapse onto attributed SADs; membership-as-access-list;
  the backdate resolution via a member-IEL honored window; period-scoped re-add).
- The first-cut model + its three review rounds — `archived/vdti-multi-party-review-*`,
  `archived/vdti-document-authorship-thoughts-*`. Those reviewed the retired V0-leg model; the
  surviving insights are carried below, re-homed. The obsolete findings (V0-leg, folds, anchored-set)
  do not.
- Grounded in the landed SAD layer (`sad/{sad,custody,said,compaction}.md`), the SEL primitive
  (event-shape / area-sel), the delegation `bound` (delegation §5 / inv 13).

## The model in one paragraph

A multi-party document is **a DAG of _attributed_ SADs (versions), authored by members whose
membership is a _creator-governed, per-period access list_.** Each version is a primitive attributed
SAD — `custody { owner, topic, readPolicy }`, owner-rooted by its own
`derive(owner, DOC_TOPIC, version_said)` SEL exactly like any bare SAD, so authorship is **provable
and non-repudiable** (only the member's `t_use` produces it). **Membership is not delegation** — a
member acts as _itself_, never with the creator's authority — it is an **access list** the creator
maintains on a doc-governance SEL: a **grant** opens a validity _period_ on the member's own IEL
(`from` = the member's IEL tip at grant), and a **rescission** — a period-scoped lookup-SEL carrying
a `bound` on the member's IEL — closes it. A version by member X (anchored at X-IEL position `V_x`) is
**honored iff `V_x` falls in some open period `[F, B]` on X's own IEL** — an **intra-chain,
append-only, clock-free** test, so a removed or compromised member **cannot backdate** into an old
membership state. Because rescissions are keyed **per-period** by the opaque `grant_said`
(`{doc_prefix, grant_said}` — the member prefix is _not_ in the key), a removed member **can be
re-added** (a fresh grant → a new period). Freeze = the creator bounds every member
(structural, hard). The feature is a **verification layer** over primitives: primitive-verify each
version, then check period-membership + DAG placement + read-invariance.

## 1. The construct

- **V0 → the doc prefix (the constitution + the doc's identity).** V0 is the genesis SAD (the DAG
  root), and — like a chain inception — it **derives a doc `prefix`** (nonce'd → unguessable for a
  private doc). **The doc is a DAG feature identified by that prefix, not a chain**; everything
  references the **doc prefix**, and event SAIDs are **uncorrelatable** to it (the prefix ≠ said
  discipline, `said.md` — the correlation a shared KERI-style identifier does not avoid). V0 carries:
  - **`creator`** — the creator IEL **prefix** [inv 7]: governs membership + sharing (may be
    multi-device/threshold; multi-admin is §7).
  - **the reserved topics** — a holder derives the governance chains from the **doc prefix**: the
    governance SEL `derive(creator, DOC_GOV_TOPIC, doc_prefix)`, per-period rescissions
    `derive(creator, DOC_RSC_TOPIC, {doc_prefix, grant_said})`.
  - **`readPolicy₀`** — the initial read/sharing gate (custody; evolution §5).
  - **`nonce`** — high-entropy so the doc prefix (hence the governance / version chains) is unguessable
    for a **private** doc; a public doc may omit it.
  - V0 is **anonymous-write** (the shared constitution; no `owner`), so its legitimacy is
    social/out-of-band — a competing V0′ is always mintable (§4).
- **Membership is hard-capped.** A verifier rejects a doc whose live membership exceeds `MAX_MEMBERS`
  (small — Jason 2026-07-03: 64 is an upper bound, likely smaller). It bounds the governance walk +
  the gated-doc reads a version's honored-check costs (§2).
- **Member names live in gated content, never in public structure (the core privacy discipline).** A
  SEL's structural fields (`owner` / `data` / manifest-role values) are witnessed → **public**, so a
  member prefix in any of them leaks. Every member reference is therefore a **readPolicy-gated content
  SAD** named by an **opaque SAID** from the event's `manifest`; the public chain carries only the
  opaque commitment (the inv-16 private-data pattern).
- **Governance SEL — the creator's access-list + sharing log.**
  `derive(creator, DOC_GOV_TOPIC, doc_prefix)`, owner = creator, `Icp` data = doc_prefix. Records:
  - **grants** — a grant `Ixn` whose `manifest` names a **gated grant-doc** listing member(s) +
    from-positions; the public SEL carries only the opaque doc-SAID. The grant event's SAID `G_x`
    **identifies the validity period** — a stronger commitment than the bare from-position (it commits
    the members, from-positions, and sharing context at grant). Multiple grants for a member =
    multiple periods (re-add). **Per-member grants are the default** — one member per grant makes `G_x`
    the per-member period id, keeping rescission collision-free (below); a **batch** grant (N members
    in one gated doc) is an option that trades that for a per-member handle.
  - **sharing changes** — `readPolicy` updates (§5).
  - A grant is a **creator-governance act** — sealed/tiered as creator authority, not a bare T1 an
    adversary could mint if the governance SEL leaked (the exact tier/kind is §7).
- **Rescission — period-scoped membership removal (reuses the §5 `bound` mechanism, not `Del`).** To
  remove X's period `G_x`: a rescission SEL keyed `derive(creator, DOC_RSC_TOPIC, {doc_prefix, G_x})`,
  `{Icp, Dec}`, the `Dec` carrying **`bound = X-IEL@B_x`** in a **gated rescind-doc** (the member +
  bound behind the read gate; the public key and structure name neither). Present → that period is
  closed at `B_x`; absent → open. A negative-check-as-lookup (inv 10): O(1), per-period. **The member
  prefix is deliberately _not_ in the key** — `G_x` is an opaque SAID (inv 16) unique per grant, so it
  names the period, not the member (a witness learns _a_ period of the doc closed, not _whose_ — §5). **The
  key must be unguessable to a witness:** with per-member grants, `G_x` (from the gated grant-doc a
  witness can't read) is that handle; a batch grant instead assigns each member a random handle `h` in
  the gated doc and keys `{V0, h}`. **Never the raw member prefix** — identities are enumerable, so a
  prefix-keyed lookup lets a witness brute-force `derive(...)` to confirm a member. The verifier holds
  the handle (it read the gated grant-doc), so it derives and looks up; a witness can't.
  _(Per-period keying is the deliberate divergence from `Del`-rescission's permanent-prefix cap
  (inv 15 R3-3) — it is what lets a removed member be **re-added**.)_
- **Version — a primitive attributed SAD.**
  `custody { owner = the member IEL prefix, topic = DOC_TOPIC, readPolicy = the current gate }`,
  owner-rooted by its `derive(owner, DOC_TOPIC, version_said)` SEL (`data = version_said`), whose
  `Icp` is anchored by the member's IEL `Ixn` at position `V_x` — the version's **as-of**
  (append-only). Plus the **doc prefix** (doc-scoping + the governance lookup, direct — no
  `ancestors[]` walk to root), **`ancestors[]`** (parent version SAID(s), the DAG), and an advisory
  **`edited`** timestamp (feature, on the SAD, never the chain — inv 6). The version SEL is **short**
  (`{Icp, Pin}`, or `{Icp, Dec}` to seal) — nothing grows, no folds.
- **The honored predicate — the load-bearing check.** A version by X at `V_x` is **honored iff** X
  has a grant `G_xi` (governance SEL) with `from = F_xi`, and — letting `B_xi` be that period's
  rescission bound (or open) — **`F_xi ≤ V_x ≤ B_xi`**. `F_xi`, `V_x`, `B_xi` are **all positions on
  X's own IEL**, so the test is **intra-chain, append-only, structural — no clock, no self-asserted
  pin.** _Backdate closed both ways: X can only append forward on its own IEL, so a post-removal
  version is past `B_xi`; and X cannot make an old, immutable IEL event anchor a new version._
- **State = the version DAG** — possibly multiple tips; forks are legal and **presented**, never
  picked. Convergence = a multi-parent merge (a version whose `ancestors[]` names competing tips).
  Canonical = a **tag** (a feature assertion, itself an edit — tags can conflict; the app arbitrates).
- **Freeze — hard, structural.** Two distinct jobs: the creator **bounds every member** (closes all
  open periods → no `V_x` can fall in an open window → no new version honored — the version-stopper,
  per-member intra-chain) **and** `Dec`s the governance SEL (blocks re-grant → makes it **permanent**,
  the irreversibility). Bound-all alone stops versions; `Dec`-governance alone does **not** (open
  periods stay open). Unfreeze = reincept to V0′.
- **Crediting is claimed-vs-consent (carried, cold-2 F5).** A grant _names_ a member, but credit only
  a member with ≥ 1 **honored** version — a malicious creator can _grant_ a non-consenting party but
  can't manufacture their `t_use`-signed versions. The grief of being _named_ is unmitigable (social,
  not structural); the rule gates _crediting_, not _naming_.

## 2. Attribution, self-location, and the work cap

- **Provable authorship (the point of the collapse).** Each version is `owner`-committed and
  owner-rooted by the member's own SEL, so authorship is non-repudiable — anchoring proves
  _authorship_, not mere endorsement. (The first-cut anchored-set walk couldn't tell originator from
  endorser; this can.)
- **Self-location — inv-16-clean, all by-prefix.** A version carries the **doc prefix** → `creator` +
  the reserved topics → derive the governance SEL (walk for X's grant + `F_x`) and the period
  rescission (`{doc_prefix, G_x}` → `B_x` or open). No SAID is inverted, no walk to the DAG root.
- **Work cap — per-version + hard size caps (carried, cold-2 F2 / cold-3 B1).** Attribution is
  per-version primitive verification (real author work, one `t_use`/version — not amplifiable). The
  floodable cost is `ancestors[]` resolution (an inline list): **O(1) set-membership** of each parent
  against the built version set (never a recursive ancestor walk), dangling-parent fetches **bounded**
  (backoff → give-up → flag deferred). Hard size caps (inv-14 pattern, verifier rejects over-cap):
  **`|ancestors|`/version**, **grants/governance-step**. A junk flood denies **only the flooder's own
  placement**.

## 3. Two "forks" — don't conflate them

- **SEL-chain fork** (two events at one SEL serial) — forbidden/detected by the divergence model; each
  version SEL and the governance SEL are strictly **linear**.
- **Version fork** (two versions naming the same `ancestors` parent) — **allowed/presented**; the DAG
  branches at the document layer over linear SELs. Acyclic by SAID (a cycle = a Blake3 preimage
  cycle).
- **A member's IEL divergence needs no special handling.** A divergent member is compromised; a
  version anchored above that IEL's seal reads **suspect** and is treated as such until the IEL
  resolves (the seal-boundary rule, inv 13). If it resolves with the version anchored in a
  **non-canonical** member event, the version dies by **cross-layer deadness-descends**, and its DAG
  descendants (the tails built on it) die **by descent** — the subtree drops; editing resumes from a
  **live (canonical)** version. inv 13/17 reused across the anchor edge and down the DAG — no
  multi-party-specific mechanism.

## 4. Trust posture

- **External parties** can't inject/alter versions (owner-rooting + the honored window) or brick the
  doc (a junk flood denies only its own leg, §2).
- **A member's T1 (signing-key) compromise is bounded + recoverable.** The attacker authors valid
  attributed versions **as that member** within its open period; they linger (durable,
  route-around-able) and stay valid after recovery (no retroactive distrust, inv 13). Recovery: the
  **creator rescinds the compromised period** (`bound = the member's IEL tip at detection`) — new
  malicious versions past the bound are un-honored — and **re-adds** the member on a fresh period once
  the member rotates the bad device out of its own IEL. So a T1-compromised member pollutes its own
  window until rescinded/rotated — bounded, recoverable, **no whole-doc reincept.**
- **Creator (governance) compromise, or a rogue/unrecoverable creator → reincept the whole
  document.** A compromised creator can grant rogues, rescind honest members, or freeze — the
  governance locus is captured. Action: honest parties **abandon and reincept a fresh V0′** (new
  creator/constitution) seeded from the last good version; the old DAG stays verifiable.
  **Successor-auth is out-of-band** — nothing structural links V0′ to V0 (by design; a competing V0″
  is always mintable; legitimacy is social). Only the creator's compromise is whole-doc; members'
  are member-local (above).

## 5. Custody, sharing, and privacy

- **`readPolicy` = the read/sharing gate** — evaluated current-mode at fetch by the store. It is
  **read-set invariance (integrity), not confidentiality** (carried, cold-2 F1 / cold-3 S2): a
  co-author can always read + exfiltrate; the rule keeps the _canonical_ DAG's read-set uniform, it
  does not hide bytes. **For confidentiality, encrypt** (a forward direction). **Sharing evolves** via
  governance-SEL `readPolicy` changes (the creator re-shares); a version is checked against the gate
  **as of its authoring period** — the same period-window discipline as membership _(exact mechanism:
  §7)_.
- **Attribution is opt-in-visible; privacy via the read gate.** A version carries `owner` (provable
  authorship) but read-gated — so `owner` is exposed only to authorized readers. Revealing authorship
  is the deliberate cost of _proving_ it; the private default hides it behind `readPolicy`.
- **The co-authorship graph leak IMPROVES vs the first cut (a real win).** Under the first-cut V0-leg,
  each author's SEL `Icp` carried `data = V0.said` in cleartext → a witness grouped every author by
  document → the full graph leaked even for private docs (cold C4b). Now a version SEL `Icp` carries
  `data = version_said` (not V0.said), and the version→V0 linkage rides read-gated `ancestors[]` — so
  a witness sees `(member, version_said)` pairs but **cannot group them by document** for a **private**
  doc. The strong on-chain graph leak is **closed** for private docs (a public doc's graph is readable
  anyway). **The membership graph closes too, given two things:** the rescission key is the opaque
  `grant_said`, not the member prefix (§1), **and** the grant records are **read-gated** for a private
  doc (the member name is in the grant _content_, not a structural field). Then a witness sees only
  **`creator ↔ doc`** (unavoidable — the governance SEL derives from `doc_prefix`) plus grant/rescission
  **volume-timing** — never _who_ the members are. That is the same inv-16 residual class accepted
  everywhere else, not the graph. _(Ungated grants = a public doc, where membership was public
  anyway; the `G_a`-vs-`F_a` referent difference only bites in the unlikely ungated-but-private middle
  case — otherwise `G_a`'s stronger commitment is kept for free.)_
- **`readPolicy` must ride owned sub-SADs (carried, cold-3 S3).** A version's content sub-SADs (cells)
  inherit no protection from the parent (compaction privacy contract), and a low-entropy cell's SAID
  is guessable → a confirmation oracle. `readPolicy` on the cell defeats it **only if the store
  returns denied ≈ absent.** App-builder responsibility, a feature contract — not structurally
  enforced.
- **Content off-node — submit the SELs, hold the content (the sovereignty mode).** A participant may
  submit only the **SEL chains** (version, governance, rescission — pure opaque structure, witnessed)
  and **never land any content SAD** (versions, grant/rescind docs) on the node; the content is held
  on-device and shared peer-to-peer (exchange/mail, §9). This composes because **the node's role is
  chain-only** — chain validity + witnessing are content-independent (inv 17), and every feature check
  (membership window, DAG placement, the honored predicate) is **participant-side**, run by whoever
  holds the content. So the node hosts a fully opaque chain and nothing readable. Two tiers, a per-doc
  choice: **content off-node** (max privacy; participants bear availability) or **content on-node but
  gated** (`readPolicy` + opaque keys — node availability, the mesh-correlation residual). **Feature
  invariant: no node operation may require a content SAD** (§7).

## 6. Credentials vs multi-party documents — two types, one substrate

|            | Credential (policy layer)                        | Multi-party document (this feature)                       |
| ---------- | ------------------------------------------------ | --------------------------------------------------------- |
| parties    | `issuer`(s) + an `issuee` — **asymmetric**       | a **creator** + **members** — governed, symmetric members |
| membership | fixed at issuance                                | **creator-governed, evolving** (grant / bound / re-add)   |
| policy     | authorizing + acceptance conditions              | none except `readPolicy` (the read/sharing gate)          |
| content    | frozen (single version)                          | evolves (the version DAG)                                 |
| kill       | revocation `Dec` (`Kil`@`govern`)                | per-member period-bound; **freeze** = bound-all           |
| home       | `primitives/policy/documents.md`                 | `features/multi-party/documents.md`                       |

Shared substrate: documents are **attributed SADs** (`owner`+`topic`+SEL-anchor), located by
`derive`, in a DAG; membership reuses the §5 grandfather-`bound` mechanism. They specialize
differently and are **not** merged.

## 7. Open / for the adversarial pass

- **Grant tier + sealing** — a grant changes who is honored, so it is creator-governance, not bare T1;
  pin the exact tier/kind on the governance SEL (a plain content `Ixn` won't do if it must be
  reserve-protected against a governance-SEL leak).
- **Sharing (`readPolicy`) evolution** — the period-window discipline for the read gate (which
  `readPolicy` a version is checked against, and its backdate-resistance), mirroring membership; work
  it explicitly.
- **Reserved topics** — `DOC_TOPIC` (version attribution), `DOC_GOV_TOPIC` (governance),
  `DOC_RSC_TOPIC` (period rescission); fix names at encode (parallel to `CRED_TOPIC` / `RSC_TOPIC`).
- **Gated-doc shapes + the unguessable-key rule** — encode the grant/rescind SEL shapes (member data
  in readPolicy-gated content docs, opaque SAIDs on the public structure) and the rescission-key rule
  (an unguessable per-member handle, **never the raw prefix** — §1); settle per-member vs batch grants.
- **Node-never-needs-content invariant** — verify no node operation (witnessing, merge, chain-validity)
  requires a content SAD, so the off-node submission mode (§5) holds. A careless encode (e.g. a
  node-side membership check) would break it — make it a checked property.
- **Multi-admin** — a single `creator` IEL governs; a governance _threshold_ (co-admins) is an
  extension.
- **Membership cap** — set `MAX_MEMBERS` (small; §1).
- **Period lifecycle validity** — a rescission `bound B_x ≥ F_x`; a grant while a member is already
  open (double-grant) reject/no-op vs overlapping periods. Small malformed-checks, currently unstated.
- **Doc-prefix derivation** — pin how V0 derives the doc prefix (nonce'd, inception-style) and the
  uncorrelatable event-SAID discipline (§1).
- **Fresh review** — this cut supersedes the reviewed first cut; it needs a dual-pass: the
  honored-window backdate argument, the period / re-add lifecycle, the governance-compromise reincept,
  the improved-but-nonzero graph leak, and the off-node/node-never-needs-content invariant.
  _(V0-linkage and member-IEL divergence are **resolved** in this cut — the doc prefix, and the
  suspect / cross-layer-deadness-descends model — §1 / §3.)_

## 8. Drift → land

- Write `docs/design/features/multi-party/documents.md` fresh from this note (greenfield voice;
  credentials as the _contrast_). Forward-ref from `primitives/policy/documents.md` + the SEL
  primitive.
- Depends on the landed custody `owner`+`topic`+SEL-anchor model (inv 16 note) and the §5
  rescission-`bound` mechanism.

## 9. Ideas / forward (exchange-layer — not settled, captured so the thread isn't lost)

- **Content confidentiality via a KEM-wrapped group key.** Off-node / private content is encrypted
  under a per-doc symmetric key (AES-256-GCM); the key is distributed to each member by
  **KEM-wrapping it to that member's public key** — reusing the **per-device KEM key** every device
  already publishes for the mesh (impl-notes / inv 16), discoverable by deriving from the member
  prefix. No new key material. This is the "encrypt for confidentiality" layer (`readPolicy` is
  access-integrity; the encryption hides bytes).
- **Re-key on removal (forward secrecy).** A removed member keeps the old key, so rotate: a new key
  wrapped to the **remaining** members, future content under it. Forward secrecy for new versions; the
  past can't be un-shared (consistent with "a co-author keeps what they already read").
- **Key epochs align with membership periods.** A newly-added member gets the **current** epoch key →
  reads from join forward, mirroring its `[from, bound]` window; a removed member is cut at the next
  re-key, mirroring its `bound`. The crypto epochs and the honored windows are the same shape — one
  notion of "since when," not two.
- **Tiered post-quantum crypto (kels precedent).** Infrastructure (witnesses) is bound to
  **ML-DSA-87 / ML-KEM-1024**; users may drop to **ML-DSA-65 / ML-KEM-768**. The algorithms are
  integration-identical (same call shape), so the tier is a parameter choice, not a code path — as
  done in `../kels`.
- **Home:** all exchange/mail feature territory (forward — inv 16 flags multi-party exchange as needing
  an extension); a feature layer over the primitives, not primitive work.
