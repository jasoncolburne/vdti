# vdti — area note: `vdtid` services (node service architecture)

**Status: FIRST CUT (2026-06-20).** The node service architecture — `vdtid` + `witnessd` over a shared
`lib/vdti`. Mirrors the kels service layout with two deliberate changes (merge chain+SAD; gossip→witnessd).
Grounded in the **kels build read on `main`** (the *mechanics* are correct; the *shape/taxonomy* is design-stale,
so mine the machinery not the kinds), the reshape design, and Jason's decomposition decisions this session.
**Not a primitive** — this note is the service/lib boundary and the cross-cutting runtime machinery.

## Sources audited (disposition)
- kels `main`: `services/{kels, sadstore, gossip, registry, mail, identity}`, `lib/{kels, gossip, derive, …}`;
  read in depth — `lib/kels/src/types/{iel,sad}/verification.rs` (tokens), `…/sync.rs` (transfer engine),
  `merge.rs` (merge), `types/deferred_deps.rs` + `services/gossip/src/pending.rs` (deferred-deps),
  `services/gossip/src/sync.rs` (anti-entropy). **Mechanics authoritative; taxonomy (`Cnt`/`Upd`/`Sea`/`Evl`)
  is the old design — do not carry.**
- kels roadmap (`kels#168`) — confirms design-ahead-of-build (many "design landed, code-side follow-up open").
- `vdti-token-store-idea.md`, `vdti-area-federation-witnessing.md` (witnessd's witness role), the SAD spec in
  this repo (custody — already covered, not re-read).
- Memories: `project_vdti_gossip_vs_witness`, `project_kels_transfer_abstractions`, `project_kels_end_verifiability`,
  `project_vdti_event_log_storage_constraint`, `project_vdti_effective_said_synthetics`,
  `feedback_verifier_is_trust_boundary`. ⚠ `project_vdti_compacted_only_submission` is **stale** on `eventsd`/`sadd`
  (§3) — fix.

## 1. Locked-candidate — the architecture

### 1a. Decomposition (mirrors kels; two changes)
- **`lib/vdti`** — the verification/merge/transfer **core**: the three primitive verifiers + their tokens, the
  transfer engine, merge, the policy/IEL resolvers, effective-SAID, deferred-deps types + collect-mode, sadstore
  custody, compaction. **Consumers link this too** (§1b). All correctness lives here; the daemons are plumbing.
- **`vdtid`** — thin daemon: **postgres chain-log + SAD store merged into one service** (kels' `kels`+`sadstore`).
  *Why merged:* events reference SADs by SAID, so a separate SAD store is an extra hop per SAD fetch — **several
  per request**; co-locating kills the hops (and keeps anchor + SAD in one txn). Hosts the API (submit / fetch /
  exists / effective-said), runs merge (advisory lock + DB txn), emits typed-422 deferred-deps.
- **`witnessd`** — kels' **`gossip` service wholesale** (renamed; "gossip" stays the *pattern* name
  [`project_vdti_gossip_vs_witness`]). Holds: gossip propagation, the deferred-deps **park/drain** map, the
  **anti-entropy** loops, and the federation **witness/receipt** role (`vdti-area-federation-witnessing.md` §1e —
  always-witness, by-`(prefix,serial)` selection). Holds HSM witness keys (destruction-on-witnessing) — isolated
  so a compromised `vdtid` can't mint receipts.
- **`clients` (cli, bench)** — build/verify locally with `lib/vdti`; **compact before submit**; maintain the
  client-side **token store** (§1d).
- **Backing stores:** postgres (chain + SAD, behind `vdtid`); Redis (park map + anti-entropy stale-tracking +
  cache, behind `witnessd`).
- **Features (creds / mail / exchange) are libraries** (`lib/vdti/*`), **never `vdtid` modules** — no
  loadable-module support; `vdtid` stays tight. (Whether any feature keeps a thin daemon like kels'
  `registry`/`mail` is §4.)

### 1b. The lib is the spine — *because consumers must verify* [end-verifiability]
End-verifiability means a consumer **cannot trust `vdtid`** — it re-verifies the data itself, with the **same**
verifier. So the verifier must be a **library both `vdtid` and consumers link**, never service-internal. The
token's unforgeability (§1c) + "the DB cannot be trusted" (§1g) mean trust attaches to the **data** (verified),
not the daemon [`feedback_verifier_is_trust_boundary`]. This is the entire reason for the lib/service split.

### 1c. Verification tokens
`KelVerification` / `IelVerification` / `SelVerification` are **unforgeable proof-of-verification** —
constructable **only** by the verifier. Structural problems = **HARD** (halt the walk); auth/policy = **SOFT**
(reported as unsatisfied via the contextual `satisfied`/`queried` sets, not raised — continue); terminal flags (`is_divergent`/`is_decommissioned`) from chain **content**
[inv 9]. **`queried`/`satisfied` SAIDs** = caller-bounded (consumer names the SAIDs it cares about up-front;
`satisfied` = anchored ∧ authorized ∧ before the divergence cut = valid-for-binding) [inv 8]. **`resume`** =
incremental re-hydration from a prior token. Tokens **compose**: a SEL resolves its IEL binding by consuming the
IEL token's `policy_history` + `satisfied_saids`, not by re-walking.

### 1d. Token store — vdti's refinement over kels' re-verify-every-write
Cache tokens keyed by prefix (tip SAID encoded); on use, compare the token's **full pinned-dependency
effective-SAID set** — the chain's own **and every chain it transitively pins** (the KEL(s) beneath an IEL, the
IEL beneath a SEL): **all match → reuse** (no walk); **any moved → `since`-query the new events + `resume`**
(incremental, not a re-walk). **Transitive is load-bearing (F5, 2026-06-20):** a lower-layer `Rec` breaks an
upper event while the upper chain's *own* effective-SAID doesn't move — only the transitive check catches it
(the warm-cache path for the cross-layer cascade). This **refines** "DB cannot be trusted" — the effective-SAID
is the cheap integrity gate; any tamper/advance **moves it** → re-verify. **Freshness, made *detectable* (F8,
2026-06-20):** a to-tip loss-of-trust decision (rescission / revocation / withdrawal) must use a **witnessed /
multi-source** effective-SAID (a single server can report a stale one to hide a revocation) — and the token
carries that **provenance** (single-source vs witnessed, as-of-when) as contextual info [inv 9], so "this decision
used insufficient-freshness data" is **detectable** — and when it can't be multi-source-confirmed the decision **fails-secure: REFUSE**, never proceeds on the flag (cold-5 C2, inv 8). Not a mere prose obligation. Non-to-tip / resolving checks: a
plain single-source comparison is fine.
- **Freshness composes over the whole transitive set (F-E, 2026-06-21).** The multi-source bar above is **not**
  per-"the chain" — it applies to **every chain the token transitively pins** (cred · issuer · *every* delegator
  above it · the devices beneath each identity). A single stale source on **any** one of them can hide a
  revocation, so a loss-of-trust decision confirms *each* dependency's effective-SAID multi-source (a witnessed
  effective-SAID *is* multi-source → cheap; an unwitnessed dependency **can't meet the bar → the decision fails-secure: REFUSE**, cold-5 C2). **"Is
  this chain forked / disputed?" is itself a loss-of-trust question** (a one-branch holder sees a normal
  tip; only the federation signal reveals the fork) → it goes in the multi-source bucket. And **`resume` re-runs
  the to-tip negative checks** (revocation / rescission / divergence) against the new tip whenever any pinned chain
  moves — never just staple on newer events, or it advances past a revocation. (So F9's cross-layer-break
  detection is F5+F8 over the full set, not a separate mechanism.) [inv 8]
- **Freshness is a wall-clock overlay, recomputed at decision-time (cold-12 F1).** The effective-SAID-movement gate
  certifies **structure** (unchanged ⇒ skip the re-walk); it does **not** certify **freshness**. The federation
  staleness / 365-day key-window auto-expiry (federation §1f) is **time-triggered** — it fires with **zero chain
  events**, so nothing *moves* and a movement-only reuse path would miss it. So the token caches the **freshest-valid
  witnessing-time** (data), **never** a cached `fresh`/`stale` *verdict* (which is `now`-dependent), and **every
  loss-of-trust decision recomputes staleness against current `now`** (the §1f staleness threshold + the 365-day
  auto-expiry), **independent of** whether any effective-SAID moved. A token cached pre-lapse therefore reads **stale at
  decision-time** (its witnessing-time is now ancient) → **fail-secure REFUSE**, never a reused pre-lapse 'fresh'
  verdict. (The staleness *machinery* already exists, §1f; this names the **cache/reuse** path so it can't skip the
  wall-clock re-check.)

### 1e. Effective-SAID — a state-encoding digest (can be **synthetic**)
- **Active / decommissioned** → the **real tip** SAID (single canonical tip; **no `decommissioned:` synthetic**).
- **Divergent (per-node local)** → recomputable synthetic `hash("forked:" + prefix)` — computed **when you hold
  ≥ 2 branches** (no single tip).
  **R4 caveat (reworded 2026-06-21): the synthetic is branch-*agnostic*, so it can mask a missing branch *after*
  detection.** Once two nodes have **each detected the divergence** (each holds ≥ 2 branches → each computes
  `forked:`) but they **retain disjoint branch-event-sets** (each pruned what the other kept), the §1i
  anti-entropy effective-SAID compare reads "in sync" and **does not exchange the missing branch events**. So
  **anti-entropy suffices for *detection* but not for assembling all branches for *repair*** — the repairer must
  **explicitly fetch all branches**. (Detection itself is safe: a *single*-branch holder is in the **Active** state
  and computes that branch's **real tip**, so two single-branch holders compute **different** tips → anti-entropy
  **does** converge them *pre*-detection; and the beacon propagates the competing branches
  regardless.) Divergent chains are frozen, so no content is lost.
- **Disputed (data-local)** → synthetic `hash("disputed:" + prefix)`, **computed by any verifier** from the retained
  branches: a branch-level walk finds ≥ 2 branches each carrying a privileged event past the fork (inv 13/17). A
  one-branch holder reaches it via keep-all-data + the **witness beacon**, which enumerates the competing branch
  SAIDs so the holder fetches and walks them — the beacon **propagates**, it does not pronounce. A fork whose
  branches are all content is **recoverable**, not this.
- Synthetics are **concatenation-then-hash** (`hash("<state>:" + prefix)`), **not** keyed-hashing — algorithm-
  portable (keyed mode pins us to a blake3 feature). ("contested"/"irreconcilable" are dead terms for *disputed*; F2.)
  - **Domain-separation is load-bearing (LF8a, 2026-06-21):** the concatenation is unambiguous **only** because the
    synthetic input space (`"<state>:" + prefix`, a lowercase state tag + a type-qualified-base64 prefix) is
    **disjoint** from any real SAD serialization (a JSON object, `{`-leading) and from each other (distinct state
    tags). State this as a requirement: a real-SAD digest can never collide with a synthetic, and the two state
    synthetics can never collide — if a future event encoding isn't `{`-leading JSON, revisit. (Otherwise use a
    tag that provably can't begin a SAD serialization.)
The comparison therefore catches **state transitions** (active→divergent flips the SAID), and two nodes agree on the
synthetic regardless of which branch each holds. **`forked` and `disputed` are distinct states** — per-node state
stays {Active, Divergent, Decommissioned}; `disputed` is the **data-local** terminal determination (≥ 2 privileged
branches, walk-found), not a fourth per-node state. Computing it from the retained branches (the beacon delivers a
missing branch) — rather than as a federation attestation — is what lets §1d's freshness bar rest on the data, not
on an unbuilt witnessing layer. **This digest is the universal "has state
changed?" comparison** behind token-reuse, deferred-deps drain, anti-entropy, and divergence.
[memory: `project_kels_effective_said_synthetics` §vdti]

### 1f. The transfer engine — the one sanctioned data-mover
One `transfer_*_events` walk with swappable **source / sink / verifier**: `verify_*` = +verifier, `forward_*` =
sink-only (no verify), `verify_*_with` = streaming callback. Source-agnostic (paged-source trait). **Merge,
anti-entropy sync, deferred-deps replay, local-verify, and CLI streaming all reuse it.** Manual pagination
bypasses tamper-evidence — forbidden [`project_kels_transfer_abstractions`].

### 1g. Merge — the write path
`vdtid` submit → fast sig-check → **merge** (advisory lock + DB txn): re-verify (or `resume` from a cached token
gated by effective-SAID, §1d) → route **normal-append** (~99%, linear non-divergent) / **new-chain** /
**full-path** (divergence / recovery / archival). **Never trusts the DB** — verification is recomputed, not cached
as trust, except behind the effective-SAID gate.

### 1h. Deferred-deps — the cross-chain race
An event can arrive before a dependency on **another** chain (independent gossip). Flow: verifier **collect-mode**
accumulates deferrable failures (`MissingIelEvent`/`MissingKelAnchor`/`MissingSadObject`) and continues soft →
`vdtid` emits a **typed 422** (`DeferredDepsResponse`: the missing deps each tagged with the dep chain's
`chainEffSaid`, plus `transientChainState` synthetics for forked/disputed) → **`witnessd` parks** the message
in Redis (`pending:msg/said/chain`, **secondaries-before-primary** so a crash orphans a self-TTLing primary, never
dangling indexes) → **drains** (replays via the transfer engine / get-post-sad) when the awaited dep commits
(pubsub) or the chain's effective-SAID moves past `eff_said_at_park`.

### 1i. Anti-entropy — silent-divergence repair
`witnessd` periodic loops (per primitive — KEL/SAD/IEL): **Phase 1 targeted** (known-stale prefixes in a Redis
hash → query peers' effective-SAIDs → sync only from peers that differ) and **Phase 2 random sampling** (random
page vs random peer; skipped if Phase 1 had work). The **effective-SAID is the compare key**; sync moves through
the transfer engine.

## 2. Mined from kels (carries; confirm in build)
- Redis park-map **write-order invariant** (secondaries before primary; `DepRef` variant order is load-bearing
  for park-record SAID determinism — don't reorder).
- The per-primitive `verify` / `forward` / `verify_*_with` / `collect_*_saids` API surface.
- `compute_prefix_effective_said`; the post-merge cache-update + pubsub-publish path.
- Advisory-lock + single-txn-per-merge discipline; fast upfront sig/structure rejection before the lock.

## 3. Superseded — do NOT carry forward
- **The `eventsd` / `sadd` split** (vdti's *own earlier* conception, mirroring kels' `kels`/`sadstore`) →
  **merged into `vdtid`** (read-path hops, §1a). ⚠ fix `project_vdti_compacted_only_submission`.
- **kels' separate `registry` / `mail` / `identity` daemons + old taxonomy** (`Cnt`/`Upd`/`Sea`/`Evl`,
  `is_contested`) → vdti features are **libs**; taxonomy is the reshape's (`Icp`/`Ixn`/`Evl`/`Rec`/…, no `Cnt`).
- **kels' re-verify-every-write** (`completed_verification` each submit) → vdti **token-cache + effective-SAID +
  `resume`** (§1d). The kels code is the correctness baseline; the cache is the scale refinement.
- **"gossip" as a service name** → `witnessd` ("gossip" stays the pattern name).

## 4. Open / route to the adversarial pass
- **`vdtid` ↔ `witnessd` transport** — kels uses HTTP between `gossip` and `kels` services. Keep HTTP, or
  local IPC? (Affects the typed-422 / park / replay path.)
- **Redis** for park map / stale-tracking / cache — kels' choice. Carry, or reconsider a single backing store?
- **The witnessed effective-SAID source** for to-tip consuming decisions (§1d caveat) — exactly how a consumer
  obtains a federation-gossiped / multi-source effective-SAID. Cross-ref `vdti-area-federation-witnessing.md`.
- **Feature daemons** — do any features keep a thin daemon (kels `registry`/`mail` shape), or are all features
  purely client-side libs over `vdtid`? Jason leaned **tight**; confirm "no feature daemons."

## 5. Drift → land backlog
- Write the services/architecture doc under `docs/design/` (the `lib/vdti` + `vdtid` + `witnessd` boundary, the
  effective-SAID/transfer-engine spine, deferred-deps, anti-entropy).
- Define the `lib/vdti` crate layout (verifiers/tokens, transfer, merge, resolvers, effective-SAID, deferred-deps,
  custody, compaction) + the thin `vdtid`/`witnessd`/`cli` binaries.
- **Fix `project_vdti_compacted_only_submission`** (`eventsd`/`sadd` → `vdtid` + `witnessd`).
- **Archived-aware fetch (repair-archived content).** `vdtid`'s fetch endpoint must expose **archived** events
  (kels' `get_archived_events` / `get_recovery_archived_events` shape), so a walk that returns the full
  graph/history also surfaces events archived by a **repair** (a divergence cascade archives the losing branch).
  *(Updated 2026-06-21: this is no longer for detecting a delayed un-rescind — kills are always sealed now, there
  is no un-rescind, see `vdti-area-sel.md` §1. The endpoint stays for repair-archived content.)*

## 6. Confidence / what's owed
- §1a–§1i — **high** on the decomposition + machinery (grounded in the kels `main` code + Jason's decisions). The
  *mechanics* are battle-tested; vdti's deltas (merge chain+SAD, token-cache refinement, witnessd rename) are
  Jason-confirmed.
- §4 — transport + backing-store choices are confirmables, not blockers.
- Owed: Jason's confirm on §4; the build itself (this note is the map, not the territory).
