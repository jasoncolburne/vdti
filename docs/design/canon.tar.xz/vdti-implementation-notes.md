# VDTI — implementation notes

Build-shaping decisions that constrain the implementation but are **not** doctrine (they don't belong
in `docs/design/`, which states product-agnostic structural rules). Concise; one entry per decision.
Doctrine is the leading edge — these follow it.

## Storage

- **Event logs are Postgres.** Structured / variable-length data never inlines in an event body; it
  lives in a SAD referenced by a scalar SAID (the `manifest` SADs, `pin`, the roster/witnesses/clock
  config SADs). See `project_vdti_event_log_storage_constraint`.
- **Witness receipts: flat Postgres rows, keyed by `(prefix, serial)`.** A receipt is a single
  witness signature over `(prefix, serial, event-said)` — small and flat — so payload + index sit in
  one table; serving a page's receipts is one index scan, no second fetch. Fall back to **SAD storage
  + a thin-pointer table** (`(prefix, serial) → receipt-SAID`) **only if** receipts grow non-flat
  (aggregated/batched, or referencing a SAD). We are not in that case yet.
- **Serving bundles receipts with the page.** The server serves a chain page **with** its receipts
  (cheap index scan, no verification — never trust the DB); the verifier re-checks signatures. Don't
  push the *lookup* to the verifier: the divergence model needs a one-branch holder to get the
  competing-branch SAIDs from the receipts, so a separate round-trip would add detection latency.

## Inter-node transport

- **All inter-node mesh traffic is encrypted** (`ML-KEM-1024` KEM + `AES-256-GCM` AEAD) — receipts
  and the events they propagate alike. The mesh is the federation roster. This is **confidentiality**,
  not trust (trust is end-verifiable: SAIDs + sigs survive any transport); it closes the
  metadata/correlation residuals (inv 16). The KEM/AEAD mechanism already exists in `../kels` for
  gossip; extend it to the data path.
- **The mesh-encryption key lives in a per-witness key SEL (RESOLVED 2026-06-26 — was the S-E / `Fcp`
  open item).** The `ML-KEM-1024` public key sits in a SEL owned by a **degenerate per-device IEL** — a
  single-member IEL (`members = [the witness KEL]`) **derived from the witness KEL prefix** (+ a purpose
  discriminator), not separately incepted, so it does **not** break the `Fcp` founder bootstrap (the
  device KEL incepts first via `Fcp`, its degenerate IEL derives, that IEL owns the key SEL; "reincept"
  = re-derive from the recovered KEL). Its kind set excludes `Evl` (≈ `{Icp, Ixn, Rpr, Dec}`), and the general **post-delta `|roster| ≥ 1`** rule (inv 12) forbids cutting the sole
  member (a `Rpr`-cut — the other roster-mutating kind since the 2026-06-30 fold — computes `1 + 0 − 1 = 0`,
  rejected), so it can neither grow (no `Evl`) nor shrink → roster immutable (no new field; singleton → all
  thresholds 1). Discovery: federation roster
  → witness KEL prefixes → derive each degenerate IEL → its key SEL. See
  `vdti-area-federation-witnessing.md` §1e.
- **Push over pull.** Prefer gossiping events (push, over the encrypted mesh) to a separate inter-node
  *query* — then there is no second channel to secure, and a one-branch holder receives competing
  branches by push rather than a detection-time fetch (the sub-mesh event-gossip already does this for
  selected witnesses; extend it). The residual by-prefix fetch (a node genuinely missing a dep)
  shrinks rather than vanishes, and rides the same encrypted mesh.
- **POST the prefix, never the request line.** Every prefix-bearing query is a POST with the prefix in
  the body — a path/query prefix leaks into common access/proxy logs (inv 16). Only POSTs.

## Merge / locking

- **Advisory locking on all log-prefix operations.** Verify-then-write paths hold a **database
  advisory lock** (the `../kels` pattern: `pg_advisory_lock` keyed by prefix) for the duration of both
  verification and write — verify the existing chain under the lock, obtain a trusted token, verify
  the incoming events against it, write, never re-querying the DB between verify and use. Doctrine
  names the *mechanism* (advisory lock); the Postgres specifics live here.
