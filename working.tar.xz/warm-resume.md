# warm-resume — warm-session context restore (post-compaction)

**This is the WARM session's resume. Never hand it to a cold pass** (asymmetric decorrelation:
warm gets everything, cold gets nothing — memory `feedback_dual_review_protocol`).

**Canon load: WHEN A BRIEF IS IN HAND, not at resume (standing, Jason 2026-07-03).** As the warm
reviewer you need a primed context — that priming IS what makes the warm pass warm. But the canon
may move between rounds, so front-loading it at resume wastes tokens on priming that goes stale;
load it fresh at the moment a brief arrives. **The canon lives at `docs/canon/`** (moved from
`.working/` 2026-07-04; `.working/` now holds only working-surface files — resumes, briefs,
findings, index, roadmap, archived/): read from disk the whole canon
(`vdti-repair-completeness-proof.md`, `vdti-invariants.md`, `vdti-implementation-notes.md`, all
`vdti-area-*.md`, `vdti-federation-inception-reference.md` — all under `docs/canon/`). Do **not**
load the landed `docs/design/` tree up front — canon and landed docs are two encodings of ONE
design; only one set belongs in memory, and **canon is canonical** (docs are re-read per-brief as
review evidence, when a brief requires them or Jason asks). The canon is greenfield-**exempt** (it
records decision evolution — "was `Del`" definitions etc.); the landed `docs/` tree is greenfield.
Jason overrides with a note when he wants otherwise.

**Maintenance (standing, Jason 2026-07-02): update this file at the end of every review round** —
verdict delivered ⇒ refresh arc state / open items here, same-turn (the warm twin of
`design-resume.md`). Standing rules live in project memory (auto-loaded); this file carries
**arc state only**. For reasoning detail the compaction summary lost, grep the prior transcript:
`/Users/jason/.claude/projects/-Users-jason-github-com-jasoncolburne-vdti/a98d268e-b7e9-4ad1-bfb6-51fb9c87edd3.jsonl`.
Re-read every file from disk each round regardless — this file is orientation, never evidence.

## Role

Warm (contextual) reviewer, one effort level up, in Jason's hand-coordinated dual-pass topology.
Jason drives all design decisions and all git. A brief arrives as a `.working/*.md` path each
turn; findings go to the brief-named file — MERGE / HOLD-N at top, tagged findings, quoted
doc:line, `make all` exit 0 as a done-gate, edit nothing while reviewing. Warm sees prior cold
output by design (passes run simultaneously, so the in-flight cold is invisible by timing only);
derive findings independently, then state where cold would converge as a shared-blind-spot flag.

## Arc state (2026-07-04, HEAD `61890e5` + the staged taxonomy refactor — review target was the staged tree)

- **THE TAXONOMY (renamed 2026-07-04 — memorized names are STALE; use these).** `Del` → **`Ath`**
  (authorize, T2 `t_authorize` — two roles at once: `delegates` for act-for-delegator, `anchors` →
  the new SEL **`Gnt`** doc-membership grant for act-as-self); `Kil` → split **`Rev`** (revoke an
  owned artifact, `t_govern`) + **`Dth`** (deauthorize a grant, `t_authorize`) — the `threshold`
  slot-name field is retired, every kind prices from exactly one slot; `Dec` → **`Trm`**
  (terminate), chain state `Decommissioned` → **`Terminated`**; `t_delegate` → **`t_authorize`**.
  Kind counts: KEL 8 (`Fcp`/`Icp`/`Ixn`/`Rot`/`Ror`/`Rec`/`Wit`/`Trm`), IEL 9
  (`Icp`/`Ixn`/`Evl`/`Ath`/`Rev`/`Dth`/`Rpr`/`Trm`/`Wit`), SEL 7
  (`Icp`/`Ixn`/`Gnt`/`Trm`/`Pin`/`Fld`/`Rpr`). Anchor matrix (five pairs): `Ixn`↔content,
  `Evl`↔`Fld`, `Ath`↔`Gnt`, `Rev`/`Dth`↔`Trm` (discriminated by SEL type — the total rule:
  `Dth` iff authorization-rescission (delegation or doc-membership), `Rev` otherwise), `Rpr`↔`Rpr`.
  `Gnt` is privileged/seal-advancing/non-archivable (walk back = rescind forward via `Dth`).
- **CURRENT ROUND — taxonomy encode review: my verdict HOLD-with-findings (2026-07-04, findings
  `.working/vdti-taxonomy-encode-review-warm-findings.md`), awaiting the fold.** Design confirmed
  sound (grant-tier T2 argument coherent; no S1 from the `Ath` two-role merge; total rule right;
  divergence semantics survived — `{Rev|Dth, content}` reconcilable, only `Trm` terminal-tip; slot
  genuinely retired). All four MAJORs are sweep-residue, ~10 lines total: **W1** inv 4's `anchors`
  carrier list omits `Ath` (invariants:52 — contradicts its own :138 matrix + area-iel + event-shape);
  **W2** the SEL seal-advancer set omits `Gnt` at four sites (protocol-doctrine:296 +
  area-sel:110/:116/:189 — would un-privilege the grant; event-shape:174/:268 + glossary have it
  right); **W3** event-shape:440-442 routes a credential-SEL `Trm` through `Dth` and says "`govern`
  slot" (contradicts the total rule everywhere; the sharpest landed error); **W4** event-shape's SEL
  validation table (:347-354) + kind-code list (:456) omit `Gnt` entirely. MINORs W5–W10 (`@authorize`
  notation residue; inv 13 recovery enumerations not swept for `Ath`; threshold-declaration map missing
  `Rev`/`Dth`; dangling deleted-column cells in event-shape tables incl. a stray `fbd` on the IEL `Wit`
  row; glossary conflates verdicts with per-node states; system-thesis glosses `t_authorize` as
  "delegation") + N1–3. Brief-vs-files note: files consistently say KEL **8** (brief said 7 — brief's
  slip). `make all` 0 (508 xrefs / 44 files).
- **Multi-party documents, SECOND CUT — my HOLD-4 is FOLDED (2026-07-04).** The 2nd-cut note
  (`docs/canon/vdti-area-multi-party-documents.md`) absorbed all of F1–F15+N1–3: rescission keying is
  now `hash(G | said_b)` (participant-blind AND grant-blind — the F1 fix done properly), the nonce
  rule landed for every gated doc on public structure (F2), DAG-descent is derived as a placement
  consequence with structural language (F3), the honored predicate carries the inv-8 freshness bar
  (F4), grants became **T2 `Gnt` ← `Ath`** (resolving my F13 constraint properly — the taxonomy
  refactor was the mechanism), disjoint-periods at doc-validation, `MAX_GRANT_ADDS = 64`,
  reserved-name convention `vdti/doc/v1/...`, custody.md backport noted at §8. Editors/commenters
  role split (view/comment/edit triad); comments mechanism deferred. Nothing outstanding from that
  round; findings file archived.

- **Prior arc (convergence / effective-SAID) — SETTLED + FOLDED, warm fold re-review WAIVED.** The
  live-tips + pure-walk + gate-in-both-modes model is canon (inv 13 F-F, inv 17, vdtid-services
  §1e/§1i, fed §1e gate bullet) and landed (`e369180`): pure-walk reading with a DERIVED seal
  ("frozen" = origination posture only; a content fork resolves by `Rec` OR a burying
  seal-advancer; identical held sets ⇒ identical reading + digest — verified both arrival orders),
  live-tips digest (settled content drops out, privileged never settles), shape-validity gate at
  the acceptance point in both modes. My re-encode HOLD-4 (Matrix-2 burial cells; system-thesis
  freeze section; derived-seal rule pinning; `Dec`-burial seam + L1–L5) was **folded in
  `47d98af`..`ef8539f`** (residue removal, polish, SAID/prefix rationale, glossary + SAD mods,
  canon/working-surface sync) — **Jason waived the warm re-review of that fold** (2026-07-04; canon
  was expected to keep moving). Digest-model history (one day, three generations): seal-relative
  `4beb456` (HOLD-2) → all-tips `fc6c91b`+`5119814` (HOLD-2 + my adjudication of the cold findings)
  → **live-tips + pure-walk** (Jason's fix — kels recall; reviewed HOLD-4, folded). Nothing
  outstanding from that arc; both convergence findings files are archive-ready.

## Prior arc state (content-fork prevention, settled + encoded)

- **Content-fork prevention — SETTLED, ENCODED, REVIEWED, POLISHED.** The model: witness-config
  **majority floor `threshold > signers/2`** + the kind-scoped witnessing ladder (content
  first-seen, one sibling per `(prefix, serial)`; privileged up to **two** per position — two
  both-witnessed siblings ARE the `disputed` proof; the resolving repair = the first privileged
  sibling, no separate clause) ⇒ **content forks on witnessed chains are prevented below
  fork-cost `2·threshold − signers`** (a priced dial: `fork-cost = threshold − slack`;
  double-signing attributable). Option (b): user-IEL content gated at its own position alongside
  Q1 anchors; federation IEL exempt; SEL rides the cross-layer theorem. Counting is
  **selection-scoped**. Recoverability cap **`threshold ≤ min(|roster| − 2, signers − 1)`**,
  `signers = 1` waiver ({1,1} evict-one = position-luck, warned); re-check on **any
  config-changing `Wit`** (incl. config-only). **Single-add federation `Wit`** (`add` scalar,
  `Fcp` exempt, `cut` a list). **`forks` → `fork`** (one root; unnamed branches close below-seal +
  by-descent — verified closure equivalence). Serialization: governance safety-critical
  everywhere; content-rail = liveness on witnessed chains, safety-critical direct-mode/solo.
  Propagation premise = success-rate/latency only, never safety. §1a reachability property
  verified (one `Wit` carries the full config delta → no forced invalid intermediates).
- **My verdicts this arc (all archived):** majority-quorum canon review **HOLD-2** → fold review
  **MERGE** (both Fable completions verified: waiver necessary+honest; collapse
  outcome-identical) → encode review **MERGE** (clusters A–J faithful; manifest independently
  clean incl. sad/policy/diagram; no cross-doc contradiction). Cold ran HOLD-11 on the canon
  round; its seam findings (config-transition F1, single-add P5) landed as the canon seam layer.
- **All my open findings are folded** (verified from disk 2026-07-03): the four fold-review LOWs
  (proof premise now lists the roster-delta straddle; area-fed elliptical bounds fixed;
  first-seen naming unified — 0 "first-receive" hits; area-sel has the transitive fork-cost
  note) and ALL of encode F1–F5 in `89f74cd` — F1 (content-rail uniformly "safety-critical on
  direct-mode") and the F2–F5 de-dup collapses exactly as recommended (verification's FORCE
  content-leg → split + §Federation-convergence ref; event-shape's witnesses/bounds/roster rows →
  shape/bound + ref, rationale prose removed). The "(verify at review)" tag is resolved out of
  area-fed.
- **Commit sequence (this layer):** `fbc62eb` majority-quorum canon → `a3e371e` re-encode landed
  design → `89f74cd` review polish → `5a5932b` **new `docs/design/README.md`** (reading-order map —
  I have not reviewed it) → `4b6c62c` clarify reconciliation.md → `b526dd3` SiblingLocked/retention
  split → `4beb456` **Eliminate synthetic SAIDs** (seal-relative digest; reviewed HOLD-2) →
  `fc6c91b`+`5119814` **all-tips** (reviewed HOLD-2) → `e369180` **Separation of duties
  (merge/persist)** = the live-tips + pure-walk re-encode (reviewed HOLD-4) → `47d98af`..`ef8539f`
  the fold + polish/glossary/custody layer (warm fold re-review waived by Jason, 2026-07-04).
- **Repair-completeness model (settled r1–r5, re-scoped to the residual):** root-pointing
  (`fork` = one root condemning its subtree) + deadness-descends (same-chain + **IEL→SEL anchor
  edge only**) + bounded fork (depth ≤ 64/lineage; retention ≥ 2/position; the ladder) + two
  guards (no-self-condemnation over the full-span walk — tight form
  `root.parent = v_{d-1} ∧ root ∉ walkback` in impl-notes; content-only) + retain-and-count
  (scoped: passes hard auth, fails content-only; junk dropped) + `{Dec, content}` tier-rank +
  D1 two-valued finality (no-resurrection unconditional; resolution-stability gated;
  residuals: eclipse + historical reserve compromise + withheld-body split + roster-delta
  straddle) + cross-layer theorem (valid SEL fork ⇒ IEL fork; anchor-monotonicity with
  skip-unattributable). Runs against the residual population (direct-mode, fork-cost byzantine,
  straddles, split-stalls, mixed races).
- **Canon:** `.working/vdti-repair-completeness-proof.md`, `vdti-invariants.md` (inv 4/12/13/14/17),
  `vdti-area-{kel,iel,sel,federation-witnessing}.md`, `vdti-implementation-notes.md`. **Landed:**
  protocol-doctrine, system-thesis, **design/README.md (new)**, event-shape, six `kel/` docs,
  sad/ + policy/ trees, `docs/.terminology-forbidden` (root-pointing + fork-scalar bans).

## Open items

- **My taxonomy-encode HOLD awaits the fold:** W1–W4 (MAJOR, ~10 mechanical lines: inv 4 `anchors`
  carrier + `Gnt` into the four SEL seal-set enumerations + event-shape's batching-bullet
  `Rev`/`Dth` fix + the missing `Gnt` validation row/code) then W5–W10 + N1–3. Findings file below;
  a cold pass ran in parallel (same files, no context) — expect overlap on W1–W4
  (fresh-eye-reachable internal contradictions).
- **Unreviewed surfaces:** `docs/design/README.md` (5a5932b) — no review round has covered it yet.
  The convergence-arc fold (`47d98af`..`ef8539f`) landed without a warm re-review (waived).
  A `vdti-protocol-doctrine-freshread-brief.md` sits in `.working/` (a queued round, not yet mine).
- **Deferred in canon (tracked there, not by me):** the `compaction.md`/`said.md` §Rule-1
  SAID-invariance fix (multi-party §7 "Deferred to the encode"); the excalidraw→mermaid re-encoding
  (excalidraw temporarily excluded from terminology lint).

## Pending externally

- Forward-ref'd / unbuilt: `iel/` + `sel/` (the cross-layer bundle lands there),
  `federation/{witnessing,bootstrap}.md`, `operations/{multi-party-governance,recovery-workflow}.md`,
  `features/credentials/`, `infrastructure/vdtid.md`. Full-out design encoding planned after this
  review iteration set.

## My findings files

**Active (round open):** `.working/vdti-taxonomy-encode-review-warm-findings.md`
(HOLD-with-findings, the taxonomy encode round, 2026-07-04). **Closed/absorbed:** the multi-party
second-cut HOLD-4 findings are folded into `docs/canon/vdti-area-multi-party-documents.md` (file no
longer in `.working/` root — migrated with the canon move); both convergence-round findings files
are archived (that arc closed, fold waived).

**Archived (`.working/archived/`):** `vdti-repair-completeness-findings-warm-r{1..5}.md` ·
`vdti-repair-completeness-encode-findings-warm.md` ·
`vdti-doctrine-quality-reverify-canon-findings.md` ·
`vdti-majority-quorum-canon-review-warm-findings.md` ·
`vdti-content-fork-prevention-fold-review-warm-findings.md` ·
`vdti-content-fork-prevention-encode-review-warm-findings.md`.
