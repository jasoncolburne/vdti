# warm-resume — warm-session context restore (post-compaction)

**This is the WARM session's resume. Never hand it to a cold pass** (asymmetric decorrelation:
warm gets everything, cold gets nothing — memory `feedback_dual_review_protocol`).

**On resume: LOAD THE FULL CANON BEFORE BEGINNING (standing, Jason 2026-07-03).** As the warm
reviewer you need a primed context — that priming IS what makes the warm pass warm. Before taking
any brief, read from disk: the whole canon (`vdti-repair-completeness-proof.md`,
`vdti-invariants.md`, `vdti-implementation-notes.md`, all `vdti-area-*.md`). Do **not** load the
landed `docs/design/` tree up front — canon and landed docs are two encodings of ONE design; only
one set belongs in memory, and **canon is canonical** (docs are re-read per-brief as review
evidence, when a brief requires them or Jason asks). This is the default every compaction; Jason
overrides with a note when he wants otherwise.

**Maintenance (standing, Jason 2026-07-02): update this file at the end of every review round** —
verdict delivered ⇒ refresh arc state / open items here, same-turn (the warm twin of
`design-resume.md`). Standing rules live in project memory (auto-loaded); this file carries
**arc state only**. For reasoning detail the compaction summary lost, grep the prior transcript:
`/Users/jason/.claude/projects/-Users-jason-github-com-jasoncolburne-vdti/a98d268e-b7e9-4ad1-bfb6-51fb9c87edd3.jsonl`.
Re-read every file from disk each round regardless — this file is orientation, never evidence.

## Role

Warm (contextual) reviewer, one effort level up, in Jason's hand-coordinated dual-pass topology.
Jason drives all design decisions and all git. A brief arrives as a `.working/*.md` path each
turn; findings go to the brief-named file — MERGE / HOLD-N at top, tagged findings, quoted
doc:line, `make all` exit 0 as a done-gate, edit nothing while reviewing. Warm sees prior cold
output by design (passes run simultaneously, so the in-flight cold is invisible by timing only);
derive findings independently, then state where cold would converge as a shared-blind-spot flag.

## Arc state (2026-07-03, HEAD `5119814` — tree clean)

- **ALL-TIPS effective-SAID — LANDED (canon `fc6c91b` + encode `5119814`), warm encode-review
  returned HOLD-2.** The digest is now a **held-tip fingerprint**: a domain-separated hash over
  **ALL the tips a node holds** (canonical + every retained competing/condemned/dead branch tip) in
  the chain's **active window** (canon; the window qualifier is MISSING from the landed statements —
  my H2). Seal-independent, no subset selection; single tip → its SAID. The `forked`/`disputed`
  verdict is the separate walk, never in the value; **colons dropped** (`forked:`/`disputed:`
  lint-banned). Below-own-seal privileged mint = the eclipse limit, not a digest gap. Anti-entropy:
  digest delta + `since:{own seal}` (response includes the cursor's own siblings); below-window →
  beacon. Replaces the one-day seal-relative digest (prior cold F1/F2 killed it: input-set ambiguity
  + below-seal privileged masking). Prior-round folds all verified landed: cold F3–F13 + my H2
  (diagram) + L1 (ban-file); Matrix-1 gains `Divergent (sealed) × Rec = Recovered ᶜ`; Matrix-2
  header splits canonical outcome vs evidence ingestion; merge outcomes gain `Rejected`.
- **My HOLD-2 this round (`vdti-convergence-encode-review-warm-findings.md`, OUTSTANDING):**
  **H1 [coherence, MED]** — adjudicated the designer's item-6 disposition: the determinism claim
  ("identical event sets yield identical state") is **SOUND — confirm, don't weaken** — under the
  walk-re-derives pinning (end-verifiability forces a pure-function reading; the only adversarially
  sound walk rule is *a content sibling dies once the competing branch carries a seal-advancer above
  the fork* — fork-stays-live would reopen a retroactive fork-DoS). My prior counterexample
  dissolves under that pinning. The DEFECT: acceptance-order sentences survive and contradict it —
  landed §E-S "the reading additionally depends on each node's own seal (which competing event it
  accepted first) … converges as the repair propagates" (:1176-1180), canon §1e "(acceptance
  order)", canon §1i's fork-holder-authors-a-Rec + "only the verdict needs the Rec", reconciliation
  :113 "A Rot doesn't resolve the fork", :649 "on a competing branch" scoping — plus ONE decision
  for Jason: merge admission on a frozen chain for a branch-extending seal-advancer (I recommend
  keep-reject; sync-ingestion + re-derivation resolves the reading anyway per the landed Matrix-2
  ingestion header). **H2 [fidelity, MED]** — the four landed digest statements dropped canon §1e's
  **active-window** scoping; "all held tips" + the below-own-seal carve-out are jointly inconsistent
  without it (and it's what makes the digest bounded + seal-independent + order-free at once).
  **L1 [de-dup, LOW]** — reconciliation:113 still reads "over its at-or-above-seal competing tips"
  (retired input formula, sole tree survivor). **L2 [consistency, LOW]** — Matrix-2 ingestion header
  unqualified vs witnessing-gated retention. Everything else verified clean; `make all` 0.

## Prior round (seal-relative digest — retired same-day by the all-tips rework)

- **Convergence cluster (synthetics retirement) — landed `4beb456`, warm encode-review HOLD-2.**
  The model: effective-SAID synthetics (`hash("forked:"/"disputed:" + prefix)`) are **retired** for
  a **real branch-derived digest** — single canonical tip → the tip SAID; live fork → a
  deterministic, domain-separated hash over the sorted held **at-or-above-seal** competing tips
  (input set pinned to the mandatory retained-evidence floor; decided-dead evidence excluded;
  fork-at-seal counts, sealed-past loser → **Active**); `forked`/`disputed` survive as the
  **walk verdict only**, never the value. Anti-entropy = two channels: above-your-own-seal via the
  digest delta + `since: {own-last-seal}.said` fetch (pull); below-own-seal + decided-dead via
  push/beacon only. Convergence **conditional on propagation** (fail-secure under partition).
  `MINIMUM_PAGE_SIZE = 129 = 2·64 + 1`; cap `(MINIMUM_PAGE_SIZE − 1)/2 = 64` **per lineage** (the
  page carries both fork branches + the `Rec` for source→sink transfer; own-`Rot`-tail and
  ≥ 3-branch shapes ride other pages). reconciliation.md reworked (Divergent (sealed) = the
  fork-AT-the-seal state; `rec.previous = seal.said`; Matrix 2 Recovered→Divergent = Recovered
  guarded; Matrix 4). Canon home: vdtid-services §1e/§1i; the canon-round cold review (GO-with-fixes,
  F1–F6) is folded.
- **My prior HOLD-2 (archived findings) — how it resolved:** H2 (diagram synthetic caption) + L1
  (ban-file comment) folded in `5119814`; H1 (determinism claims) NOT folded — the designer disputed
  it with the walk-re-derives disposition and the all-tips rework, and this round's brief item 6
  sent it back to me for independent adjudication (see the current round above: confirmed sound;
  the residue sentences are the new H1).

## Prior arc state (content-fork prevention, settled + encoded)

- **Content-fork prevention — SETTLED, ENCODED, REVIEWED, POLISHED.** The model: witness-config
  **majority floor `threshold > signers/2`** + the kind-scoped witnessing ladder (content
  first-seen, one sibling per `(prefix, serial)`; privileged up to **two** per position — two
  both-witnessed siblings ARE the `disputed` proof; the resolving repair = the first privileged
  sibling, no separate clause) ⇒ **content forks on witnessed chains are prevented below
  fork-cost `2·threshold − signers`** (a priced dial: `fork-cost = threshold − slack`;
  double-signing attributable). Option (b): user-IEL content gated at its own position alongside
  Q1 anchors; federation IEL exempt; SEL rides the cross-layer theorem. Counting is
  **selection-scoped**. Recoverability cap **`threshold ≤ min(|roster| − 2, signers − 1)`**,
  `signers = 1` waiver ({1,1} evict-one = position-luck, warned); re-check on **any
  config-changing `Wit`** (incl. config-only). **Single-add federation `Wit`** (`add` scalar,
  `Fcp` exempt, `cut` a list). **`forks` → `fork`** (one root; unnamed branches close below-seal +
  by-descent — verified closure equivalence). Serialization: governance safety-critical
  everywhere; content-rail = liveness on witnessed chains, safety-critical direct-mode/solo.
  Propagation premise = success-rate/latency only, never safety. §1a reachability property
  verified (one `Wit` carries the full config delta → no forced invalid intermediates).
- **My verdicts this arc (all archived):** majority-quorum canon review **HOLD-2** → fold review
  **MERGE** (both Fable completions verified: waiver necessary+honest; collapse
  outcome-identical) → encode review **MERGE** (clusters A–J faithful; manifest independently
  clean incl. sad/policy/diagram; no cross-doc contradiction). Cold ran HOLD-11 on the canon
  round; its seam findings (config-transition F1, single-add P5) landed as the canon seam layer.
- **All my open findings are folded** (verified from disk 2026-07-03): the four fold-review LOWs
  (proof premise now lists the roster-delta straddle; area-fed elliptical bounds fixed;
  first-seen naming unified — 0 "first-receive" hits; area-sel has the transitive fork-cost
  note) and ALL of encode F1–F5 in `89f74cd` — F1 (content-rail uniformly "safety-critical on
  direct-mode") and the F2–F5 de-dup collapses exactly as recommended (verification's FORCE
  content-leg → split + §Federation-convergence ref; event-shape's witnesses/bounds/roster rows →
  shape/bound + ref, rationale prose removed). The "(verify at review)" tag is resolved out of
  area-fed.
- **Commit sequence (this layer):** `fbc62eb` majority-quorum canon → `a3e371e` re-encode landed
  design → `89f74cd` review polish → `5a5932b` **new `docs/design/README.md`** (reading-order map —
  I have not reviewed it) → `4b6c62c` clarify reconciliation.md → `b526dd3` SiblingLocked/retention
  split → `4beb456` **Eliminate synthetic SAIDs** (the convergence encode: reconciliation.md rework
  bundled with the implementer's verification/protocol-doctrine/events/merge/log pass — the round I
  reviewed HOLD-2).
- **Repair-completeness model (settled r1–r5, re-scoped to the residual):** root-pointing
  (`fork` = one root condemning its subtree) + deadness-descends (same-chain + **IEL→SEL anchor
  edge only**) + bounded fork (depth ≤ 64/lineage; retention ≥ 2/position; the ladder) + two
  guards (no-self-condemnation over the full-span walk — tight form
  `root.parent = v_{d-1} ∧ root ∉ walkback` in impl-notes; content-only) + retain-and-count
  (scoped: passes hard auth, fails content-only; junk dropped) + `{Dec, content}` tier-rank +
  D1 two-valued finality (no-resurrection unconditional; resolution-stability gated;
  residuals: eclipse + historical reserve compromise + withheld-body split + roster-delta
  straddle) + cross-layer theorem (valid SEL fork ⇒ IEL fork; anchor-monotonicity with
  skip-unattributable). Runs against the residual population (direct-mode, fork-cost byzantine,
  straddles, split-stalls, mixed races).
- **Canon:** `.working/vdti-repair-completeness-proof.md`, `vdti-invariants.md` (inv 4/12/13/14/17),
  `vdti-area-{kel,iel,sel,federation-witnessing}.md`, `vdti-implementation-notes.md`. **Landed:**
  protocol-doctrine, system-thesis, **design/README.md (new)**, event-shape, six `kel/` docs,
  sad/ + policy/ trees, `docs/.terminology-forbidden` (root-pointing + fork-scalar bans).

## Open items

- **My HOLD-2 (all-tips encode round) awaits the fold:** H1 — confirm the walk-re-derives pinning +
  reconcile the acceptance-order sentence set (landed §E-S :1176-1180; canon §1e/§1i; reconciliation
  :113/:649) + Jason's frozen-chain merge-admission decision; H2 — active-window qualifier at the
  four landed digest statements; L1/L2 riders. Findings file above; re-review on the fold brief.
- **Unreviewed surfaces:** `docs/design/README.md` (5a5932b) — no review round has covered it yet.

## Pending externally

- Forward-ref'd / unbuilt: `iel/` + `sel/` (the cross-layer bundle lands there),
  `federation/{witnessing,bootstrap}.md`, `operations/{multi-party-governance,recovery-workflow}.md`,
  `features/credentials/`, `infrastructure/vdtid.md`. Full-out design encoding planned after this
  review iteration set.

## My findings files

**Active (round open):** `vdti-convergence-encode-review-warm-findings.md` (HOLD-2, the ALL-TIPS
round, 2026-07-03 — overwrote the archived seal-relative-round file of the same name).

**Archived (`.working/archived/`):** `vdti-repair-completeness-findings-warm-r{1..5}.md` ·
`vdti-repair-completeness-encode-findings-warm.md` ·
`vdti-doctrine-quality-reverify-canon-findings.md` ·
`vdti-majority-quorum-canon-review-warm-findings.md` ·
`vdti-content-fork-prevention-fold-review-warm-findings.md` ·
`vdti-content-fork-prevention-encode-review-warm-findings.md`.
