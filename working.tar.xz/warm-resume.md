# warm-resume — warm-session context restore (post-compaction)

**This is the WARM session's resume. Never hand it to a cold pass** (asymmetric decorrelation:
warm gets everything, cold gets nothing — memory `feedback_dual_review_protocol`).

**On resume: LOAD THE FULL CANON BEFORE BEGINNING (standing, Jason 2026-07-03).** As the warm
reviewer you need a primed context — that priming IS what makes the warm pass warm. Before taking
any brief, read from disk: the whole canon (`vdti-repair-completeness-proof.md`,
`vdti-invariants.md`, `vdti-implementation-notes.md`, all `vdti-area-*.md`). Do **not** load the
landed `docs/design/` tree up front — canon and landed docs are two encodings of ONE design; only
one set belongs in memory, and **canon is canonical** (docs are re-read per-brief as review
evidence, when a brief requires them or Jason asks). This is the default every compaction; Jason
overrides with a note when he wants otherwise.

**Maintenance (standing, Jason 2026-07-02): update this file at the end of every review round** —
verdict delivered ⇒ refresh arc state / open items here, same-turn (the warm twin of
`design-resume.md`). Standing rules live in project memory (auto-loaded); this file carries
**arc state only**. For reasoning detail the compaction summary lost, grep the prior transcript:
`/Users/jason/.claude/projects/-Users-jason-github-com-jasoncolburne-vdti/a98d268e-b7e9-4ad1-bfb6-51fb9c87edd3.jsonl`.
Re-read every file from disk each round regardless — this file is orientation, never evidence.

## Role

Warm (contextual) reviewer, one effort level up, in Jason's hand-coordinated dual-pass topology.
Jason drives all design decisions and all git. A brief arrives as a `.working/*.md` path each
turn; findings go to the brief-named file — MERGE / HOLD-N at top, tagged findings, quoted
doc:line, `make all` exit 0 as a done-gate, edit nothing while reviewing. Warm sees prior cold
output by design (passes run simultaneously, so the in-flight cold is invisible by timing only);
derive findings independently, then state where cold would converge as a shared-blind-spot flag.

## Arc state (2026-07-03, HEAD `e369180` — tree clean)

- **THE SETTLED MODEL — LIVE-TIPS + PURE-WALK + GATE-IN-BOTH-MODES (canon + encode `e369180`
  "Separation of duties (merge/persist)"); my re-encode review returned HOLD-4 (edge residue, model
  confirmed).** Three interlocking parts, all canon-side (inv 13 reframed, vdtid-services §1e/§1i,
  impl-notes, fed §1e gate bullet) and landed (protocol-doctrine, merge/log/reconciliation/
  verification):
  - **(A) Pure-walk reading.** The reading (Active/`forked`/`disputed`) is a **pure function of the
    held events**; the **seal is DERIVED** (highest seal-advancer that is not itself a contested
    sibling and is clean — content competitors bury below it, a privileged competitor un-cleans →
    `disputed`). **"Frozen" = an origination posture only** (a node originates no non-resolving work
    onto a live fork), never the reading, never a stored flag. A **content** fork is resolved by a
    `Rec` OR by a **burying seal-advancer on the winning branch** (the loser drops below-seal-inert
    — you can't fork the past, now order-free). Identical held sets ⇒ identical reading + digest —
    the determinism claim is now TRUE and I verified it both arrival orders (the old F2/H1
    counterexample dissolves; the privileged-loser variant reads `disputed` identically).
  - **(B) Live-tips digest.** effective-SAID = hash over the **live tips** (canonical + every
    UNRESOLVED competing branch — incl. a held below-seal **privileged** spine fork); a **settled**
    branch (repair-condemned, or buried below-seal-inert **content**) drops out — forensic via the
    on-chain `fork` commitment + by-prefix fetch (the settled-evidence anti-entropy spin closed; a
    resolved fork converges on its canonical tip). Colons stay banned; verdict never in the value;
    below-own-seal deep mint recast as a **does-not-hold** eclipse limit (pure-function-clean).
  - **(C) Shape-validity gate at the acceptance point, both modes.** Reject a seal-advancer that
    would bury a **privileged** branch / a bad `Rec` — witness pre-sign (witnessed), threshold
    (non-witness), the **merging node itself** (direct-mode). Merge otherwise integrates
    (keep-all-data) + seal-cap; content-fork prevention stays witnessed-only (a direct-mode content
    fork forms, reads `forked`, fail-secure — first-seen without a shared witness would fail-open).
  - New merge routing: Matrix-1 Divergent rows gain guard **ᵈ** (winning-branch seal-advancer →
    Accepted, re-reads Active; `Dec` → Decommissioned; second-privileged → shape-gate rejects;
    `v_{d-1}`-sibling privileged → SiblingLocked; non-resolving content → RecoverRequired =
    retained-as-evidence, reading stays `forked`).
- **My HOLD-4 this round (`vdti-convergence-reencode-review-warm-findings.md`, OUTSTANDING):**
  **H1 [MED]** Matrix-2 lags the burial routing — `Active→Divergent` and `Decommissioned→Divergent`
  print flat RecoverRequired but a source run carrying a burying seal-advancer/`Dec` → Accepted /
  Decommissioned (the determinism fix's own convergence mainline); + Matrix-1 Divergent(sealed) ×
  at-seal-parent content `Ixn` has no cell (→ RecoverRequired). **H2 [MED]** system-thesis:138-144
  untouched — still the absolute freeze ("frozen until a repair resolves it; accepts no new event")
  contradicting the origination/reading split + burial (its :67-69 determinism claim is now fine).
  **H3 [MED]** the derived-seal rule is prose-only everywhere — verification.md:239 token field
  ("most recent Rot/Ror/Rec/Wit/Dec on the spine") + log.md watermark table lack the
  contested-sibling + clean qualifiers; pin the algorithm at the walk spec (canon-side too).
  **H4 [MED]** `Dec`-burial seam: canon inv 4 "(a `Dec` caught in a divergence forces an
  `Rpr`/`Rec`)" + protocol-doctrine:662 "repair first, then the `Dec`" vs the ᵈ cell's
  `Dec`-buries; also "by tier-rank" mislabels burial (tier-rank = the same-position no-successor
  case). Decision rider: confirm `Dec`-burial intended (it is sound), then fix all three — or drop
  `Dec` from ᵈ. **LOWs:** L1 canon "witnessed + propagated" dead-events phrase (proof:49,
  invariants:110/:700); L2 canon fed §1e split-stall "THE exit is the repair" (burial = 2nd exit);
  L3 inv 13 "no new event of any kind" wording forbids the resolving moves it then names; L4 landed
  live-tip definition leaves below-seal-privileged-is-live to complement-reasoning (canon names the
  arm — carry it over); L5 carryover — Matrix-2 ingestion header lacks the witnessing-gate
  qualifier. Verified clean: all greps (all-tips/frozen-reading/only-a-Rec/acceptance-order resi-
  due ZERO), folds F5/F6/F8 landed, voice clean, `make all` 0 (455 xrefs).
- **Digest-model history (same-day, three generations):** seal-relative (`4beb456`, killed by cold
  F1 masking + F2 input-ambiguity) → all-tips (`fc6c91b`+`5119814`, killed by cold F1
  resolved-fork-two-ways + F2 determinism counterexample = my H1/H2; my adjudication of that cold
  file — all ten valid, F1 was a canon-internal unpinned choice, F2 was my trace better-routed —
  is §Adjudication in the archived all-tips findings file) → **live-tips + pure-walk (current;
  Jason's fix — kels recall)**. Prior rounds' findings all folded or superseded by the rework;
  nothing outstanding from them.

## Prior arc state (content-fork prevention, settled + encoded)

- **Content-fork prevention — SETTLED, ENCODED, REVIEWED, POLISHED.** The model: witness-config
  **majority floor `threshold > signers/2`** + the kind-scoped witnessing ladder (content
  first-seen, one sibling per `(prefix, serial)`; privileged up to **two** per position — two
  both-witnessed siblings ARE the `disputed` proof; the resolving repair = the first privileged
  sibling, no separate clause) ⇒ **content forks on witnessed chains are prevented below
  fork-cost `2·threshold − signers`** (a priced dial: `fork-cost = threshold − slack`;
  double-signing attributable). Option (b): user-IEL content gated at its own position alongside
  Q1 anchors; federation IEL exempt; SEL rides the cross-layer theorem. Counting is
  **selection-scoped**. Recoverability cap **`threshold ≤ min(|roster| − 2, signers − 1)`**,
  `signers = 1` waiver ({1,1} evict-one = position-luck, warned); re-check on **any
  config-changing `Wit`** (incl. config-only). **Single-add federation `Wit`** (`add` scalar,
  `Fcp` exempt, `cut` a list). **`forks` → `fork`** (one root; unnamed branches close below-seal +
  by-descent — verified closure equivalence). Serialization: governance safety-critical
  everywhere; content-rail = liveness on witnessed chains, safety-critical direct-mode/solo.
  Propagation premise = success-rate/latency only, never safety. §1a reachability property
  verified (one `Wit` carries the full config delta → no forced invalid intermediates).
- **My verdicts this arc (all archived):** majority-quorum canon review **HOLD-2** → fold review
  **MERGE** (both Fable completions verified: waiver necessary+honest; collapse
  outcome-identical) → encode review **MERGE** (clusters A–J faithful; manifest independently
  clean incl. sad/policy/diagram; no cross-doc contradiction). Cold ran HOLD-11 on the canon
  round; its seam findings (config-transition F1, single-add P5) landed as the canon seam layer.
- **All my open findings are folded** (verified from disk 2026-07-03): the four fold-review LOWs
  (proof premise now lists the roster-delta straddle; area-fed elliptical bounds fixed;
  first-seen naming unified — 0 "first-receive" hits; area-sel has the transitive fork-cost
  note) and ALL of encode F1–F5 in `89f74cd` — F1 (content-rail uniformly "safety-critical on
  direct-mode") and the F2–F5 de-dup collapses exactly as recommended (verification's FORCE
  content-leg → split + §Federation-convergence ref; event-shape's witnesses/bounds/roster rows →
  shape/bound + ref, rationale prose removed). The "(verify at review)" tag is resolved out of
  area-fed.
- **Commit sequence (this layer):** `fbc62eb` majority-quorum canon → `a3e371e` re-encode landed
  design → `89f74cd` review polish → `5a5932b` **new `docs/design/README.md`** (reading-order map —
  I have not reviewed it) → `4b6c62c` clarify reconciliation.md → `b526dd3` SiblingLocked/retention
  split → `4beb456` **Eliminate synthetic SAIDs** (seal-relative digest; reviewed HOLD-2) →
  `fc6c91b`+`5119814` **all-tips** (reviewed HOLD-2) → `e369180` **Separation of duties
  (merge/persist)** = the live-tips + pure-walk re-encode (current round, reviewed HOLD-4).
- **Repair-completeness model (settled r1–r5, re-scoped to the residual):** root-pointing
  (`fork` = one root condemning its subtree) + deadness-descends (same-chain + **IEL→SEL anchor
  edge only**) + bounded fork (depth ≤ 64/lineage; retention ≥ 2/position; the ladder) + two
  guards (no-self-condemnation over the full-span walk — tight form
  `root.parent = v_{d-1} ∧ root ∉ walkback` in impl-notes; content-only) + retain-and-count
  (scoped: passes hard auth, fails content-only; junk dropped) + `{Dec, content}` tier-rank +
  D1 two-valued finality (no-resurrection unconditional; resolution-stability gated;
  residuals: eclipse + historical reserve compromise + withheld-body split + roster-delta
  straddle) + cross-layer theorem (valid SEL fork ⇒ IEL fork; anchor-monotonicity with
  skip-unattributable). Runs against the residual population (direct-mode, fork-cost byzantine,
  straddles, split-stalls, mixed races).
- **Canon:** `.working/vdti-repair-completeness-proof.md`, `vdti-invariants.md` (inv 4/12/13/14/17),
  `vdti-area-{kel,iel,sel,federation-witnessing}.md`, `vdti-implementation-notes.md`. **Landed:**
  protocol-doctrine, system-thesis, **design/README.md (new)**, event-shape, six `kel/` docs,
  sad/ + policy/ trees, `docs/.terminology-forbidden` (root-pointing + fork-scalar bans).

## Open items

- **My HOLD-4 (live-tips re-encode round) awaits the fold:** H1 Matrix-2/Matrix-1 burial cells;
  H2 system-thesis freeze section; H3 derived-seal rule pinned at the walk spec (+ canon); H4
  `Dec`-burial seam (with the confirm-or-drop decision rider); L1–L5. Findings file above;
  re-review on the fold brief. The in-flight cold re-encode pass may add items (expect convergence
  on H1/H2 — landed-surface-reachable; H4's canon side + L1–L3 are invisible to cold).
- **Unreviewed surfaces:** `docs/design/README.md` (5a5932b) — no review round has covered it yet.

## Pending externally

- Forward-ref'd / unbuilt: `iel/` + `sel/` (the cross-layer bundle lands there),
  `federation/{witnessing,bootstrap}.md`, `operations/{multi-party-governance,recovery-workflow}.md`,
  `features/credentials/`, `infrastructure/vdtid.md`. Full-out design encoding planned after this
  review iteration set.

## My findings files

**Active (round open):** `vdti-convergence-reencode-review-warm-findings.md` (HOLD-4, the
LIVE-TIPS + PURE-WALK round, 2026-07-03). The all-tips round's
`vdti-convergence-encode-review-warm-findings.md` (HOLD-2 + the cold-findings adjudication §) is
superseded by the rework — archive-ready.

**Archived (`.working/archived/`):** `vdti-repair-completeness-findings-warm-r{1..5}.md` ·
`vdti-repair-completeness-encode-findings-warm.md` ·
`vdti-doctrine-quality-reverify-canon-findings.md` ·
`vdti-majority-quorum-canon-review-warm-findings.md` ·
`vdti-content-fork-prevention-fold-review-warm-findings.md` ·
`vdti-content-fork-prevention-encode-review-warm-findings.md`.
