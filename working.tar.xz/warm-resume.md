# warm-resume — warm-session context restore (post-compaction)

**This is the WARM session's resume. Never hand it to a cold pass** (asymmetric decorrelation:
warm gets everything, cold gets nothing — memory `feedback_dual_review_protocol`).

**Canon load: WHEN A BRIEF IS IN HAND, not at resume (standing, Jason 2026-07-03).** As the warm
reviewer you need a primed context — that priming IS what makes the warm pass warm. But the canon
may move between rounds, so front-loading it at resume wastes tokens on priming that goes stale;
load it fresh at the moment a brief arrives. **The canon lives at `docs/canon/`** (moved from
`.working/` 2026-07-04; `.working/` now holds only working-surface files — resumes, briefs,
findings, index, roadmap, archived/): read from disk the whole canon
(`vdti-repair-completeness-proof.md`, `vdti-invariants.md`, `vdti-implementation-notes.md`, all
`vdti-area-*.md`, `vdti-federation-inception-reference.md` — all under `docs/canon/`). Do **not**
load the landed `docs/design/` tree up front — canon and landed docs are two encodings of ONE
design; only one set belongs in memory, and **canon is canonical** (docs are re-read per-brief as
review evidence, when a brief requires them or Jason asks). The canon is greenfield-**exempt** (it
records decision evolution — "was `Del`" definitions etc.); the landed `docs/` tree is greenfield.
Jason overrides with a note when he wants otherwise.

**Maintenance (standing, Jason 2026-07-02): update this file at the end of every review round** —
verdict delivered ⇒ refresh arc state / open items here, same-turn (the warm twin of
`design-resume.md`). Standing rules live in project memory (auto-loaded); this file carries
**arc state only**. For reasoning detail the compaction summary lost, grep the prior transcript:
`/Users/jason/.claude/projects/-Users-jason-github-com-jasoncolburne-vdti/a98d268e-b7e9-4ad1-bfb6-51fb9c87edd3.jsonl`.
Re-read every file from disk each round regardless — this file is orientation, never evidence.

## Role

Warm (contextual) reviewer, one effort level up, in Jason's hand-coordinated dual-pass topology.
Jason drives all design decisions and all git. A brief arrives as a `.working/*.md` path each
turn; findings go to the brief-named file — MERGE / HOLD-N at top, tagged findings, quoted
doc:line, `make all` exit 0 as a done-gate, edit nothing while reviewing. Warm sees prior cold
output by design (passes run simultaneously, so the in-flight cold is invisible by timing only);
derive findings independently, then state where cold would converge as a shared-blind-spot flag.

## Arc state (2026-07-11 — canon SHIPPED; **phase-2 `docs/design/` landing PR-by-PR** — PR#11 KEL primitive **MERGED** (`a310c72`); **CURRENT: holistic-9 review (FIDELITY-TO-CANON + all axes — validate the round-8 fold + PRESSURE-TEST the killswitch/forced-brick + same-serial topology — REPORT-ONLY) — findings delivered; NO P0:** BOTH pressure-tests SOUND — (A) killswitch/forced-brick is sound + faithful to canon (`vdti-area-kel:59-62` signing-key→competing-rotation / reserve→takeover; forced-brick trichotomy airtight; KERI §4 consistent + owns the hedge); (B) same-serial topology sound (cross-serial pair collapses — earlier seal buries the later branch → later seal not lineage-accepted). My round-8 F1 (verdict "accepted" sweep) FOLDED complete. Only 2 P2: F1 ~11 "past the fork" survivors (sound — accepted-qualifier does the work — but not the intended "at the last seal/same serial"); F2 low — two-tier capability model vs killswitch use "signing key" w/ two referents (K₀ pre-rotation / K₁ post-rotation) (prior: holistic-8 collapse-theorem SOUND + P1 sweep — NOW FOLDED, holistic-7 ONE P0 acceptance-conflation — FOLDED, holistic-6 ONE P0 threshold-independent — FOLDED, holistic-5 NO-P0/P1, holistic-4 SOUNDNESS, holistic-3 refactor-pointer, IEL MERGE/HOLD-1, holistic-1/2 HOLD-1, sealing-rename MERGE — all folded); `sel/`, `federation/witnessing.md`, `features/`, services docs deferred to later PRs)

- **CURRENT ROUND — HOLISTIC-9 review (FIDELITY-TO-CANON + all axes — validate the round-8 fold + PRESSURE-TEST
  the killswitch/forced-brick + same-serial topology — REPORT-ONLY): findings delivered (2026-07-11,
  `.working/vdti-holistic-review-9-warm-findings.md`).** Round-8 fold: dispute topology resolved to SAME-SERIAL;
  verdict "accepted" sweep; NEW block — the live-tip dispute is a **killswitch, forced by structure**
  (`kel/compromise` §The live-tip dispute + KERI-comparison §4). **BOTH pressure-tests SOUND (NO P0).** **(A)
  killswitch:** attacked all 4 sub-claims — (A1) a rival seal at the tip needs `K₁`'s PRIVATE half (revealing the
  public preimage isn't enough) = the current signing key post-reveal / the reserve pre-reveal — can't forge with
  less; (A2) racing-with-reserve-that-wins→takeover, late-rival(first-seen-spent)+collusion→brick, no inversion;
  (A3) forced-brick trichotomy (reincept / data-rule-grindable / first-seen-observer-dependent) is COMPLETE — tried
  ~5 tiebreaks (lowest-SAID/most-receipts/next-reserve-hash/longest-chain/later-reveal), all grindable or
  observer-dependent; (A4) FAITHFUL to canon `vdti-area-kel:59-62` (signing-key→competing-rotation-declined /
  reserve→takeover); Sweep 3 found NO "dispute needs the reserve" survivor. KERI §4 (`keri-comparison:118-130`)
  consistent + owns the "not the KERI authority" hedge. **(B) same-serial:** couldn't construct a cross-serial
  accepted pair — the earlier seal buries the other branch from the fork (`f < s₁`) → the later seal's lineage
  isn't accepted → dropped; the `accepted` (lineage-accepted) qualifier enforces it. **MY ROUND-8 F1 FOLDED
  COMPLETE** (Sweep 1: every previously-bare verdict site now carries "accepted" + scope). **Only 2 P2:** F1 —
  ~11 "past the fork" survivors (`glossary:147`, `pd:122/1345`, `kel/log:48/68/74`, `iel/log:68/85/98`,
  `kel/compromise:240` [subagent MISSED — my catch], canon `area-kel:80`) — SOUND (accepted-qualifier prevents the
  cross-serial false-Disputed) but not the intended "at the last seal/same serial" + inconsistent with adjacent
  "at the last seal" lines (parallel to round-8 F1, an incomplete phrasing-sweep). F2 [low] — `events.md:205-219`
  two-tier capability model ("signing key → tier 1 only" = pre-rotation K₀) vs the killswitch (current signing key
  K₁ = the spent reserve → forges a competing tier-2 seal at its own serial); both correct, "signing key" shifts
  referent across the rotation boundary → add a cross-ref. Low obs (no finding): canon `area-kel:85-86` "{Rot,Rot} =
  confirmed reserve compromise" is scenario-scoped, reconciled by K₁=spent-reserve. (A subordinate Explore agent ran
  3 sweeps; I verified a sample + caught `kel/compromise:240` it missed.) `make all` 0/724. **Cold-overlap:** (A) is
  warm-leaning — a design-only cold pass reading the `events.md` two-tier table in isolation may see the killswitch's
  "signing key forges a seal" as a contradiction (F2) not the boundary case it is.
- **PRIOR ROUND — HOLISTIC-8 review (FIDELITY-TO-CANON + all axes — RE-REVIEW of the round-7 fold + the NEW
  collapse theorem — REPORT-ONLY): findings delivered (2026-07-11, `.working/vdti-holistic-review-8-warm-findings.md`).**
  The round-7 fold went FURTHER than my F1: the designer derived a **collapse theorem** — dead-by-descent generalized
  ("you can't seal a buried chain": a lineage is dead from its first-seen loss at ANY position, a `Rot`/`Evl` seal
  forged on it dead too) ⇒ two accepted sealed branches must meet at ONE fork position where both siblings are
  accepted ⇒ a provable same-position witness double-sign; **NO cross-position dispute.** **HEADLINE — property 3:
  the collapse theorem is SOUND (NO P0).** Attacked it adversarially (brief: "construct a two-accepted-branch state
  w/o a same-position double-sign → P0") — COULD NOT. My cross-position attack (forge seal `Ry@7` high on a
  first-seen-loser lineage, threshold-witnessed by ignorant serial-7 selectees) is closed THREE ways: (1) verifier
  **lineage-acceptance** (an "accepted sealed branch" = seal witnessed-at-threshold AND lineage accepted — every
  ancestor at threshold; fail-secure, safety-layer — `pd:93-99`, `inv:823-831`); (2) universal position gate starves
  the dead branch per-serial; (3) query-scoping keeps sub-threshold ancestors witness-only so a non-witness can't
  complete the lineage. Safety rests on (1) (premise-independent); (2)/(3) are prevention. **MY ROUND-7 F1 LANDED
  FAITHFULLY** (`kel/verification:417-427` "Acceptance requires threshold — for every node"; canon
  `federation-witnessing:350-354` split decline-trigger from acceptance). **ONE P1: F1 — verdict-predicate sweep
  incomplete (the Known-partial task):** 16 UNQUALIFIED + 2 PARTIAL "≥ 2 sealed branches" sites (some the superseded
  "past the fork" framing) → target **"≥ 2 accepted sealed branches at the last seal"**; LOAD-BEARING not cosmetic —
  a literal encode of the bare form counts a dead-lineage/cross-position seal → false Forked/reincept (griefing) or
  false Disputed (the round-6 recurrence). Sites: `iel/events:42`, `iel/log:67`, `iel/reconciliation:184/219`,
  `kel/log:47/55/74`, `kel/merge:49`, `kel/reconciliation:109/250/505`, `pd:500/572/719`, `system-thesis:77`,
  `inv:456` (unqualified); `iel/merge:79`, `area-vdtid-services:283` (partial — missing "at the last seal"). Gold
  templates: `iel/verification:252`, `kel/verification:254`. (A subordinate Explore agent classified; I verified a
  representative sample vs source — it couldn't Write, read-only mode; I captured the list.) **F2 [P2]:** the
  verifier-RULE sites gloss "accepted" as witnessed-at-threshold ALONE, dropping the lineage half
  (`kel/verification:395`, `iel/verification:355`, recon matrices) — the load-bearing conjunct invisible where the
  walk is implemented; gloss it or cross-ref `pd` §Terminology. **F3 [P2 low]:** `pd:90-92` "a key-state branch you
  did not author can never be buried" — scope to the accepted-lineage/live-tip forgery (a dead-lineage forged seal
  IS buried — property 7); defensible, add a scope word. **VERIFIED GOOD:** dead-by-descent-generalized consistent
  (`inv:823-831`/`fed:270`/`pd:95-96`/`glossary:208-210`); `{Evl,Evl}`→collusion (`pd:513`); query-scoping+`all-data`
  reached the design surface (`pd:1084-1089` — my round-7 canon-only note resolved); properties 1–7 hold. `make all`
  0/720. **Cold-overlap:** property-3 soundness is warm-leaning (needs the canon lineage-accept def + the "why the
  sweep is load-bearing" trace); a design-only cold pass reading `kel/verification:395` in isolation may accept
  "witnessed at threshold at the last seal" as the whole test and miss the lineage half (the round-6 blind spot).
- **PRIOR ROUND — HOLISTIC-7 review (FIDELITY-TO-CANON + all axes, the AUTHOR-FLAGGED PRESSURE-TEST of the
  `witnessed`/acceptance seam — REPORT-ONLY; Jason: "i think the designer messed up a bit … i think i'm right,"
  and later "advise on the corrected wording"): findings delivered (2026-07-11,
  `.working/vdti-holistic-review-7-warm-findings.md`).** The claim to break: _first-seen-decline_ and _acceptance_
  are one predicate. **CONFIRMED they are NOT — the author is right; canon + design conflate them.** **ONE P0: F1
  [soundness/consistency(doc-vs-doc)/coherence] — acceptance is defined as SELF-SIGNING, must be threshold-only.**
  Canon ROOT `vdti-area-federation-witnessing.md:350-354` — "_Witnessed_ … signed it itself OR threshold-many
  others' receipts; **this one predicate is both the first-seen-decline trigger AND the acceptance condition**."
  Design LEAK `kel/verification.md:418-423` (§"Acceptance gating for non-witnesses") — "**Witness nodes accept `E`
  upon their own signing**," a *stronger* state than the non-witness deferred-pending (must be the SAME). **The
  break** (partition, no collusion): W1 self-signs sealed `E` (sub-threshold, 2 of 3); `E'` reaches threshold
  elsewhere; on heal W1 holds two "accepted" branches → false `disputed` (abandons a recoverable position). Safe
  for DECLINE (self-limiting), unsound for ACCEPTANCE (confers canonical trust on a loser). **Masked-not-fixed:**
  the round-6 fold threshold-hardened the FORCE *count* ("each witnessed at threshold"), which re-filters the
  false-dispute — but the acceptance DEFINITION still conflates, contradicts the corpus, and leaves the
  single-branch trust reading unguarded (round-6 lesson one level up). **CONTRADICTS (all threshold-correct, keep):**
  `glossary:200-201` ("confirmed tip = witnessed at threshold (accepted); the acceptance boundary"),
  `kel/verification:388` (witnessed = threshold-many receipts — 30 lines above its own leak),
  `kel/verification:394-395` / `iel/verification:353-354` / `protocol-doctrine:1047-1048` (disputed = each at
  threshold), `kel/merge:76-79`+`iel/merge:98-103` (accept-retain gated on "witnessed"), `inv:439/829`,
  `area-iel:129/231` (declined sibling deferred, never accepted). IEL verification twin is CLEAN (no self-sign
  clause — leak is KEL-only). **Corrected wording PROPOSED for both sites** (Jason asked) — acceptance = threshold
  for every node; a self-signed sub-threshold event is DEFERRED (admits-valid/commits-first-seen, not
  accepted-as-canonical), same state as a non-witness; in the findings file + my response. **VERIFIED GOOD:**
  round-6 P0 fully folded (threshold-independent = ZERO survivors); properties 1–6 hold (position gate universal;
  below-seal straggler dropped/inert, clean seal defined pd:752; dispute-only-at-last-seal; backdate closed;
  query-scoping canon-only, design `federation/witnessing.md` forthcoming; {Evl,Evl}→collusion, sealing
  serialization liveness-only inv:439). `make all` 0/715. **Cold-overlap:** F1 warm-leaning — needs the canon root +
  cross-ref `:419` vs `:388`/`glossary:200` + recognizing round-6 *masks* the symptom; a design-only cold pass may
  read `kel/verification:394-395` as clean and pass over `:419`.
- **PRIOR ROUND — HOLISTIC-6 review (FIDELITY-TO-CANON + complete, validating the LOAD-BEARING canon change:
  witnessing signs ONE sealing event per position (first-seen), NOT two — commit `f61c734`; REPORT-ONLY): findings
  delivered (2026-07-11, `.working/vdti-holistic-review-6-warm-findings.md`).** The change flips two things I blessed
  in prior rounds (round-4 "sign up to two sealed" + round-5 "sealing serialization safety-critical" — BOTH now
  superseded → read fresh, not recall). Read the canon change first (federation-witnessing §1e ladder, inv 13/17,
  area-kel/iel, keri-comparison) then swept the design for old-model survivors. **ONE P0: F1[soundness/fidelity/
  consistency] — the `disputed` reading still fires "threshold-INDEPENDENT on merely-HELD sealed branches" at 5
  sites** (kel/reconciliation:485 + :538-539, kel/verification:392-394, iel/reconciliation:363, iel/verification:
  348-350), contradicting (a) canon inv 13/17 ("an unwitnessed sibling a node merely holds is NOT an accepted
  branch"), (b) the CORRECT owner statement protocol-doctrine:1039-1042 ("holds two or more sealed branches that
  EACH REACHED THRESHOLD (accepted)…below threshold is deferred-pending"), (c) each file's OWN witnessing rule
  (kel/verification:390 "receipt counts alone do not satisfy witnessed"; kel/reconciliation:411 "accepts up to two
  WITNESSED…declined sibling deferred-pending"). **Re-opens the grief the change closes:** a node can still HOLD a
  witness-declined deferred-pending sibling (retention/gossip/beacon) → these 5 sites count it → false disputed →
  abandons a recoverable prefix. Half-(a) (witnessing declines 2nd sibling) landed everywhere; half-(b) (read only
  ACCEPTED) landed in pd:1039 but NOT the 5 Matrix-4/verification passages. Fix: gate on "each witnessed at
  threshold", drop "threshold-independent". **F2[P2]:** 3 sites (pd:99-100, kel/log:83-84, kel/verification:317-318)
  say "holding both → disputed directly" w/o the "accepted" qualifier (defensible via retained=witnessed, tighten).
  **VERIFIED GOOD:** witnessing=one-sealed-first-seen landed correctly (witness 1 / retain-accept ≤2-witnessed /
  decline-2nd-deferred-pending — merge docs + pd:1039); {Evl,Evl} honest-partition correctly NEGATED (pd:498-504,
  iel/log:74); sealing-serialization "safety-critical" GONE (now liveness-only, sweep 0 hits); record-both=retention
  only; reserve-theft KERI-shared bullet present; BOTH my round-5 P2s folded (KEL mixed-chain self-frame kel/log:15;
  O(1)-hit monotone-kill pd:1196); fork-cost/synthetic/bounds untouched. `make all` 0/714. **Cold-overlap:** F1 needs
  the canon to see "threshold-independent" is superseded (not just odd) + cross-ref the same file's witnessing rule
  for the internal contradiction — a design-only cold pass may pass kel/reconciliation:485 in isolation.
- **PRIOR ROUND — HOLISTIC-5 review (FIDELITY-TO-CANON + complete, all 5 axes, whole `docs/design/` reading order
  + the canon `docs/canon/` — REPORT-ONLY, no MERGE/HOLD): findings delivered (2026-07-11,
  `.working/vdti-holistic-review-5-warm-findings.md`).** Read the canon (inv 8/10/12, area-delegation/iel/kel,
  federation-bounds) THEN re-read the changed design fresh (9 commits since round-4: negative-check O(1)-first
  reframing, federation exclude-self pool, delegation.md landed, sig-signs-SAID, mixed-chain-by-tier, +375-line
  protocol-doctrine readability/de-dup churn). **NO P0/P1 — the flagged changes are clean, consistent, canon-faithful.
  MY HOLISTIC-4 F1 IS RESOLVED:** the exclude-self pool `signers ≤ |roster| − 1` now lands in iel/events:406-411 +
  protocol-doctrine:264-269, faithful to canon inv 10:67 ("witness never receipts its own event"), jointly
  satisfiable (`signers−1` leg binds), even names the footgun I flagged ("naive all-four-witnesses-sign not
  selectable"). **VERIFIED GOOD:** negative-check O(1)-first is result-equivalent to canon inv 10 (fail-secure-by-
  default preserved — a MISS still walks; O(1) is a hit fast-path) + CONSISTENT across all 6 sites (protocol-doctrine/
  glossary/iel-verification/iel-events/policy/delegation — wrap-tolerant sweep found ZERO stale walk-first residuals);
  Trm.pin bound-trace (=killing Rev/Dth's previous) stated where load-bearing; delegation.md faithful to canon
  area-delegation §1; sig-signs-SAID consistent (event-shape:43/said.md:160/kel-verification:34); P1-P9+P11 preserved
  through the churn (sealing-serialization safety/liveness split survived pd:336-339; effective-SAID synthetic naming
  uniform); reconciliation matrices preserved (kel/recon Matrix-2 footnote gap ᵉ→ᵈ FIXED, outcomes unchanged); R1
  earliest-anchor + constants (129/64/32) match canon; greenfield voice clean. **2 P2-LOW MINORS:** (1) "mixed chain"
  framing (property 11) stated only from iel/log:24 — kel/log/event-shape don't self-frame KEL/SEL as mixed chains
  though iel asserts they are; (2) O(1)-hit "done, no walk" (pd:1189) doesn't state WHY the hit is safe w/o freshness
  (kills are monotone → present-means-killed; sound but unstated, canon area-delegation:39 notes "a freshness walk
  still runs"). **Observation:** brief's read-list names deleted `vdti-repair-completeness-proof.md` (gone since
  first-seen encode). `make all` 0 (714 checks). **Cold-overlap:** fidelity-to-canon is my edge (a design-only cold
  pass can't confirm the O(1)-first/exclude-self encode faithfully from the machine-canon).
- **PRIOR ROUND — HOLISTIC-4 review (SOUNDNESS / first-reader property-verification, whole `docs/design/` reading
  order — REPORT-ONLY, no MERGE/HOLD): findings delivered (2026-07-11,
  `.working/vdti-holistic-review-4-warm-findings.md`).** Read the full tree in `README.md` order fresh from disk
  (all `sad/`, protocol-doctrine, event-shape, full `kel/*` + `iel/*` sets, `policy/*`) and verified the 10 named
  properties case-by-case + the four recent gloss+pointer collapses against their pointer targets. **ONE substantive
  finding: F1[soundness/incomplete-enumeration P1] — the FEDERATION threshold bounds are NOT jointly satisfiable at
  `|roster|=4, signers=|roster|=4`** (witnessing floor `threshold > signers/2` forces `≥3`; recoverability cap
  `threshold ≤ min(|roster|−2, signers−1)` forces `≤2` → ∅). Swept the whole permitted space (`|roster|≥4,
  3≤signers≤|roster|`) — that is the **only** empty corner; general feasibility needs `signers < 2·|roster|−4` (at
  min roster ⇒ `signers ≤ 3`). **Fail-SAFE** (both legs re-checked ⇒ every threshold rejected, never mis-accepted),
  so P1 gap-in-argument + operator footgun (naive 4-of-4 federation can't incept), NOT P0. `iel/events:398`'s "≥5
  recommended" gestures at it but never states the `signers`-vs-`|roster|` constraint. Fix: state it at
  `iel/events:396-399`/`protocol-doctrine:260-263`. **Verified GOOD:** all four holistic-3 collapses preserve
  soundness (pointer targets own the detail — said.md algorithm, iel/events bounds, protocol-doctrine synthetic-
  rationale + divergence-detail); user-identity bounds jointly satisfiable across the whole space; fork-cost math
  sound (`2·threshold−signers`); P1-P9 hold + docs mutually agree on every case checked (`{Evl|Rev|Dth,content}`
  recoverable / `{sealed,sealed}` terminal / `{Trm,content}` tier-rank; the 3-view state/region/effective_said table
  matches both verifiers); **holistic-3 F2 FOLDED** (`iel/log:16` now "is anchored by"); narrow-governance census
  clean except **F1-minor** ("doc-governance" for a `t_authorize` Gnt at event-shape:353/368, low). 2nd minor:
  `region()="forked → recoverable"` gloss looser than the lone-sealed-branch reincept case (reconcilable, low).
  `make all` 0 (703 checks). **Cold-overlap:** F1 needs *composing* 4 individually-correct bounds — a one-at-a-time
  cold read calls them "individually consistent" and misses the empty intersection; that composition is my edge.
- **PRIOR ROUND — HOLISTIC-3 review (structural / refactor-pointer / readability, whole `docs/design/` tree —
  REPORT-ONLY, no MERGE/HOLD): findings delivered (2026-07-11,
  `.working/vdti-holistic-review-3-warm-findings.md`).** A de-duplication / pointer-opportunity pass (Jason's seed:
  prefix/SAID re-described in event-log docs when `sad/` owns it). **Jason flagged mid-round to READ files fresh (not
  recall) — which paid off: my recalled "sealed-kind trio inconsistency" was STALE** (fresh `grep-terms.pl` shows
  "sealing kind(s)" uniform ×8, zero survivors — cleaned in `5a96d1d`/`660cc86`; glossary:65-71 defines the trio).
  **Used the NEW `scripts/grep-terms.pl`** (decoration/wrap-tolerant phrase search — the round-2 "bold hides
  stragglers" lesson as a tool) to locate variant re-descriptions + verify inversion scope. **Read fully:**
  sad/{sad,said,custody,availability,compaction}, event-shape, protocol-doctrine (1300ln), glossary, system-thesis +
  prefix/bounds/reconciliation-intro sections. **5 findings + minors:** F1[refactor P1] the prefix/SAID **algorithm**
  (two-hash/placeholder/collision) re-described in kel/log:21-33, iel/log:38-50, event-shape:32-33/582-587 — owner
  `sad/said.md §Derivation`; collapse to gloss+pointer, KEEP the per-primitive "what the prefix commits to"
  (said.md:105-111 delegates it) [Jason-confirmed seed]. F2[consistency P1] `iel/log.md:15` "It **anchors in** member
  KEL events" — lone direction inversion (should be "is anchored by"; contradicts inv4/event-shape:493/folded
  protocol-doctrine:208/glossary:169/its own :18; the other 2 grep-terms "anchors in" hits are false positives —
  batching + temporal). F3[refactor/dup P1] threshold-vector **bounds triplicated** (protocol-doctrine:236-264 +
  event-shape:116-152 + iel/events:94-135) → iel/events owns, event-shape gloss+points (already defers derivations),
  protocol-doctrine↔iel/events split = Jason's call. F4[dup P2] "why a synthetic not a digest" rationale near-verbatim
  in protocol-doctrine:1254-1262 (owner) + kel/reconciliation:331-346 + iel/reconciliation:269-272. F5[refactor P2]
  event-shape:538-580 §Divergence-is-scoped-to-content re-describes protocol-doctrine's retention/forked-disputed/
  burial (keep the spine + mermaid, collapse the detail). Minors: two-tier model 3× (protocol-doctrine/event-shape/
  kel-events); glossary:66 seal-family xref split. **Verified GOOD:** property-4 reconciliation "load-bearing
  correctness proof" framing PRESENT on both; narrow-governance glossary bridge consistent; direction convention
  otherwise clean; availability/compaction clean owners; no pointer chains. `make all` 0 (693 checks).
- **PRIOR ROUND — SEALING-RENAME review (governance → sealed/sealing, commits `3613342` "Remove governance"
  + `4f6a1f7`): my verdict MERGE (2026-07-11, findings `.working/vdti-sealing-rename-review-warm-findings.md`).**
  The rename split the umbrella seal-advancing spine from the `t_govern` slot: **`sealed`** (state/spine/category/
  fork) vs **`sealing`** (event/kind/act/decision/submitter); `governance` RESERVED for the `t_govern` slot,
  federation governance (the federation `Wit`), role enumerations, establishment, doc-governance. **Verified
  complete + consistent + meaning-preserving:** umbrella flipped cleanly (tolerant sweep — no `content-versus-
  governance`/`pure-governance`/`governance seal`/`governance sub-split`/`did governance` survivor); reserved
  senses all correctly kept (`establishes governance` NOT flipped); **no sealed↔sealing inversion either
  direction**; meaning preserved at the named spots (log.md:133 "yielding state", area-iel:220 "the sealing event
  survives"); **KEL general-burial broadening complete** (protocol-doctrine ×4 :77/:314/:377/:428 + system-thesis/
  event-shape/invariants → "a `Rot`/`Wit`/`Trm` on the KEL"), **recovery-doctrine `Rot` correctly untouched**
  (protocol-doctrine:462 kept — the reserve-boundary sense); **filename unified** (`operations/sealing-serialization.md`,
  `.docs-xref-ignore` updated, no dangling `governance-workflow.md`; kels cross-repo pointer at area-iel:273
  intentionally left). `make all` **exit 0**. **ALL findings P2 (fold-step polish, no blocker):** F1 redundant
  "governance `Evl`" residuals (area-iel:33 [bold-hidden behind `**`], invariants:64 — settled "governance Evl→Evl"
  drop incompletely applied; → "`Evl`"); F2 nit reconciliation.md:305 "holding sealed events" renders the act-of-
  pausing-sealing as a state-noun (→ "pausing sealing"); F3 low/out-of-scope "sealing kinds" (reconciliation:283,
  rename-new) vs pre-existing "sealed/seal-advancing kinds" (protocol-doctrine/event-shape/kel — untouched by the
  rename). **Correctly-kept (NOT findings):** "(governance change)" on an Evl (system-thesis:179/area-iel:212 F7 =
  establishment sense); "sealed decision" (state-sense like "sealed branch"); out-of-16-scope "governance changes"
  (custody:131/multi-party:392). **Cold-overlap:** my decorrelated edge = completeness-against-the-rule (F1's
  bold-hidden residual is what a rule-blind read misses); F2/F3 a cold reader may independently flag as prose
  awkwardness (convergence = real). **Prior holistic-2 F1 (protocol-doctrine:208 anchor-direction) FOLDED** —
  now "reach a tier by **being anchored by** a lower-layer event."
- **PRIOR ROUND — HOLISTIC review 2, all landed `docs/design/` (soundness + fidelity, simplification-drift
  weighted; THE big change = the trust-tree direction flip down→up, `72c941f`): my verdict HOLD-1 (2026-07-10,
  findings `.working/vdti-holistic-review-2-warm-findings.md`).** My round-1-holistic F1 (README:4 trust-tree
  inversion) folded — and the designer reframed it into a **full-surface convention flip**: `inv 4` is now
  **"Manifest-up + pin-down"** (was manifest-down/pin-up), `inv 3` "pins down to the layer beneath, anchors up to
  the layer above," KEL "no chain **below** it" (was above). **Verified the flip is MECHANICALLY SOUND +
  THOROUGHLY APPLIED + GREENFIELD:** manifest-up (a lower event's `manifest.anchors` commits up to the higher event
  it anchors) + pin-down (higher pins down to its foundation) + resolve-down (verification walks down to the KEL
  base — iel/events:81, protocol-doctrine:1225); design matches (glossary:70/73, event-shape:111 "commits up",
  **mermaid `flowchart TB`→`BT`**, floors-down everywhere). **Ran it as a HALF-FLIP regression sweep** (the top risk
  of a 25-file direction flip = one survivor now contradicting the new convention): consolidated every
  anchor/commit/pin/floor/resolve × up/down/above/below across canon+design. **Round-1 residuals GONE** ("no chain
  above it"=0, "SAID of the layer below"=0, "manifest-down"/"pin-up"=0 modulo "spin up" false positives). `make all`
  **exit 0**; floor census 0 `majority floor`; no migration voice introduced. **The HOLD-1 = ONE self-contradictory
  direction residual the flip missed: `protocol-doctrine.md:208`** — "IEL/SEL events reach a tier by **anchoring in a
  lower-layer event**" (active, IEL anchoring DOWN) contradicts (a) the just-flipped inv 4 ("anchors **up**"), (b) its
  own next clause "is **anchored by** the KEL kind", (c) :1225 "resolves each anchor **down** to its KEL event". A
  canon-blind reader inverts the direction — the exact simplification-drift the brief weights. Fix: "reach a tier by
  **being anchored by** a lower-layer event." Plus 1 low F2: canon `vdti-area-delegation.md:71/116` "delegating links
  **pin up** … to X" (delegation-chain axis) now collides with inv 4's "pin-down" — pre-existing (flip didn't touch
  the delegation note); reword to avoid "pin". **Cold-overlap:** F1 is canon-grounded (only inv 4 says which direction
  is canonical) so the *fix direction* is my decorrelated edge; the cold pass may still flag :208 as a self-contradiction
  from the two visible clauses (convergence = real defect, not shared blind spot); F2 is canon-only, invisible to cold.
- **PRIOR ROUND — HOLISTIC fidelity review, all landed `docs/design/` (KEL `recovery.md`→`compromise.md`
  re-scope + this session's churn): my verdict HOLD-1 (2026-07-10, findings
  `.working/vdti-holistic-review-warm-findings.md`).** Deep-read the churn against the moved canon: `docs/canon/
  vdti-area-kel.md` (full), the re-scoped `kel/compromise.md` (full), every KEL-group diff
  (`events`/`log`/`merge`/`reconciliation`/`verification` + `README` + `canon-kel`) vs HEAD; swept the non-KEL
  surface for the cross-cutting properties. **The KEL re-scope is FAITHFUL:** `compromise.md` is doctrine-not-workflow
  and matches canon-kel (two-tier compromise, reserve-defends-signing-not-rotation, the 3 reserve-theft-escape facts,
  pre-seal verifiability, defense-layers-above-KEL); "recovery = plain `Rot` that buries at root" + "burial = any
  seal-advancer / deliberate recovery = `Rot`" (property 4) hold; the **moved mechanics landed clean** — attach shapes
  (branch-tip + ancestor-extending, ASCII + the `v_{d-1}` cross-node-validatable arg) → `merge.md` (+87), races →
  `reconciliation.md#matrix-3`, locked-portion → `log.md`; every relocated cross-ref propagated (canon-kel/README/all
  5 KEL docs). **"burying `Rot`"→"burying seal-advancer"** generalized (KEL twin of round-2 IEL). **Round-2 floor
  survivors FOLDED** — commit `81fc0b1` extended `lint-terminology` to catch **wrapped** tokens (the line-based blind
  spot I flagged), and the wrap-tolerant census now returns **zero** `majority floor`. `make all` **exit 0**;
  greenfield/jargon clean; effective-SAID synthetic + no-direct-mode + anchor-matrix all no-drift. **The HOLD-1 is
  ONE non-soundness fidelity break: `README.md:4`** — "each layer below assumes the ones above it" **inverts the
  trust-tree** (property 3): contradicts its own `:12` ("authorization layer sits on top"), canon-kel:24-25 (KEL =
  root, nothing above it), inv 3 (layers one-way — a KEL can't look up). First orientation sentence; one-clause fix
  ("each layer assumes the ones **below** it"). Plus 1 nit F2: "burying seal-advancer" over-applied into the
  **deliberate-recovery** worked scenarios (kel/reconciliation.md:612/632/634 — lead-in generalized, body still
  "Rot"; deliberate recovery IS a `Rot` per compromise.md:67-72). **Cold-overlap:** F1 is a README *prose-direction*
  catch a cold pass gravitating to the KEL/IEL mechanics can read past; decorrelated cold value = re-attacking whether
  the *move* changed any meaning (attach-shape ASCII, the `v_{d-1}` argument), not re-blessing the doctrine.
- **PRIOR ROUND — VDTI-16 IEL primitive, review 2 (cross-primitive floor rename + review fold, pre-merge):
  my verdict HOLD-1 (2026-07-10, findings `.working/vdti-16-iel-review2-warm-findings.md`).** Since round 1 the
  docs took the anchor-matrix fold (`Evl`→`roster`), content-fork terminology, matrix/table fixes, the F-2
  burying-seal narrow, and a **cross-primitive floor rename** — `majority floor` split into **witnessing floor**
  (`> signers/2`, witness signers) / **authorization floor** (`t_govern`/`t_authorize > |roster|/2`, roster
  members), **position gate** kept — touching the IEL docs, the KEL docs, and the canon. **The correctness-critical
  check PASSES completely:** every floor use classifies against its actual threshold — **no witnessing↔authorization
  swap anywhere** (full wrap-tolerant census, design + canon). The 9 properties hold post-churn (no drift); anchor
  matrix faithful (`Evl`→`roster`, anchors no kills); **F-2 fold landed correctly** (log.md:74 — non-terminal
  governance seal → Active, `Trm` → Terminated by tier-rank); **round-1 N1 folded** (events.md:370 adds user
  `Icp`←`Rot`) **and N2 folded** (log.md:74 precise). `make all` **exit 0**. **The HOLD-1 is NAMING, not soundness:**
  two **line-wrapped `majority floor` survivors** the line-based `lint-terminology` can't see (so `make all` is green
  while property-1 "no bare majority floor in docs/" is false) — `iel/verification.md:153` (roster bounds-list →
  **`authorization floor`**, matches :400 same file) and `kel/reconciliation.md:449` ("witnessing majority floor" →
  **`witnessing floor`**, remove `majority` per Jason). **The fix DIFFERS per site** — don't blanket-remove `majority`
  (:153 needs `authorization`, not "the floor"). Plus 2 nits: F2 "a authorization floor"→"an" (protocol-doctrine:241,
  event-shape:131, events:106, +canon supplemental:214); F3 reconciliation.md:346 residual "any governance
  seal-advancer" → "any **non-terminal**…" (log.md:74 sets the standard). **Cold-overlap:** a cold pass running the
  first-reflex line-based `grep`/`lint` will **miss both wrapped survivors** and call the rename clean — that's the
  line-based blind spot, NOT corroboration; the wrap-tolerant `perl -0777 …/majority\s+floor/` is what surfaces them.
- **PRIOR ROUND (round 1) — VDTI-16 IEL primitive docs (fresh encode, fidelity-to-canon, pre-merge): my verdict MERGE
  (2026-07-10, findings `.working/vdti-16-iel-review-warm-findings.md`).** First dual-pass on the freshly-written
  IEL primitive (branch `VDTI-16_iel-primitive`): `iel/{log,events,merge,reconciliation,verification,delegation}.md`
  encoded from `docs/canon/vdti-area-iel.md` (+ federation-witnessing / delegation / multi-party) against the landed
  KEL docs as the template. **Read all 6 design files + 4 canon area-notes from disk.** **A faithful, complete,
  greenfield, jargon-free encode — no fidelity break, no subtly-wrong mechanism.** All **9 properties verified
  design↔canon** (cited in findings): structure-only layering, 8-kind user + restricted federation IEL, two-tier
  + threshold vector + bounds + declaration, first-seen mixed chain (four-state walk-derived, user-IEL majority
  position gate), fail-secure `kills[]` revocation, **facet-dependent `Wit`** (root-facet dispatch on every
  `Wit`-reading path, token carries `root_facet`), eviction=`Evl`-with-`cut`, manifest-down kind-strict anchoring
  + anchor-monotonicity, seal-cap 64/lineage + roster-less re-seal `Evl`. **The 3 highest-risk areas re-attacked and
  HELD:** facet-`Wit` (governance-payload-smuggle path closed), sealed-branch verdict (≤1 Forked / ≥2 Disputed,
  `{Rev,content}` recoverable / `{Wit,Wit}` terminal), `kills[]` privacy split (delegate `bound` public / doc-member
  gated in rescind-doc). `make all` **exit 0** (52 files / 681 OK / **0 errors** / 46 sanctioned forward-refs,
  prettier clean). Greenfield + no-jargon greps both clean (the only "invariant N" refs are reconciliation.md's own
  §Invariants, like the KEL doc). **MY PRIOR CARRY-FORWARD RESOLVED:** the `iel/delegation.md` stub is now fully
  reconciled — delegate `bound` public in `kills[]`, `Trm` pin-only, `DLG_RSC_TOPIC`, fail-secure default (the old
  `manifest.bound`-on-`Trm` shape is gone). **TWO findings, both low/nit, non-blocking:** N1 [completeness]
  events.md:366-370 threshold-anchoring table omits the user IEL `Icp` ← KEL `Rot` row (includes the federation
  `Fcp`) — stated elsewhere (events.md:62, verification.md:106), add for table symmetry; N2 [consistency/nit] the
  burying-seal framing varies (log.md:74/reconciliation.md:346 "an `Evl`, or `cut` `Evl`" vs merge.md:73 +
  reconciliation Position 3 "any governance seal-advancer") — reconcilable, widen log.md:74's parenthetical.
  **Cold-overlap:** a fresh encode both passes diff vs one canon → convergence on "faithful" is inheritance; N1/N2
  are mechanical diffs a cold read surfaces identically; decorrelated value is cold re-attacking the *mechanisms*
  (facet-`Wit` done-criterion, `{Rev,content}` vs `{Wit,Wit}`, anchor-monotonicity ⇒ no-SEL-fork-under-linear-IEL).
- **PRIOR ROUND — final confirmation pass (KEL primitive PR#11, fidelity-to-canon): my verdict MERGE (2026-07-10,
  findings `.working/vdti-final-review-warm-findings.md`).** PR#11 has since **MERGED** (`a310c72`). The reconcile
  round's MERGE/MERGE fold: **8 folded findings** —
  verified each landed faithfully from disk: (1) protocol-doctrine:222 `tier 1/2`; (2) event-shape:308 KEL heading
  mirrors the IEL `(+ Fcp …)`; (3) event-shape:476 SEL `Trm` = **rescind**-doc (my reconcile F1 fix); (4)
  reconciliation:104-106 `Empty`-vs-four-live-states; (5) reconciliation:149-151 Matrix-1 below-seal position (my
  reconcile F2); (6) reconciliation:238-242 Matrix-2 no-Disputed-source Row note (my reconcile F3); (7)
  verification:270-279 state→region()→effective_said table — landed as a **4-row superset** (adds Terminated→trusted)
  of the brief's "3-row", faithful; (8) glossary:111-115 Terminated/Terminal/Trm disambig. **All 9 named properties
  verified against canon** (design↔canon cited in findings): first-seen+two-tier, four-state walk-derived, formalized
  merge outcomes (Matrix 1 exhaustive/sound), fail-secure revocation+R6, cred=direct-anchored SAD + R1 earliest-anchor
  +tier-inversion (documents.md:55-63), layering (event-shape:200-202 vs area-iel:15-25), no direct mode,
  verdict-recoupled effective-SAID synthetic, SAID §Rule-1 form-dependent (said.md:120-130). `make all` **exit 0**
  (47 files / 527 OK / **0 errors** / 31 sanctioned forward-refs, prettier clean). **Greenfield voice holds** (3
  `previously/superseded` hits all present-tense RUNTIME, no design-history; `was \`X\`` grep clean). **Merged
  supplemental** `vdti-keri-acdc-comparison.md` internally consistent (no contradiction across the positioning-note +
  keripy-deep-dive halves; [TO VALIDATE] flags intentional, KERI-side). **ONE substantive note, OUT of this PR's
  scope (carry-forward for the `iel/` PR):** `iel/delegation.md:14`/mermaid:25 shows the **delegate** rescission `Trm`
  carrying **`manifest.bound`** — the retired pre-fail-secure shape; canon (area-sel:145/281, inv 4:86) + the design's
  own protocol-doctrine:778 + event-shape:476 put the **delegate** `bound` **public in the `Dth`'s `kills[]`**, `Trm`
  carries only its pin (only the **doc-member** `Trm` commits a gated rescind-doc; `features/multi-party/documents.md:18`
  gets that right — it's the *delegation* stub that's stale). Also `RSC_TOPIC` vs canon `DLG_RSC_TOPIC`, and
  fail-open-only framing. **Both `iel/delegation.md` + `features/multi-party/documents.md` are diagram stubs**
  ("_Forthcoming_", same species as in-scope `federation/bootstrap.md`) — presence intended, doctrine deferred; the
  stale delegate-bound is not a blocker for the KEL merge but the same class as fold #3, so should be reconciled when
  `iel/` lands. **Cold-overlap:** fidelity re-encode both passes inherit from one canon — folds are mechanical, a cold
  diff surfaces them identically; **Note 1 is warm-leaning** (needs the R3 delegate-vs-doc-member bound-placement
  framing a cold pass may lack).
- **PRIOR ROUND — phase-2 reconciliation (fidelity-to-canon): my verdict MERGE (2026-07-10, findings
  `.working/vdti-reconcile-review-warm-findings.md`).** First phase-2 PR: the landed `docs/design/` KEL group
  (`kel/{log,events,merge,reconciliation,recovery,verification}`), `event-shape.md`, `protocol-doctrine.md`,
  `system-thesis.md`, `glossary.md`, `README.md`, `sad/{sad,said,compaction,custody,availability}`,
  `policy/{policy,documents,evaluation}`, `federation/bootstrap.md` — reconciled to the ship-reviewed canon.
  **Read every in-scope design file from disk** vs the canon. **A faithful, complete, consistent, greenfield
  encode — no soundness break, no fidelity drift.** All **9 named properties verified faithful** (design↔canon
  cited in the findings): first-seen+two-tier (5 KEL / 8 IEL / 5 SEL kinds), four-state walk-derived,
  formalized merge outcomes (`Result<MergeTransition, MergeRejection>` — Matrix 1 exhaustive/sound), fail-secure
  revocation + R6, cred=direct-anchored SAD + **R1 earliest-anchor + tier-inversion counter-example landed**
  (documents.md:55-63), the layering principle (`kills` opaque to the IEL, event-shape:200-202 — no topic
  semantics in the chain), no direct mode, verdict-recoupled effective-SAID synthetic, and **the SAID §Rule-1
  fix LANDED** (said.md:120-130 now says the SAID is **form-dependent** / re-derivable-by-compacting-down — the
  old wrong "wire-form-invariance" claim my resume tracked as deferred is GONE). `make all` **exit 0** from root
  (lint-terminology 0, prettier 0, lint-docs errors 0 — 31 sanctioned forward-refs, no broken in-surface refs).
  Dead-model + bookkeeping-leakage + greenfield-voice greps all clean in `docs/design/` scope. **STALE-CONTEXT
  TRAP CAUGHT:** the design's four-state contradicted my ship-round context's three-state — but the canon was
  **reconciled to four-state after my earlier read** (`54e5137`, area-kel.md/area-vdtid Jul 10 05:21-05:23), so
  the design faithfully encodes the *updated* canon; re-read from disk corrected it (would've been a false
  "design ahead of canon"). Also resolved: the whole-canon **F1 (KEL 5-vs-6 count)** — the design uses "5 kinds,
  2 inception variants" (events.md:3 / event-shape:308), clearer than federation-ref's "6". **The THREE findings
  are all [minor], non-blocking:** F1 [consistency] event-shape:476 mislabels the doc-member rescission `Trm`'s
  gated **rescind**-doc as a "grant-doc" (and the `grant` role is Gnt-only per the vocab table :170-179 —
  internal inconsistency; fix at the sel/features encode); F2 [completeness] reconciliation.md:135 "three
  attach-positions covers every valid submission" doesn't tabulate the parent-strictly-below-seal case (uniform
  `Sealed`/`Disputed` by seal-cap invariant 5 — add a Position-0 line for the exhaustiveness claim); F3
  [clarity] Matrix 2 has no Disputed-source row + no cross-ref to Matrix 3 (which covers it). **Cold-overlap:**
  the crown-jewel soundness is a faithful RE-encode both passes inherit — decorrelated value is cold re-confirming
  design↔canon agree on *meaning* (esp. the four-state/merge-outcome backport that changed under this PR); F1 is
  a warm-leaning catch, F2/F3 mechanical.
- **PRIOR ROUND — whole-canon holistic ship-readiness gate: my verdict SHIP (2026-07-10, findings
  `.working/vdti-canon-holistic-review-warm-findings.md`).** Swept **all 14 `docs/canon/` files in one pass**
  (read fresh from disk — invariants 874ln + federation-witnessing 672ln paginated in full) against the 7 Cs;
  the gate before the canon is promoted into human-facing `docs/design/`. **The canon is a sound, coherent,
  composable, consistent, threat-covering foundation — no blocker, no major.** `make all` **exit 0** (46/545/0).
  **Crown jewels re-attacked, not affirmed:** R1 (earliest issuance floor) genuinely closed + consistently
  stated (inv 5:218 / inv 10:317 / area-sel:94 — verifier derives earliest itself, never trusts a supplied
  later position; re-anchor accepted structurally, inert at the cred layer); fail-secure revocation closes all
  four escape routes (forge / silent-un-revoke / re-anchor / stale-IEL-hide); the freshness gate (whole
  transitive set, time-triggered, no-single-tip synthetic satisfies the bar); the effective-SAID synthetic
  (flood-stable, verdict-recoupled, converges with deferred-deps); federation never-bricks (self-attest under
  new key-windows, cold-8 F1). **The cross-layer theorem actually holds** (linear IEL ⇒ one anchored tip ⇒ a
  second same-serial SEL event is an inert re-anchor ⇒ SEL-fork forces IEL-fork; skip-unattributable prevents
  deadlock). **Seams verified sound:** KEL↔IEL↔SEL kind-strict + anchor-monotonicity + cross-layer theorem;
  the layering cut (chain=structure / feature=topic, R2 is a cred-layer check); federation-binding closed set;
  effective-SAID universal comparison; tier/threshold-vector. **Consistency sweep grep-clean** — every
  dead-model token (`privileged`=0 · `Ror`/`Rec`/`Rpr`/`Fld` · `T3`/`t_recover` · `Cnt`/`contested` ·
  `KILL_TOPIC` · `attribute-all`/`positive-presence`/`create-on-revoke` · `policyPin`/`grp`/`dev` ·
  direct-mode · raw `said(cred)`) is a negation or decision-history, never a live claim. **My Round C open
  item (the R3 doc-member bound-placement sweep) has LANDED** — verified from disk: every `only its pin` /
  `self-contained` / `never fetches` statement is now cred+delegate-scoped with the doc-member gated-rescind-doc
  carve-out (area-sel:145-150/281/289-290/309-313, inv:649-651, doc-policy:225, multi-party:181); no de-anon
  misread risk remains. **The FOUR findings are all [minor]/[nit], non-blocking:** F1 [consistency] KEL kind
  count stated "5 kinds" (area-kel:27, per-KEL) vs "KEL is 6" (federation-ref:25, total labels) — needs a
  bridging frame (5 per KEL, `Fcp` XOR `Icp`); F2 [completeness] doc-policy §E "policy-satisfaction matching"
  is `[fresh]`/unworked (:24; composer mechanics in §B/§C cover the substance — fold or work it at the feature
  encode); F3 [consistency] the token-store supplemental (:44) cites the archived `vdti-creds-issuance-
  revocation-model.md §4.2` + pre-rework "non-revocation proof" framing (absorbed into vdtid §1d — wants a
  status pointer); F4 [clarity][nit] inv:667's trailing "the `Trm` carries only its pin" grazes the doc-member
  exception (scoped correctly by inv:649-651 16 lines up — a re-scope at encode). **Cold-overlap flag:** the
  crown-jewel soundness rests on multi-round prior review both passes inherit from the same canon text — a
  cold re-read shares my priors (esp. the cross-layer theorem's linear-IEL step + the synthetic-satisfies-the-
  bar claim); best decorrelation is cold re-attacking the residual coverage claims (eclipse / just-closed-window
  lag / current-threshold-compromise), not re-blessing the crown jewels.
- **PRIOR ROUND — the fail-secure R1–R6 + layering FOLD: my verdict MERGE (2026-07-10, findings
  `.working/vdti-failsecure-fold-review-warm-findings.md`).** The fail-secure encode's dual-pass re-review
  returned HOLD/HOLD and **decorrelated-converged on ONE real break — the walk floor** (my F1 last round =
  cold's F1, found fresh with no spec → a genuine convergence, not a shared blind spot). Six resolutions
  (**R1–R6**) + a **layering principle** were folded, reconcile-not-redesign. `make all` **exit 0**. **The fold
  landed faithfully and the converged break (R1) is GENUINELY CLOSED — I verified it adversarially, not on
  faith:** R1 pins **both** the revocation floor AND the as-of to the **EARLIEST** issuance anchor (inv 5:218,
  area-sel:89-94, inv 10:316-318 — so a re-anchor is *fully* inert, stronger than my F1 ask which named only
  the floor); the verifier derives earliest itself + never trusts a supplied/cached later position (compatible
  with inv 8 caching); **no other mechanism moves the floor** (hiding the earliest needs a stale IEL → inv 8
  refuses; an earlier anchor only moves it earlier; as-of can't diverge from floor); **cred-only immunity is
  structural** — delegate/doc-member targets are grant-epoch-scoped AND their grant is a SEL event with
  anchor-monotonicity (re-anchor inert), while the cred issuance is a flat hash (no monotonicity) keyed only on
  `cred.said`. **The layering principle** (area-iel §1:15-25, kinds-vs-topic-labels, `kills[]`-only-on-`Rev`/`Dth`
  the one schema rule) is coherent + its key soundness check passes: the moved rules (R1/R2) are **feature-local**
  — skipping = a local wrong answer on one cred (R2 safe-direction), never a chain-validity break. **R2/R4/R5/R6
  sound:** R2 topic↔kind (cred revocation needs a `Rev`/`t_govern`; found-fast-path carries the check); R4 my F2
  closed (private lookup `Icp` recomputed-never-published, "CLOSED" rests on both halves); R5 my F3+minor closed
  (grep-clean no raw `said(cred)`; inv 4:110-114 back-check carve-out); R6 vdtid is a structural store not a
  revocation authority (grep-clean, freshness bar stays). **The ONE finding is [consistency], non-blocking:**
  R3's doc-member bound-placement carve-out isn't propagated to two secondary passages (area-sel:296, inv:662)
  that state the *delegate* case ("`bound` rides `kills[]`, `Trm` only its pin") as general — a de-anon misread
  risk if a doc-member impl follows it (the participant-identifying bound would land in public `kills[]` instead
  of the gated rescind-doc). Authoritative statements are all correct; just a propagation sweep.
- **PRIOR ROUND — the FAIL-SECURE revocation encode: my verdict HOLD (2026-07-09, findings
  `.working/vdti-failsecure-review-warm-findings.md`).** After re-review-2 broke the best-effort model's
  `attribute-all` escape hatch (my F1 last round), the design was reworked AGAIN — this time to **fail-secure
  by default**: revocation/rescission is a **`kills[] = [{target, bound?}]` declaration on the issuer's
  WITNESSED IEL `Rev`/`Dth`** (read by the fresh inv-8 walk, so detection rides the same freshness gate the
  verifier already runs to trust the issuer — "kill-freshness == authority-freshness"), with the
  content-addressed `{Icp, Trm}` lookup SEL demoted to a **fail-OPEN opt-out**; **the issuance SEL is dropped**
  (a cred is a direct-anchored SAD, `hash('{CRED_ISSUANCE_TOPIC}:{issuer}:{cred.said}')`); `target =
  hash('{topic}:{owner}:{data}')` (flat, distinct topics per kind). `make all` **exit 0**. **This is a genuine
  improvement and lands faithfully/completely/consistently in the main:** the core claim ("not-found in any
  `kills[]` at a confirmed-fresh tip → genuinely not-killed") **HOLDS** (forward-match your own target on the
  un-withholdable witnessed log — fixes re-review-2 F1 at the root, no reverse-attribution); the four flags,
  two reads, bound-per-kind (cred none / delegate public / doc-member gated), and `kills[]`-opacity all landed;
  completeness grep-clean (no live attribute-all/positive-presence/create-on-revoke/KILL_TOPIC); positive chain
  stays fail-closed (no over-correction); doc-member freeze hard again (multi-party:167-182, verified NOT stale
  — I re-read it after a momentary recall-confusion). **The HOLD is THREE reconcile items — two the exact
  unstated-assumption class the last two passes missed:** **F1 [soundness/under-spec]** the `[issuance-position
  .. tip]` lower bound doesn't say **earliest** issuance, and the inert-serial re-anchor guard was dropped with
  the issuance SEL — a re-anchored/claimed later issuance-position skips an intervening revocation ("no lossy
  cap" is unstated; lower-bound analog of the spec's named tip assumption). **F2 [soundness/privacy]** the
  private-cred "CLOSED" claim (inv 16:715) rests on non-computability of the address, but the lookup SEL's
  `Icp` carries `data = cred.said` **RAW** (area-sel:96) and the canon closes only "private cred **bodies** not
  published" (inv 16:719) — not the private lookup SEL `Icp`; if it's published for the O(1) path a replica
  reads cred.said raw (the holder-vs-replica gap; the encoder's own flag-1 target). **F3 [consistency]**
  inv 4:56/:66-67 still say the issuance anchor is raw `said(cred)`, contradicting the qualified-hash form
  everywhere else (inv 8:266, inv 16:686, area-sel:48) + flag-1. Plus an inv 4:106 back-check-precision minor.
  Reconcile-not-redesign; none fatal. F1's likely-intended close: earliest-issuance / re-anchor inert. F2's:
  only the pin-only `Trm` is served, the `Icp` recomputed-not-published.
- **PRIOR ROUND — re-review 2 (the best-effort rework across all three absence-reads): my verdict HOLD
  (2026-07-09, findings `.working/vdti-rereview2-warm-findings.md`).** Context: my PRIOR round called the
  positive-presence two-SEL revocation model "SOUND"; the cold pass then **broke it** (cold B-1 — a withheld
  serial-2 `Trm` reads a single Active tip → grants a revoked cred; positive presence defeats whole-SEL
  _absence_, not a withheld _tip_, SEL unwitnessed). **I reproduced the designer's error by trusting the
  spec's framing** — the correlated-blind-spot the decorrelated cold pass exists to catch. Jason reworked to
  the honest industry ceiling: **create-on-revoke `{Icp, Trm}`, best-effort / fail-OPEN** (matches KERI TEL /
  OCSP soft-fail), under an **inv-8 carve-out** (positive trust chain fails closed; revocation/rescission
  negative overlays fail open), extended to **delegate rescission** (`area-delegation`) and **doc-membership
  rescission** (`multi-party:167-181`) — all three the same create-on-X absence-read. `make all` **exit 0**
  (46 files). **The core rework is FAITHFUL, COMPLETE, CONSISTENT, and — this time — HONEST:** the default
  best-effort read is sound; the positive chain stays fail-closed (no over-correction); the present-object /
  closed-period asymmetry is kept in all three; the warm-F4 propagation is **recorded** (`multi-party:175-177`
  — reclassifying propagates Decision 1 (SELs unwitnessed), the premise F4's fail-secure rested on, NOT
  overturning F4); completeness grep-verified (no surviving positive-presence / "leaks nothing" / "CLOSED" /
  dual-Pin — only history / explicit-drops / the named future witnessed-revocation regime). **My PRIOR-round
  F1 (the "leaks nothing"/"CLOSED" over-claim) is RESOLVED** by this rework (inv 16 now states the
  revocation-list residual honestly). **The HOLD is ONE [soundness]/over-reach (F1) — the mirror of last
  round's error:** the **`attribute-all` fail-secure OPT-IN** (`area-sel:218-222`, `document-policy:219-226`,
  `inv 10:277-279`, `area-delegation:38-40`, `multi-party:178-179`) claims "attribute every `Rev`/`Dth`,
  **fetch each one's _derived_ SEL**, confirm none match → **confirmed clean** → grant." But a `Rev`/`Dth`
  names an **opaque `said(Trm)`, no prefix** (`area-sel:210`); cred-SELs are **by-prefix-only, no SAID→event
  index** (`inv 16:626/671-678`); a non-holder **can't derive a foreign address** (`plain-english:213` "no one
  else can find it"). So a client can address **only its own** cred's SEL; every **foreign** `Rev`/`Dth` is
  structurally unattributable, and the "(a withheld SEL)" parenthetical (`area-sel:220`) conflates
  "withheld" with "structurally-unaddressable" — the **same class of error** the rework just fixed. The
  "confirm clean" path is unreachable for any issuer with revocations the client doesn't hold. **NOT a safety
  break** (attribute-all fails secure — refuses, never false-grants; the default merges). The design's own
  model file uses the honest coarse form ("**refuse any cred whose revocation it can't positively check**",
  `plain-english:227`). Reconcile: restate as the coarse deny-by-default, or specify + reconcile the
  replica-enumeration `attribute-all` secretly needs (widens the inv-16 correlation residual). Jason's call —
  reconcile, not redesign. C1 minor: delegation states the present-object asymmetry least explicitly.
- **PRIOR ROUND — whole-canon re-review after the encode-review folds: my verdict HOLD (2026-07-09,
  findings `.working/vdti-rereview-warm-findings.md`).** The cold encode-review HOLD's fixes were folded:
  **B1** (NEW design — the two-SEL credential-revocation model, its first review), C1/C2, M1–M5. `make
  all` **exit 0** (46 files — the supplemental stub is now deleted, M1 folded). **The fold is faithful,
  complete, consistent; the `:57` "cred-SELs are witnessed" contradiction is FULLY GONE; C1/C2/M1–M5
  landed.** **B1's revocation SAFETY is SOUND** — the two-SEL split (issuance SEL `{Icp,Pin}` serial-≥2-inert
  + a derived **positive-presence** revocation SEL, always-published, `Trm@2` `Rev`-anchored) closes the
  hidden-revocation hole: "not revoked" is a positive read of an always-published Active object, so
  can't-confirm → fail-secure REFUSE (a denial, never a false grant); inert-not-reject encoded with
  reasoning (a T1 thief's serial-2 append is a no-op DoS-safe); the eclipse edge is pinned + fail-secure
  (not a new hole). **The HOLD is ONE soundness finding (F1):** the published revocation SEL's `Icp`
  stores `owner=issuer` + `data=issuance.prefix` in the clear and is replicated to the mesh, so a witness
  reads `(issuer, issuance.prefix)` + per-cred revocation status — **reopening the "issuer ↔ private-prefix"
  correlation `inv 16:661` claims CLOSED (§2c Decision 1)**, via the published body instead of the retired
  receipt. NOT a safety break (opaque hash, no content/holder), but `area-sel:61` "leaks nothing" +
  `inv 16:661` "CLOSED" + the model narrative :215/:222 over-claim it. The correlation edge IS pinned
  (`inv 16:665` — good), the pin just resolves negative. Reconcile (state the residual / accept the trade)
  or mitigate with a blinded derivation — Jason's threat-model call. Nit: `area-sel:187` keeps "third-tier"
  (greenfield-exempt history; applied-log's "without the dead token" over-states). Everything else MERGES.
- **PRIOR ROUND — first-seen CANON ENCODE review: my verdict MERGE (2026-07-09, findings
  `.working/vdti-first-seen-encode-review-warm-findings.md`).** The ground-up divergence/recovery rewrite
  across 12 `docs/canon/` files + the repair-proof deletion (1016 ins / 1250 del) landed in the working
  tree (uncommitted; commits are "Working surface" only). **`make all` exit 0** (47 files / 545 OK / 0
  errors / prettier clean — done-gate met). **The encode is faithful, complete, consistent; no blocker.**
  The **three KEEPs all survived** (checked hardest per the brief): inv 13 F-F pure-walk KEPT+reworded
  (invariants:436-438 — the F4 dependency the effective-SAID recoupling rests on; explicitly tied at
  vdtid §1e:121-123); `Fcp` genesis carve-out KEPT (area-kel:32 "not direct mode"); seal-cap KEPT,
  satisfiers narrowed `{Rot,Wit}` (area-kel:104). **Completeness verified from disk** (not on faith):
  `privileged`=0 (rename clean, `sealed-on-arrival` survived — 13 intact); every Ror/Rec/Rpr/Fld/
  t_recover/T3/direct-mode hit in the 12 files is a negative/history/guard. **F1 resolved cleanly** —
  lint-terminology is closest-file-wins, so `docs/canon/.terminology-forbidden` omits the `forked:`/
  `disputed:` ban (allows the synthetic) while `docs/.terminology-forbidden:181-182` keeps it for phase-2
  `docs/design/`. **The NOT-previously-reviewed block (§2b/§2c/§5/§9) — SOUND on first review:** §1g
  receipt spec (verify-first holds — every SEL kind rides an IEL anchor; Decision-1 makes plain-prefix
  safe; refuse-not-sign-then-not-count avoids self-forking; rebind-`Wit` T2), §1f second conjunct
  (forward-of-last-confirmed-tip, NOT pairwise/NOT seal — tightens the F5 just-closed-window residual),
  §1j SAD-store kind filter (closes a real inversion oracle), §1k receipt-threshold (exact-match-on-pull
  sound). **Effective-SAID consistent across vdtid §1e / inv 17 / area-kel.** Both encoder flags resolve
  SOUND: rebind-`Wit` T2 (ledger's "T3 rotation" is a typo — flag for Jason); roster floor ≥4 structural
  /≥5 recommended is forced (signers≥3 + exclude-self ⇒ |roster|≥4) + consistent (inv 12 + fed §1a/§1c).
  **Four MINOR/NIT:** M1 grep-canon-clean overstated (supplemental/vdti-lib-storage-stub.md:15,38 has live
  ancient-taxonomy `Rec`/`Ror`/`Fed`/`Dip`/`Dec` — out of scope, lint-green, stale-by-many-rounds); M2
  §1k [REVIEW-PENDING] hint-vs-authoritative scope (state it at encode); M3 fed §1a:94 "naive ≥ 3 floor"
  vestige; M4 impl-notes `forked:` vs `disputed:{prefix}` shorthand. No design blocker.
- **⟳ DISPOSED (2026-07-08, by the design session).** All my effective-SAID re-review findings are **folded**
  into the ledger + model files: F1 (`.terminology-forbidden:174-175` un-ban — the `make all` breaker, flagged
  in §2a's canon-edit list to do first), F2 (`area-kel:89`), F3 (inv 17 multiple passages), F4 (§2a + §3 KEEP
  `inv 13:484-487`, the F-F pure-walk the recoupling rests on), F5 (§1h edit site + inv 8 note). The cold pass's
  B1/B2/C1/M1–M3 are folded too. **The encode review is DONE (the CURRENT ROUND bullet above, MERGE);
  both watch-items confirmed** — the synthetic tokens are un-banned (scoped to `docs/canon/`) and the F-F
  pure-walk is kept (invariants:436-438). Findings now in `archived/`.
- **CURRENT ROUND — effective-SAID resolution re-review: my verdict HOLD (2026-07-08, findings now
  `archived/vdti-effective-said-warm-review-findings.md`).** The focused re-review the DISPOSED bullet
  queued. **The reversal is SOUND and NECESSARY — verified hard, both load-bearing claims survive:**
  (P1) the flood-instability premise HOLDS — §1e's convergence (:154 "hold the same branches") assumed
  honest first-seen witnesses; the dishonest-signer flood is a *witnessed* flood, outside §1e:168's
  "un-witnessed flood dropped" defense, and no canon mechanism bounds the witnessed sealed breadth
  (fork-cost prices not caps; retention keeps a non-deterministic ≥2; seal-cap bounds depth not breadth);
  (P2) **no consumer needs branch-sensitivity** — swept ALL readers (§1d token-reuse, §1e/§1i anti-entropy,
  §1g merge, §1h deferred-deps, document-policy §F, inv 8 multi-source), every one uses the digest as a
  change-detector + reads the VERDICT for trust; §1e's "Required"(branch-sensitive)+"Safer"(fail-open) are
  defeated correctly by verdict-recoupling (R4-masking only masks OUTCOME-PRESERVING branches; the M=1→M=2
  crossing moves `forked`→`disputed` and fires); resolution is owner-driven (root-bury `Rot`), never
  anti-entropy-assembly. (P3) "no silent forgery" — grep-confirmed ZERO "no silent breach" in canon
  (design-docs-only, §5 fixes it). (P4) "early-terminate at 2 sealed" squares with inv 17:761. **HOLD is on
  §2a COMPLETENESS:** **F1 [breaks make all]** `docs/.terminology-forbidden:174-175` ENFORCE `forked:` /
  `disputed:` as banned tokens (written to forbid the exact reversed model) — the reversal reintroduces
  them → lint fails; §2a omits `.terminology-forbidden` (un-ban 174/175, keep 172/173 divergent/irrec.,
  rewrite the canon comment :150-155); **F2** area-kel:89 asserts "real digest over live tips, not a
  synthetic" — inverts, not in §2a; **F4** the re-coupling is sound ONLY under the F-F pure-walk
  (inv 13:484-487) — §3 "delete inv 13's divergence rules" risks deleting the foundation; §2a must name it;
  F3 (inv 17 is 4+ live-tips passages :745/:748/:769-772/:779-782, not one) + F5 (§1h:193-194
  DeferredDepsResponse edit site + the inv 8:272-273 multi-source note) ride along. No design blocker.
- **⟳ DISPOSED (2026-07-08, by the design session).** Jason resolved the L2 crux: the effective-SAID is
  **single confirmed tip → real SAID; no single tip → a synthetic recoupled to the verdict** (`forked` /
  `disputed`) — **no live-tips digest** (flood-unstable under dishonest signers), **no branch-assembly**
  (root-bury resolves by position, owner-driven). L1's omitted files are now in the ledger (§2a lists
  vdtid-services §1e/§1i, implementation-notes, document-policy §F). The cold blockers were dispositioned
  too (A = a doc-precision fix, verified not a hole; B = "no silent breach" → "no silent forgery"; C/D/E
  folded into the model files). All of it is in the updated `.working/` model files + ledger; the first-seen
  **findings are now in `archived/`**. **The focused effective-SAID re-review is DONE (the CURRENT ROUND
  bullet above, HOLD); next is the encode review** once §2a's F1–F5 are folded.
- **CURRENT ROUND — first-seen model → canon reconciliation review: my verdict HOLD (2026-07-07,
  findings now `archived/vdti-first-seen-warm-review-findings.md`).** THE BIG CHANGE Jason flagged: a
  **design reversal** captured in `.working/vdti-{model-plain-english,event-kinds,adversary-cases}.md`
  + a delete/keep/rewrite ledger `.working/vdti-first-seen-reconciliation.md`. **Two tiers only** (T1
  signing / T2 rotation reserve — **drop T3 recovery key + `t_recover`**); **drop kinds** KEL
  `Ror`+`Rec`, IEL `Rpr`, SEL `Fld`+`Rpr`; **all key changes single-signed** (no dual-sig). **First-seen
  pivot:** witnesses take first-seen for content AND *single-key* key changes (KEL rotation, solo
  governance — the Rot'@v_M fix); record-both→`disputed` only for *multi-signer* key changes (federation
  IEL, multi-member IEL governance). **Recovery = a plain `Rot` at the fork position** (buries by descent
  + privileged-buries-content); **eviction = `Evl`-with-`cut`**; **DELETE the repair-completeness proof**.
  Roster cap → 32 all IELs; majority floor `t_govern`/`t_authorize > |roster|/2`; **direct mode removed**.
  **The DESIGN is SOUND** — no soundness break; the recovery mechanism (cross-tier co-sign + first-seen
  rotation + privileged-buries-content + deadness-descends) verifies, all 5 load-bearing claims hold,
  anchor re-homing is clean (only `Trm`: `Ror`→`Rot`, user + fed IEL both), the proof deletion leaves
  nothing unreplaced, FORCE-by-provenance survives scoped to key-change `disputed`. **The HOLD is on
  LEDGER COMPLETENESS, not the design:** L1 three affected canon files omitted (**`vdti-area-vdtid-services.md`
  §1e/§1i, `vdti-implementation-notes.md`:22-91/128-140, `vdti-area-document-policy.md` §R4** — none in
  the ledger or the brief's list); **L2 the effective-SAID change (§2) reverses a four-round-reviewed
  decision** — the ledger's `forked:<seal>` synthetic reverses vdtid-services §1e's "real live-tips, NO
  synthetics" (which explicitly retired the synthetics: "Required: branch-sensitive" + "Safer: fail-secure")
  and re-couples digest↔verdict — asserted without tracing or justifying (the one item needing Jason, not
  just the encoder); L3 SEL `Fld` deletion collides with area-sel §4's explicit "NOT transitive" finding
  (deletion sound — no-repair⇒no-page-atomicity — but unstated); L4 direct-mode removal under-lists its
  canonical §1d home + the "both modes" shape-gate simplification; L5 multi-party §3/§7 carry
  repair-proof citations + deleted anchor pairs. L6-9 minor. **Answer to "encodable as-is?": NO** —
  fix L1+L2 first.
- **PRIOR ROUND — fold + mermaid + removal review (2026-07-04, HOLD-with-findings,
  `.working/vdti-fold-and-diagrams-review-warm-findings.md`).** Disposition from THIS session unknown
  (a new brief arrived instead of a fold). Three MAJORs were: W1 event-shape role-vocabulary table
  malformed GFM (`content` spliced into `delegates`, :132-136); W2 six parent→child `|previous|` arrows
  in the stubs; W3 event-shape:377-384 §Anchoring omits `Ath ↔ Gnt` + retains retired "uniformly on the
  serial-1 `Pin`". MINORs W4-7 + NITs N1-4 (see the findings file). If a fold lands, re-verify from disk.
- **THE TAXONOMY (renamed 2026-07-04 — memorized names are STALE; use these).** `Del` → **`Ath`**
  (authorize, T2 `t_authorize` — two roles at once: `delegates` for act-for-delegator, `anchors` →
  the new SEL **`Gnt`** doc-membership grant for act-as-self); `Kil` → split **`Rev`** (revoke an
  owned artifact, `t_govern`) + **`Dth`** (deauthorize a grant, `t_authorize`) — the `threshold`
  slot-name field is retired, every kind prices from exactly one slot; `Dec` → **`Trm`**
  (terminate), chain state `Decommissioned` → **`Terminated`**; `t_delegate` → **`t_authorize`**.
  Kind counts: KEL 8 (`Fcp`/`Icp`/`Ixn`/`Rot`/`Ror`/`Rec`/`Wit`/`Trm`), IEL 9
  (`Icp`/`Ixn`/`Evl`/`Ath`/`Rev`/`Dth`/`Rpr`/`Trm`/`Wit`), SEL 7
  (`Icp`/`Ixn`/`Gnt`/`Trm`/`Pin`/`Fld`/`Rpr`). Anchor matrix (five pairs): `Ixn`↔content,
  `Evl`↔`Fld`, `Ath`↔`Gnt`, `Rev`/`Dth`↔`Trm` (discriminated by SEL type — the total rule:
  `Dth` iff authorization-rescission (delegation or doc-membership), `Rev` otherwise), `Rpr`↔`Rpr`.
  `Gnt` is privileged/seal-advancing/non-archivable (walk back = rescind forward via `Dth`).
- **PRIOR ROUND (detail) — fold + mermaid + removal review: HOLD-with-findings (2026-07-04,
  findings `.working/vdti-fold-and-diagrams-review-warm-findings.md`).** The
  taxonomy-round fold is **faithful and complete** — every warm W1–W10+N1–3 and cold M1–7/MIN1–5/
  NIT1–3 verified folded from disk (map in the findings file); the four rebuilt model surfaces
  (seal-advancer sets, `{Ixn, Pin}` archivable set, five-pair anchor matrix, SEL-`Icp`-never-anchored
  + fallback floor) agree at every normative site. The new **`grant` role is sound** (inv 4:74-76 +
  event-shape:137/:354; back-checked via the `Ath` kind-strict anchor, not allowlist-dependent; no
  S1). The 11 mermaid diagrams are current-model + kind-strict-correct with structural captions; the
  multi-party stub is rebuilt from the current canon (per-period `Gnt`←`Ath` grants,
  `hash(G | said_b)`, `{Icp, Pin}` versions, `ancestors[]` — no `authors[]`). Removal grep-clean;
  `make all` 0 (48 files / 545 xrefs / 31 fwd-refs). Three MAJORs: **W1** event-shape's
  role-vocabulary table is malformed GFM — 3-cell header vs 7-cell delimiter, the `content` row
  spliced into `delegates` (:132-136; a FRESH regression of the fold's own GFM fix — the allowlist
  table renders as raw text); **W2** the three stubs draw `previous` edges parent→child with the
  `|previous|` label (6 edges — inverts the field; landed diagrams draw child→parent); **W3**
  event-shape:377-384 §Anchoring omits `Ath ↔ Gnt` from its "only its matching kinds" pair list AND
  retains retired "uniformly on the serial-1 `Pin`". MINORs W4–W7 + NITs N1–4 (see Open items).
- **Taxonomy encode round — CLOSED (2026-07-04).** My HOLD (4 MAJOR / 6 MINOR / 3 NIT) and cold's
  HOLD (7 MAJOR / 5 MINOR / 3 NIT) are both fully folded in `1289bef` — verified from disk this
  round, findings archived. One residue became this round's W3 (the §Anchoring half-fix); one fix
  regressed into this round's W1 (the role-table splice).
- **Multi-party documents, SECOND CUT — my HOLD-4 is FOLDED (2026-07-04).** The 2nd-cut note
  (`docs/canon/vdti-area-multi-party-documents.md`) absorbed all of F1–F15+N1–3: rescission keying is
  now `hash(G | said_b)` (participant-blind AND grant-blind — the F1 fix done properly), the nonce
  rule landed for every gated doc on public structure (F2), DAG-descent is derived as a placement
  consequence with structural language (F3), the honored predicate carries the inv-8 freshness bar
  (F4), grants became **T2 `Gnt` ← `Ath`** (resolving my F13 constraint properly — the taxonomy
  refactor was the mechanism), disjoint-periods at doc-validation, `MAX_GRANT_ADDS = 64`,
  reserved-name convention `vdti/doc/v1/...`, custody.md backport noted at §8. Editors/commenters
  role split (view/comment/edit triad); comments mechanism deferred. Nothing outstanding from that
  round; findings file archived.

- **Prior arc (convergence / effective-SAID) — SETTLED + FOLDED, warm fold re-review WAIVED.** The
  live-tips + pure-walk + gate-in-both-modes model is canon (inv 13 F-F, inv 17, vdtid-services
  §1e/§1i, fed §1e gate bullet) and landed (`e369180`): pure-walk reading with a DERIVED seal
  ("frozen" = origination posture only; a content fork resolves by `Rec` OR a burying
  seal-advancer; identical held sets ⇒ identical reading + digest — verified both arrival orders),
  live-tips digest (settled content drops out, privileged never settles), shape-validity gate at
  the acceptance point in both modes. My re-encode HOLD-4 (Matrix-2 burial cells; system-thesis
  freeze section; derived-seal rule pinning; `Dec`-burial seam + L1–L5) was **folded in
  `47d98af`..`ef8539f`** (residue removal, polish, SAID/prefix rationale, glossary + SAD mods,
  canon/working-surface sync) — **Jason waived the warm re-review of that fold** (2026-07-04; canon
  was expected to keep moving). Digest-model history (one day, three generations): seal-relative
  `4beb456` (HOLD-2) → all-tips `fc6c91b`+`5119814` (HOLD-2 + my adjudication of the cold findings)
  → **live-tips + pure-walk** (Jason's fix — kels recall; reviewed HOLD-4, folded). Nothing
  outstanding from that arc; both convergence findings files are archive-ready.

## Prior arc state (content-fork prevention, settled + encoded)

- **Content-fork prevention — SETTLED, ENCODED, REVIEWED, POLISHED.** The model: witness-config
  **majority floor `threshold > signers/2`** + the kind-scoped witnessing ladder (content
  first-seen, one sibling per `(prefix, serial)`; privileged up to **two** per position — two
  both-witnessed siblings ARE the `disputed` proof; the resolving repair = the first privileged
  sibling, no separate clause) ⇒ **content forks on witnessed chains are prevented below
  fork-cost `2·threshold − signers`** (a priced dial: `fork-cost = threshold − slack`;
  double-signing attributable). Option (b): user-IEL content gated at its own position alongside
  Q1 anchors; federation IEL exempt; SEL rides the cross-layer theorem. Counting is
  **selection-scoped**. Recoverability cap **`threshold ≤ min(|roster| − 2, signers − 1)`**,
  `signers = 1` waiver ({1,1} evict-one = position-luck, warned); re-check on **any
  config-changing `Wit`** (incl. config-only). **Single-add federation `Wit`** (`add` scalar,
  `Fcp` exempt, `cut` a list). **`forks` → `fork`** (one root; unnamed branches close below-seal +
  by-descent — verified closure equivalence). Serialization: governance safety-critical
  everywhere; content-rail = liveness on witnessed chains, safety-critical direct-mode/solo.
  Propagation premise = success-rate/latency only, never safety. §1a reachability property
  verified (one `Wit` carries the full config delta → no forced invalid intermediates).
- **My verdicts this arc (all archived):** majority-quorum canon review **HOLD-2** → fold review
  **MERGE** (both Fable completions verified: waiver necessary+honest; collapse
  outcome-identical) → encode review **MERGE** (clusters A–J faithful; manifest independently
  clean incl. sad/policy/diagram; no cross-doc contradiction). Cold ran HOLD-11 on the canon
  round; its seam findings (config-transition F1, single-add P5) landed as the canon seam layer.
- **All my open findings are folded** (verified from disk 2026-07-03): the four fold-review LOWs
  (proof premise now lists the roster-delta straddle; area-fed elliptical bounds fixed;
  first-seen naming unified — 0 "first-receive" hits; area-sel has the transitive fork-cost
  note) and ALL of encode F1–F5 in `89f74cd` — F1 (content-rail uniformly "safety-critical on
  direct-mode") and the F2–F5 de-dup collapses exactly as recommended (verification's FORCE
  content-leg → split + §Federation-convergence ref; event-shape's witnesses/bounds/roster rows →
  shape/bound + ref, rationale prose removed). The "(verify at review)" tag is resolved out of
  area-fed.
- **Commit sequence (this layer):** `fbc62eb` majority-quorum canon → `a3e371e` re-encode landed
  design → `89f74cd` review polish → `5a5932b` **new `docs/design/README.md`** (reading-order map —
  I have not reviewed it) → `4b6c62c` clarify reconciliation.md → `b526dd3` SiblingLocked/retention
  split → `4beb456` **Eliminate synthetic SAIDs** (seal-relative digest; reviewed HOLD-2) →
  `fc6c91b`+`5119814` **all-tips** (reviewed HOLD-2) → `e369180` **Separation of duties
  (merge/persist)** = the live-tips + pure-walk re-encode (reviewed HOLD-4) → `47d98af`..`ef8539f`
  the fold + polish/glossary/custody layer (warm fold re-review waived by Jason, 2026-07-04).
- **Repair-completeness model (settled r1–r5, re-scoped to the residual):** root-pointing
  (`fork` = one root condemning its subtree) + deadness-descends (same-chain + **IEL→SEL anchor
  edge only**) + bounded fork (depth ≤ 64/lineage; retention ≥ 2/position; the ladder) + two
  guards (no-self-condemnation over the full-span walk — tight form
  `root.parent = v_{d-1} ∧ root ∉ walkback` in impl-notes; content-only) + retain-and-count
  (scoped: passes hard auth, fails content-only; junk dropped) + `{Dec, content}` tier-rank +
  D1 two-valued finality (no-resurrection unconditional; resolution-stability gated;
  residuals: eclipse + historical reserve compromise + withheld-body split + roster-delta
  straddle) + cross-layer theorem (valid SEL fork ⇒ IEL fork; anchor-monotonicity with
  skip-unattributable). Runs against the residual population (direct-mode, fork-cost byzantine,
  straddles, split-stalls, mixed races).
- **Canon:** `.working/vdti-repair-completeness-proof.md`, `vdti-invariants.md` (inv 4/12/13/14/17),
  `vdti-area-{kel,iel,sel,federation-witnessing}.md`, `vdti-implementation-notes.md`. **Landed:**
  protocol-doctrine, system-thesis, **design/README.md (new)**, event-shape, six `kel/` docs,
  sad/ + policy/ trees, `docs/.terminology-forbidden` (root-pointing + fork-scalar bans).

## Open items

- **Phase-2 `docs/design/` landing PR-by-PR. PR#11 (KEL) MERGED (`a310c72`). CURRENT: VDTI-16 IEL primitive →
  my verdict MERGE.** The IEL primitive (6 docs, fresh encode) is a faithful/complete/greenfield/jargon-free
  encode of `vdti-area-iel.md` (+ federation-witnessing / delegation / multi-party); all 9 properties verified
  design↔canon, `make all` 0, the 3 high-risk areas (facet-`Wit` / sealed-branch verdict / `kills[]` privacy
  split) re-attacked and held. **My prior `iel/delegation.md` carry-forward is RESOLVED** (the stub reconciled to
  the fail-secure model — delegate `bound` public in `kills[]`, `Trm` pin-only, `DLG_RSC_TOPIC`, fail-secure
  default). **TWO new findings, both low/nit, non-blocking:** N1 [completeness] events.md:366-370 threshold-
  anchoring table omits the user IEL `Icp` ← KEL `Rot` row (has the federation `Fcp`; stated at events.md:62 /
  verification.md:106) — add for symmetry; N2 [consistency/nit] burying-seal framing varies (log.md:74/
  reconciliation.md:346 "an `Evl`/`cut` `Evl`" vs merge.md:73 + reconciliation Position 3 "any governance
  seal-advancer") — widen log.md:74. **Deferred to later PRs (out of scope, not gaps):** `sel/`,
  `federation/witnessing.md`, `features/` (credentials + multi-party), services docs — the 46 forward-refs into
  them are sanctioned (`lint-docs` errors:0). `features/multi-party/documents.md` remains a diagram stub (like
  `federation/bootstrap.md`); `iel/delegation.md` is a stub too but now model-current. **Whole-canon SHIP minors'
  disposition (still open canon-side, non-blocking):** F2 (doc-policy §E `[fresh]`), F3 (token-store supplemental
  dead-file pointer), F4 (inv:667 tail). **When the next design PR arrives (likely `sel/`):** re-read the canon
  regions it encodes + the landed design from disk; watch that N1/N2 got folded into the IEL docs; confirm the
  deferred-doc forward-refs resolve as those docs land.
- **Prior fold-and-diagrams HOLD (2026-07-04) — disposition unknown from this session:** W1–W3 (MAJOR, mechanical: de-splice event-shape's
  role-vocabulary table (:132-136 — 3-cell header vs 7-cell delimiter, `content` row spliced into
  `delegates`; a FRESH fold regression, renders as raw text); flip the six parent→child
  `|previous|` arrows in the three stubs (bootstrap ×3, delegation ×2, reconciliation ×1); add
  `Ath ↔ Gnt` to event-shape:377-381's pair list + kill the retired "uniformly on the serial-1
  `Pin`" at :383) then W4–W7 (multi-party stub's `|content|`-on-a-`Pin` label → `Icp.data`; inv 18 +
  inv 4 class enumerations missing `grant`/`bound`; reconciliation stub "losing branch" → root;
  multi-party stub orphaned — no inbound link) + N1–4. A cold pass ran in parallel — expect overlap
  on W1/W2/W4/W6 (render-and-read-reachable).
- **Unreviewed surfaces:** `docs/design/README.md` (5a5932b) — still no dedicated round (this round
  read only its forthcoming section). The convergence-arc fold landed without a warm re-review
  (waived). `vdti-protocol-doctrine-freshread-brief.md` sits in `.working/` (queued, not yet mine).
- **Deferred in canon (tracked there, not by me):** the `compaction.md`/`said.md` §Rule-1
  SAID-invariance fix (multi-party §7 "Deferred to the encode"). The excalidraw→mermaid re-encoding
  is DONE (this round's target; drawing + lint-diagrams deleted, exclusion removed).

## Pending externally

- Forward-ref'd / unbuilt: `iel/` + `sel/` (the cross-layer bundle lands there),
  `federation/{witnessing,bootstrap}.md`, `operations/{multi-party-governance,recovery-workflow}.md`,
  `features/credentials/`, `infrastructure/vdtid.md`. Full-out design encoding planned after this
  review iteration set.

## My findings files

**Active (round open):** `.working/vdti-holistic-review-9-warm-findings.md` (REPORT-ONLY — holistic-9
FIDELITY-TO-CANON + all axes, validate the round-8 fold + PRESSURE-TEST the killswitch/forced-brick + same-serial
topology; **HEADLINE: BOTH pressure-tests SOUND (NO P0)** — (A) killswitch faithful to canon + forced-brick
trichotomy airtight (attacked A1-A4; KERI §4 consistent); (B) same-serial sound (cross-serial pair collapses via
lineage-acceptance); my round-8 F1 sweep FOLDED complete. **2 P2:** F1 ~11 "past the fork" survivors (sound but not
"at the last seal/same serial" — incl. `kel/compromise:240` the subagent missed); F2 low — two-tier capability model
vs killswitch "signing key" referent (K₀/K₁). `make all` 0/724; 2026-07-11).
**Prior (holistic-8; REPORT-ONLY — collapse theorem SOUND, its P1 sweep NOW FOLDED complete):**
`.working/vdti-holistic-review-8-warm-findings.md` (holistic-8; collapse theorem verified sound adversarially; P1
verdict-predicate sweep — since folded; F2/F3 P2; `make all` 0/720; 2026-07-11).
**Prior (holistic-7; REPORT-ONLY — its ONE P0 acceptance-conflation NOW FOLDED):**
`.working/vdti-holistic-review-7-warm-findings.md` (holistic-7
FIDELITY-TO-CANON + all axes, the author-flagged PRESSURE-TEST of the `witnessed`/acceptance seam; **pressure-test
CONFIRMED (author right)**; **ONE P0: F1** — acceptance conflated with the first-seen-decline trigger (self-signing
treated as acceptance): canon root `federation-witnessing:350-354` + design leak `kel/verification:418-423`; break =
false `disputed` under partition when a witness self-signs the losing sealed sibling; masked-not-fixed by the round-6
threshold-hardened FORCE count; corrected wording proposed for both sites; properties 1–6 hold, round-6 P0 folded
(threshold-independent zero survivors); `make all` 0/715; 2026-07-11). **Prior (holistic-6; REPORT-ONLY — its ONE P0
NOW FOLDED, zero threshold-independent survivors):** `.working/vdti-holistic-review-6-warm-findings.md` (holistic-6
FIDELITY-TO-CANON validating the one-sealing-per-position canon change; **ONE P0: F1** — `disputed` reading fires
"threshold-INDEPENDENT on merely-HELD sealed branches" at 5 sites (kel-recon:485/539, kel-verif:393, iel-recon:363,
iel-verif:349) vs canon inv 13/17 + the CORRECT owner pd:1039 + each file's own witnessing rule; re-opens the
durable-`disputed` grief (a held witness-declined deferred-pending sibling gets counted → false disputed → abandons
recoverable prefix); fix = gate on "each witnessed at threshold". **F2[P2]:** 3 "holding both → disputed directly"
sites lack the "accepted" qualifier. Witnessing side landed correctly everywhere; {Evl,Evl}-honest-partition negated;
sealing-serialization-safety GONE; both my round-5 P2s folded; `make all` 0/714; 2026-07-11). **Prior (holistic-5;
REPORT-ONLY — NO P0/P1, my holistic-4 F1 RESOLVED):** `.working/vdti-holistic-review-5-warm-findings.md`
(FIDELITY-TO-CANON + complete, all 5 axes, design + canon; flagged changes clean/consistent/canon-faithful;
negative-check O(1)-first result-equiv to canon + consistent ×6 sites; exclude-self `signers ≤ |roster| − 1` landed;
delegation.md faithful; 2 P2-low both now folded (holistic-6); `make all` 0/714; 2026-07-11). **Prior (holistic-4;
REPORT-ONLY — F1 RESOLVED via exclude-self fold):**
`.working/vdti-holistic-review-4-warm-findings.md` (SOUNDNESS / first-reader property-verification; **F1[P1]
federation bounds jointly UNSATISFIABLE at `|roster|=4, signers=4`** (floor `≥3` vs cap `≤2`; only empty corner;
general constraint `signers < 2·|roster|−4`) — fail-safe gap-in-argument + footgun, **now folded** (exclude-self
pool); all 4 holistic-3 collapses preserve soundness; P1-P9 hold; `make all` 0/703; 2026-07-11). **Prior
(holistic-3; REPORT-ONLY — F1/F3/F4/F5 collapses + F2 direction fix all FOLDED since):**
`.working/vdti-holistic-review-3-warm-findings.md` (structural/refactor-pointer/readability pass;
F1 prefix/SAID algorithm re-described (owner sad/said.md; Jason-confirmed seed), F2 iel/log:15 "anchors in" inversion,
F3 threshold-bounds triplicated, F4 "why synthetic not digest" dup, F5 event-shape divergence re-description;
`make all` 0/693; 2026-07-11). **Prior (sealing-rename; MERGE delivered):**
`.working/vdti-sealing-rename-review-warm-findings.md` (MERGE — sealing-rename review
(governance → sealed/sealing, `3613342`+`4f6a1f7`); the rename is **complete + consistent + meaning-preserving** —
umbrella flipped cleanly (tolerant sweep clean), reserved senses kept, no sealed↔sealing inversion, KEL broadening
complete (protocol-doctrine ×4), recovery-doctrine `Rot` untouched, filename unified, `make all` 0; **ALL findings
P2** — F1 redundant "governance `Evl`" ×2 (area-iel:33 bold-hidden, invariants:64 → "`Evl`"), F2 reconciliation:305
"holding sealed events"→"pausing sealing" nit, F3 low/out-of-scope "sealing kinds" vs pre-existing "sealed/seal-
advancing kinds"; 2026-07-11). **Prior (holistic-2; HOLD-1 delivered — protocol-doctrine:208 F1 FOLDED to "being
anchored by"; the trust-tree flip reviewed there is now stable):** `.working/vdti-holistic-review-2-warm-findings.md`
(HOLD-1 — holistic review 2, soundness +
fidelity, simplification-drift weighted; THE trust-tree direction flip down→up (`72c941f`) is **mechanically sound +
thoroughly applied + greenfield** — inv 4 now "Manifest-up + pin-down", design matches (glossary/event-shape/mermaid
TB→BT), half-flip regression sweep clean of round-1 residuals; `make all` 0, floor census 0; **HOLD-1 =
`protocol-doctrine.md:208`** "reach a tier by **anchoring in a lower-layer event**" inverts direction (contradicts
inv 4 "anchors up" + its own next clause "is anchored by the KEL kind" + :1225 "resolves down") → fix "being anchored
by"; +1 low F2 canon delegation.md:71/116 "pin up" collides with flipped pin-down; 2026-07-10). **Prior (holistic-1;
HOLD-1 delivered — README:4 F1 FOLDED + reframed into the full direction flip reviewed this round; F2 seal-advancer
nit appears reworded):** `.working/vdti-holistic-review-warm-findings.md` (HOLD-1 — holistic fidelity review,
all landed `docs/design/`; the KEL `recovery.md`→`compromise.md` re-scope is faithful (compromise.md doctrine
matches canon-kel; attach shapes→merge.md +87, races→reconciliation Matrix 3, locked-portion→log.md — all clean),
round-2 floor survivors folded (wrapped-token lint added, census 0), all 6 properties hold **except** property 3;
`make all` 0, greenfield/jargon clean; **HOLD-1 = `README.md:4` inverts the trust-tree** ("each layer below assumes
the ones above it" — contradicts its own :12 + canon-kel:24-25 + inv 3; fix "assumes the ones **below** it"); +1 nit
F2 "burying seal-advancer" over-applied into deliberate-recovery worked scenarios (kel/reconciliation.md:612/632/634);
2026-07-10). **Prior (VDTI-16 IEL review 2; HOLD-1 delivered, folded — the 2 wrapped `majority floor` survivors + the
wrapped-token lint gap are RESOLVED this round):** `.working/vdti-16-iel-review2-warm-findings.md` (HOLD-1 — VDTI-16
IEL primitive review 2, floor rename + fold; the floor **classification** is 100% clean (no witnessing↔authorization
swap, full wrap-tolerant census); 9 properties hold post-churn, anchor matrix + F-2 fold + round-1 N1/N2 all landed,
`make all` 0; **HOLD-1 = two line-wrapped `majority floor` survivors the line-based lint can't see** —
`iel/verification.md:153`→`authorization floor`, `kel/reconciliation.md:449`→`witnessing floor`; +2 nits
(a→an, reconciliation:346 residual); 2026-07-10). **Prior (round 1; MERGE delivered, folded into review 2):**
`.working/vdti-16-iel-review-warm-findings.md` (MERGE — VDTI-16 IEL primitive, fresh
encode, fidelity-to-canon, pre-merge; 6 docs `iel/{log,events,merge,reconciliation,verification,delegation}`;
**faithful/complete/greenfield/jargon-free**, all 9 properties verified design↔canon, `make all` 0 (0 errors / 46
forward-refs), the 3 high-risk areas (facet-`Wit` / sealed-branch verdict / `kills[]` privacy split) re-attacked
and held; **my prior delegation-stub carry-forward RESOLVED**; 2 findings low/nit — N1 events.md:366-370 table
omits user `Icp` ← KEL `Rot`, N2 log.md:74 burying-seal framing; 2026-07-10). **Prior (MERGE delivered; PR#11
KEL MERGED `a310c72`):** `.working/vdti-final-review-warm-findings.md` (MERGE — final confirmation pass,
fidelity-to-canon; PR#11 KEL primitive; **all 8 folded findings verified landed faithfully**, all 9
properties re-verified design↔canon, `make all` 0, greenfield clean, merged supplemental internally consistent;
its one carry-forward — the `iel/delegation.md` delegate-bound stub — is now RESOLVED in the IEL PR; 2026-07-10).
**Prior (MERGE delivered; its F1/F2/F3 all FOLDED as folds #3/#5/#6 in PR#11):**
`.working/vdti-reconcile-review-warm-findings.md` (MERGE — phase-2 reconciliation, fidelity-to-canon; the first
design PR is a faithful/complete/consistent/greenfield encode of the ship-reviewed canon; all 9 properties
verified design↔canon; SAID §Rule-1 fix + four-state/merge-outcome backport landed; 3 [minor] — event-shape:476
grant-doc-vs-rescind-doc mislabel, reconciliation.md Matrix-1 below-seal position, Matrix-2 Disputed-source
cross-ref; `make all` 0, 2026-07-10). **Prior (SHIP delivered; whole-canon promotion gate):**
`.working/vdti-canon-holistic-review-warm-findings.md` (SHIP — all 14 canon files; no blocker/major; seams +
crown jewels verified adversarially; my Round C R3 sweep verified LANDED; 4 [minor]/[nit] — KEL 5-vs-6 (resolved
in the design PR), doc-policy §E `[fresh]`, token-store supplemental pointer, inv:667 tail; `make all` 0,
2026-07-10). **Prior (MERGE delivered; its one [consistency] sweep RESOLVED):**
`.working/vdti-failsecure-fold-review-warm-findings.md` (MERGE — R1–R6 + layering fold faithful; the converged
break R1 GENUINELY CLOSED (earliest floor + as-of, verified adversarially); layering sound; R2/R4/R5/R6 sound;
one [consistency] sweep — R3 doc-member carve-out, since propagated; `make all` 0, 2026-07-10). **Prior (HOLD
delivered; its F1/F2/F3 RESOLVED by the fold → R1/R4/R5):** `.working/vdti-failsecure-review-warm-findings.md`
(HOLD — 3 reconcile items:
earliest-issuance lower bound, private lookup-`Icp` publication, inv 4 stale raw `said(cred)`, 2026-07-09).
**Prior (HOLD; F1 the `attribute-all` over-reach RESOLVED at the root by the fail-secure rework):**
`.working/vdti-rereview2-warm-findings.md` (HOLD — the `attribute-all` opt-in over-claims a selective "confirm
clean" the addressing model forbids, 2026-07-09). **Prior (HOLD; the two-SEL correlation over-claim RESOLVED
by the B1 rework):** `.working/vdti-rereview-warm-findings.md` (HOLD — B1 positive-presence safety called
"sound", later BROKEN by cold B-1 + reworked, 2026-07-09). **Prior (folded — the encode-review HOLD's fixes
landed):**
`.working/vdti-first-seen-encode-review-warm-findings.md` (MERGE — the canon encode,
faithful/complete/consistent, 4 minor/nit — all folded, 2026-07-09) + the cold encode HOLD (B1/C1/C2/M1–M5,
folded). **Earlier (folded):** `.working/vdti-effective-said-warm-review-findings.md` (HOLD — reversal
sound+necessary, §2a completeness gaps F1–F5, folded into the encode). **DISPOSED + archived (2026-07-08 — L2
resolved + folded):** `archived/vdti-first-seen-warm-review-findings.md` (HOLD — ledger-completeness, the
first-seen reversal review, 2026-07-07). **Prior (disposition unknown this session):**
`.working/vdti-fold-and-diagrams-review-warm-findings.md`
(HOLD-with-findings, the fold + mermaid + removal round, 2026-07-04). **Closed/archived:** the
taxonomy-encode dual-pass findings (`vdti-taxonomy-encode-review-{warm,cold}-findings.md`, both in
`.working/archived/`) — every finding verified folded this round (the faithfulness map is in the
active findings file); the multi-party second-cut HOLD-4 is folded into
`docs/canon/vdti-area-multi-party-documents.md`; both convergence-round findings files are archived
(that arc closed, fold waived).

**Archived (`.working/archived/`):** `vdti-repair-completeness-findings-warm-r{1..5}.md` ·
`vdti-repair-completeness-encode-findings-warm.md` ·
`vdti-doctrine-quality-reverify-canon-findings.md` ·
`vdti-majority-quorum-canon-review-warm-findings.md` ·
`vdti-content-fork-prevention-fold-review-warm-findings.md` ·
`vdti-content-fork-prevention-encode-review-warm-findings.md`.
