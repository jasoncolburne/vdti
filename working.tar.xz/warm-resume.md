# warm-resume — warm-session context restore (post-compaction)

**This is the WARM session's resume. Never hand it to a cold pass** (asymmetric decorrelation:
warm gets everything, cold gets nothing — memory `feedback_dual_review_protocol`).

**Canon load: WHEN A BRIEF IS IN HAND, not at resume (standing, Jason 2026-07-03).** As the warm
reviewer you need a primed context — that priming IS what makes the warm pass warm. But the canon
may move between rounds, so front-loading it at resume wastes tokens on priming that goes stale;
load it fresh at the moment a brief arrives. Then read from disk: the whole canon
(`vdti-repair-completeness-proof.md`, `vdti-invariants.md`, `vdti-implementation-notes.md`, all
`vdti-area-*.md`). Do **not** load the landed `docs/design/` tree up front — canon and landed docs
are two encodings of ONE design; only one set belongs in memory, and **canon is canonical** (docs
are re-read per-brief as review evidence, when a brief requires them or Jason asks). Jason
overrides with a note when he wants otherwise.

**Maintenance (standing, Jason 2026-07-02): update this file at the end of every review round** —
verdict delivered ⇒ refresh arc state / open items here, same-turn (the warm twin of
`design-resume.md`). Standing rules live in project memory (auto-loaded); this file carries
**arc state only**. For reasoning detail the compaction summary lost, grep the prior transcript:
`/Users/jason/.claude/projects/-Users-jason-github-com-jasoncolburne-vdti/a98d268e-b7e9-4ad1-bfb6-51fb9c87edd3.jsonl`.
Re-read every file from disk each round regardless — this file is orientation, never evidence.

## Role

Warm (contextual) reviewer, one effort level up, in Jason's hand-coordinated dual-pass topology.
Jason drives all design decisions and all git. A brief arrives as a `.working/*.md` path each
turn; findings go to the brief-named file — MERGE / HOLD-N at top, tagged findings, quoted
doc:line, `make all` exit 0 as a done-gate, edit nothing while reviewing. Warm sees prior cold
output by design (passes run simultaneously, so the in-flight cold is invisible by timing only);
derive findings independently, then state where cold would converge as a shared-blind-spot flag.

## Arc state (2026-07-04, HEAD `ef8539f` — tree clean)

- **CURRENT ROUND — multi-party documents, SECOND CUT: my verdict HOLD-4 (2026-07-04, findings
  `vdti-multi-party-2ndcut-review-warm-findings.md`), awaiting the fold.** The cut under review
  (`vdti-area-multi-party-documents.md`): a DAG of attributed SADs (custody `owner`+`topic`+
  SEL-anchor per version), creator-governed per-period access-list membership (a grant `Ixn` on the
  governance SEL opens `[F_x, B_x]` on the member's own IEL; per-period rescission lookup-SEL
  `{doc_prefix, G_x}` with a gated `bound`), honored iff `F ≤ V ≤ B` intra-chain; freeze =
  bound-all + `Dec`-governance; re-add = a fresh period. **Model confirmed sound** — the MAJORs are
  statement/rule-completion fixes: **F1** the "unguessable to a witness" key claim names the wrong
  adversary (a witness HOLDS `G_x` — receipts sign the governance SEL's event SAIDs, and the
  rescission `Icp.data` carries `{doc_prefix, G_x}` cleartext; restate as **member-blind keying** —
  the member prefix is never a derivation input, which DOES hold). **F2** missing entropy rule:
  gated-doc SAIDs committed on public structure (grant-doc, rescind-doc, private-doc version SADs)
  are **offline confirmation oracles** without a nonce — denied≈absent can't defend a public hash;
  the §5 membership + co-authorship graph closures rest on this. **F3** "inv 13/17 reused down the
  DAG" overclaims — the anchor-edge leg is real reuse, DAG-descent is a feature placement rule
  (derive via placement/unplaceable-parents + re-issue); also ":147 a divergent member is
  compromised" is identity-framed. **F4** the honored predicate's open-period-by-absence read has
  no freshness bar (a to-tip loss-of-trust read → F8 multi-source + fail-secure REFUSE;
  document-policy §F states it for creds, the note never mentions freshness). **F5–F15 minors**
  ride (incl. F5 "`Icp` is anchored" vs inv 15's v1-anchoring — same drift in landed
  `custody.md:70`; F7 `DOC_RSC` `Kil` slot unpinned → govern per inv 4's total rule; F10 §2's
  doc-prefix→creator arrow needs "the verifier holds V0"; F13 the grant-tier open is constrained by
  no-sealed-content-SEL-kind + inv 12 self-pricing — resolution is creator-IEL hardening config or
  new primitive surface) + N1–3. Expect cold convergence on F1/F3 (note+canon-reachable); F2 is
  missable; F5/F7/F13's canon legs need the invariants open.

- **Prior arc (convergence / effective-SAID) — SETTLED + FOLDED, warm fold re-review WAIVED.** The
  live-tips + pure-walk + gate-in-both-modes model is canon (inv 13 F-F, inv 17, vdtid-services
  §1e/§1i, fed §1e gate bullet) and landed (`e369180`): pure-walk reading with a DERIVED seal
  ("frozen" = origination posture only; a content fork resolves by `Rec` OR a burying
  seal-advancer; identical held sets ⇒ identical reading + digest — verified both arrival orders),
  live-tips digest (settled content drops out, privileged never settles), shape-validity gate at
  the acceptance point in both modes. My re-encode HOLD-4 (Matrix-2 burial cells; system-thesis
  freeze section; derived-seal rule pinning; `Dec`-burial seam + L1–L5) was **folded in
  `47d98af`..`ef8539f`** (residue removal, polish, SAID/prefix rationale, glossary + SAD mods,
  canon/working-surface sync) — **Jason waived the warm re-review of that fold** (2026-07-04; canon
  was expected to keep moving). Digest-model history (one day, three generations): seal-relative
  `4beb456` (HOLD-2) → all-tips `fc6c91b`+`5119814` (HOLD-2 + my adjudication of the cold findings)
  → **live-tips + pure-walk** (Jason's fix — kels recall; reviewed HOLD-4, folded). Nothing
  outstanding from that arc; both convergence findings files are archive-ready.

## Prior arc state (content-fork prevention, settled + encoded)

- **Content-fork prevention — SETTLED, ENCODED, REVIEWED, POLISHED.** The model: witness-config
  **majority floor `threshold > signers/2`** + the kind-scoped witnessing ladder (content
  first-seen, one sibling per `(prefix, serial)`; privileged up to **two** per position — two
  both-witnessed siblings ARE the `disputed` proof; the resolving repair = the first privileged
  sibling, no separate clause) ⇒ **content forks on witnessed chains are prevented below
  fork-cost `2·threshold − signers`** (a priced dial: `fork-cost = threshold − slack`;
  double-signing attributable). Option (b): user-IEL content gated at its own position alongside
  Q1 anchors; federation IEL exempt; SEL rides the cross-layer theorem. Counting is
  **selection-scoped**. Recoverability cap **`threshold ≤ min(|roster| − 2, signers − 1)`**,
  `signers = 1` waiver ({1,1} evict-one = position-luck, warned); re-check on **any
  config-changing `Wit`** (incl. config-only). **Single-add federation `Wit`** (`add` scalar,
  `Fcp` exempt, `cut` a list). **`forks` → `fork`** (one root; unnamed branches close below-seal +
  by-descent — verified closure equivalence). Serialization: governance safety-critical
  everywhere; content-rail = liveness on witnessed chains, safety-critical direct-mode/solo.
  Propagation premise = success-rate/latency only, never safety. §1a reachability property
  verified (one `Wit` carries the full config delta → no forced invalid intermediates).
- **My verdicts this arc (all archived):** majority-quorum canon review **HOLD-2** → fold review
  **MERGE** (both Fable completions verified: waiver necessary+honest; collapse
  outcome-identical) → encode review **MERGE** (clusters A–J faithful; manifest independently
  clean incl. sad/policy/diagram; no cross-doc contradiction). Cold ran HOLD-11 on the canon
  round; its seam findings (config-transition F1, single-add P5) landed as the canon seam layer.
- **All my open findings are folded** (verified from disk 2026-07-03): the four fold-review LOWs
  (proof premise now lists the roster-delta straddle; area-fed elliptical bounds fixed;
  first-seen naming unified — 0 "first-receive" hits; area-sel has the transitive fork-cost
  note) and ALL of encode F1–F5 in `89f74cd` — F1 (content-rail uniformly "safety-critical on
  direct-mode") and the F2–F5 de-dup collapses exactly as recommended (verification's FORCE
  content-leg → split + §Federation-convergence ref; event-shape's witnesses/bounds/roster rows →
  shape/bound + ref, rationale prose removed). The "(verify at review)" tag is resolved out of
  area-fed.
- **Commit sequence (this layer):** `fbc62eb` majority-quorum canon → `a3e371e` re-encode landed
  design → `89f74cd` review polish → `5a5932b` **new `docs/design/README.md`** (reading-order map —
  I have not reviewed it) → `4b6c62c` clarify reconciliation.md → `b526dd3` SiblingLocked/retention
  split → `4beb456` **Eliminate synthetic SAIDs** (seal-relative digest; reviewed HOLD-2) →
  `fc6c91b`+`5119814` **all-tips** (reviewed HOLD-2) → `e369180` **Separation of duties
  (merge/persist)** = the live-tips + pure-walk re-encode (reviewed HOLD-4) → `47d98af`..`ef8539f`
  the fold + polish/glossary/custody layer (warm fold re-review waived by Jason, 2026-07-04).
- **Repair-completeness model (settled r1–r5, re-scoped to the residual):** root-pointing
  (`fork` = one root condemning its subtree) + deadness-descends (same-chain + **IEL→SEL anchor
  edge only**) + bounded fork (depth ≤ 64/lineage; retention ≥ 2/position; the ladder) + two
  guards (no-self-condemnation over the full-span walk — tight form
  `root.parent = v_{d-1} ∧ root ∉ walkback` in impl-notes; content-only) + retain-and-count
  (scoped: passes hard auth, fails content-only; junk dropped) + `{Dec, content}` tier-rank +
  D1 two-valued finality (no-resurrection unconditional; resolution-stability gated;
  residuals: eclipse + historical reserve compromise + withheld-body split + roster-delta
  straddle) + cross-layer theorem (valid SEL fork ⇒ IEL fork; anchor-monotonicity with
  skip-unattributable). Runs against the residual population (direct-mode, fork-cost byzantine,
  straddles, split-stalls, mixed races).
- **Canon:** `.working/vdti-repair-completeness-proof.md`, `vdti-invariants.md` (inv 4/12/13/14/17),
  `vdti-area-{kel,iel,sel,federation-witnessing}.md`, `vdti-implementation-notes.md`. **Landed:**
  protocol-doctrine, system-thesis, **design/README.md (new)**, event-shape, six `kel/` docs,
  sad/ + policy/ trees, `docs/.terminology-forbidden` (root-pointing + fork-scalar bans).

## Open items

- **My HOLD-4 on the multi-party second cut awaits the fold:** F1 member-blind keying restatement;
  F2 the nonce/entropy rule for gated docs whose SAIDs ride public structure; F3 the DAG-descent
  derivation (placement, not inv 13/17 reuse) + the identity-framed clause; F4 the honored
  predicate's freshness bar; F5–F15 + N1–3 (F5 also touches landed `custody.md:70` — the
  Icp-anchored phrasing vs inv 15). Findings file below; re-review on the fold brief.
- **Unreviewed surfaces:** `docs/design/README.md` (5a5932b) — no review round has covered it yet.
  The convergence-arc fold (`47d98af`..`ef8539f`) landed without a warm re-review (waived).

## Pending externally

- Forward-ref'd / unbuilt: `iel/` + `sel/` (the cross-layer bundle lands there),
  `federation/{witnessing,bootstrap}.md`, `operations/{multi-party-governance,recovery-workflow}.md`,
  `features/credentials/`, `infrastructure/vdtid.md`. Full-out design encoding planned after this
  review iteration set.

## My findings files

**Active (round open):** `vdti-multi-party-2ndcut-review-warm-findings.md` (HOLD-4, the
multi-party second-cut round, 2026-07-04). **Archive-ready (convergence arc closed, fold waived):**
`vdti-convergence-reencode-review-warm-findings.md` (HOLD-4, folded) and
`vdti-convergence-encode-review-warm-findings.md` (HOLD-2 + the cold-findings adjudication §,
superseded by the live-tips rework).

**Archived (`.working/archived/`):** `vdti-repair-completeness-findings-warm-r{1..5}.md` ·
`vdti-repair-completeness-encode-findings-warm.md` ·
`vdti-doctrine-quality-reverify-canon-findings.md` ·
`vdti-majority-quorum-canon-review-warm-findings.md` ·
`vdti-content-fork-prevention-fold-review-warm-findings.md` ·
`vdti-content-fork-prevention-encode-review-warm-findings.md`.
