# warm-resume — warm-session context restore (post-compaction)

**This is the WARM session's resume. Never hand it to a cold pass** (asymmetric decorrelation:
warm gets everything, cold gets nothing — memory `feedback_dual_review_protocol`).

**Canon load: WHEN A BRIEF IS IN HAND, not at resume (standing, Jason 2026-07-03).** As the warm
reviewer you need a primed context — that priming IS what makes the warm pass warm. But the canon
may move between rounds, so front-loading it at resume wastes tokens on priming that goes stale;
load it fresh at the moment a brief arrives. **The canon lives at `docs/canon/`** (moved from
`.working/` 2026-07-04; `.working/` now holds only working-surface files — resumes, briefs,
findings, index, roadmap, archived/): read from disk the whole canon
(`vdti-repair-completeness-proof.md`, `vdti-invariants.md`, `vdti-implementation-notes.md`, all
`vdti-area-*.md`, `vdti-federation-inception-reference.md` — all under `docs/canon/`). Do **not**
load the landed `docs/design/` tree up front — canon and landed docs are two encodings of ONE
design; only one set belongs in memory, and **canon is canonical** (docs are re-read per-brief as
review evidence, when a brief requires them or Jason asks). The canon is greenfield-**exempt** (it
records decision evolution — "was `Del`" definitions etc.); the landed `docs/` tree is greenfield.
Jason overrides with a note when he wants otherwise.

**Maintenance (standing, Jason 2026-07-02): update this file at the end of every review round** —
verdict delivered ⇒ refresh arc state / open items here, same-turn (the warm twin of
`design-resume.md`). Standing rules live in project memory (auto-loaded); this file carries
**arc state only**. For reasoning detail the compaction summary lost, grep the prior transcript:
`/Users/jason/.claude/projects/-Users-jason-github-com-jasoncolburne-vdti/a98d268e-b7e9-4ad1-bfb6-51fb9c87edd3.jsonl`.
Re-read every file from disk each round regardless — this file is orientation, never evidence.

## Role

Warm (contextual) reviewer, one effort level up, in Jason's hand-coordinated dual-pass topology.
Jason drives all design decisions and all git. A brief arrives as a `.working/*.md` path each
turn; findings go to the brief-named file — MERGE / HOLD-N at top, tagged findings, quoted
doc:line, `make all` exit 0 as a done-gate, edit nothing while reviewing. Warm sees prior cold
output by design (passes run simultaneously, so the in-flight cold is invisible by timing only);
derive findings independently, then state where cold would converge as a shared-blind-spot flag.

## Arc state (2026-07-10 — canon SHIPPED; **phase-2 `docs/design/` reconciliation landing PR-by-PR** — PR#11 (branch `VDTI-10_kel-primitive`: KEL primitive + sad/ + policy/ + protocol-doctrine + event-shape + voice docs) reconciled to canon, once-reviewed MERGE/MERGE, **8 findings folded, final confirmation pass MERGE — clear to merge**; `iel/`, `sel/`, `federation/witnessing.md`, `features/`, services docs deferred to later PRs)

- **CURRENT ROUND — final confirmation pass (fidelity-to-canon, pre-merge): my verdict MERGE (2026-07-10, findings
  `.working/vdti-final-review-warm-findings.md`).** The reconcile round's MERGE/MERGE fold: **8 folded findings** —
  verified each landed faithfully from disk: (1) protocol-doctrine:222 `tier 1/2`; (2) event-shape:308 KEL heading
  mirrors the IEL `(+ Fcp …)`; (3) event-shape:476 SEL `Trm` = **rescind**-doc (my reconcile F1 fix); (4)
  reconciliation:104-106 `Empty`-vs-four-live-states; (5) reconciliation:149-151 Matrix-1 below-seal position (my
  reconcile F2); (6) reconciliation:238-242 Matrix-2 no-Disputed-source Row note (my reconcile F3); (7)
  verification:270-279 state→region()→effective_said table — landed as a **4-row superset** (adds Terminated→trusted)
  of the brief's "3-row", faithful; (8) glossary:111-115 Terminated/Terminal/Trm disambig. **All 9 named properties
  verified against canon** (design↔canon cited in findings): first-seen+two-tier, four-state walk-derived, formalized
  merge outcomes (Matrix 1 exhaustive/sound), fail-secure revocation+R6, cred=direct-anchored SAD + R1 earliest-anchor
  +tier-inversion (documents.md:55-63), layering (event-shape:200-202 vs area-iel:15-25), no direct mode,
  verdict-recoupled effective-SAID synthetic, SAID §Rule-1 form-dependent (said.md:120-130). `make all` **exit 0**
  (47 files / 527 OK / **0 errors** / 31 sanctioned forward-refs, prettier clean). **Greenfield voice holds** (3
  `previously/superseded` hits all present-tense RUNTIME, no design-history; `was \`X\`` grep clean). **Merged
  supplemental** `vdti-keri-acdc-comparison.md` internally consistent (no contradiction across the positioning-note +
  keripy-deep-dive halves; [TO VALIDATE] flags intentional, KERI-side). **ONE substantive note, OUT of this PR's
  scope (carry-forward for the `iel/` PR):** `iel/delegation.md:14`/mermaid:25 shows the **delegate** rescission `Trm`
  carrying **`manifest.bound`** — the retired pre-fail-secure shape; canon (area-sel:145/281, inv 4:86) + the design's
  own protocol-doctrine:778 + event-shape:476 put the **delegate** `bound` **public in the `Dth`'s `kills[]`**, `Trm`
  carries only its pin (only the **doc-member** `Trm` commits a gated rescind-doc; `features/multi-party/documents.md:18`
  gets that right — it's the *delegation* stub that's stale). Also `RSC_TOPIC` vs canon `DLG_RSC_TOPIC`, and
  fail-open-only framing. **Both `iel/delegation.md` + `features/multi-party/documents.md` are diagram stubs**
  ("_Forthcoming_", same species as in-scope `federation/bootstrap.md`) — presence intended, doctrine deferred; the
  stale delegate-bound is not a blocker for the KEL merge but the same class as fold #3, so should be reconciled when
  `iel/` lands. **Cold-overlap:** fidelity re-encode both passes inherit from one canon — folds are mechanical, a cold
  diff surfaces them identically; **Note 1 is warm-leaning** (needs the R3 delegate-vs-doc-member bound-placement
  framing a cold pass may lack).
- **PRIOR ROUND — phase-2 reconciliation (fidelity-to-canon): my verdict MERGE (2026-07-10, findings
  `.working/vdti-reconcile-review-warm-findings.md`).** First phase-2 PR: the landed `docs/design/` KEL group
  (`kel/{log,events,merge,reconciliation,recovery,verification}`), `event-shape.md`, `protocol-doctrine.md`,
  `system-thesis.md`, `glossary.md`, `README.md`, `sad/{sad,said,compaction,custody,availability}`,
  `policy/{policy,documents,evaluation}`, `federation/bootstrap.md` — reconciled to the ship-reviewed canon.
  **Read every in-scope design file from disk** vs the canon. **A faithful, complete, consistent, greenfield
  encode — no soundness break, no fidelity drift.** All **9 named properties verified faithful** (design↔canon
  cited in the findings): first-seen+two-tier (5 KEL / 8 IEL / 5 SEL kinds), four-state walk-derived,
  formalized merge outcomes (`Result<MergeTransition, MergeRejection>` — Matrix 1 exhaustive/sound), fail-secure
  revocation + R6, cred=direct-anchored SAD + **R1 earliest-anchor + tier-inversion counter-example landed**
  (documents.md:55-63), the layering principle (`kills` opaque to the IEL, event-shape:200-202 — no topic
  semantics in the chain), no direct mode, verdict-recoupled effective-SAID synthetic, and **the SAID §Rule-1
  fix LANDED** (said.md:120-130 now says the SAID is **form-dependent** / re-derivable-by-compacting-down — the
  old wrong "wire-form-invariance" claim my resume tracked as deferred is GONE). `make all` **exit 0** from root
  (lint-terminology 0, prettier 0, lint-docs errors 0 — 31 sanctioned forward-refs, no broken in-surface refs).
  Dead-model + bookkeeping-leakage + greenfield-voice greps all clean in `docs/design/` scope. **STALE-CONTEXT
  TRAP CAUGHT:** the design's four-state contradicted my ship-round context's three-state — but the canon was
  **reconciled to four-state after my earlier read** (`54e5137`, area-kel.md/area-vdtid Jul 10 05:21-05:23), so
  the design faithfully encodes the *updated* canon; re-read from disk corrected it (would've been a false
  "design ahead of canon"). Also resolved: the whole-canon **F1 (KEL 5-vs-6 count)** — the design uses "5 kinds,
  2 inception variants" (events.md:3 / event-shape:308), clearer than federation-ref's "6". **The THREE findings
  are all [minor], non-blocking:** F1 [consistency] event-shape:476 mislabels the doc-member rescission `Trm`'s
  gated **rescind**-doc as a "grant-doc" (and the `grant` role is Gnt-only per the vocab table :170-179 —
  internal inconsistency; fix at the sel/features encode); F2 [completeness] reconciliation.md:135 "three
  attach-positions covers every valid submission" doesn't tabulate the parent-strictly-below-seal case (uniform
  `Sealed`/`Disputed` by seal-cap invariant 5 — add a Position-0 line for the exhaustiveness claim); F3
  [clarity] Matrix 2 has no Disputed-source row + no cross-ref to Matrix 3 (which covers it). **Cold-overlap:**
  the crown-jewel soundness is a faithful RE-encode both passes inherit — decorrelated value is cold re-confirming
  design↔canon agree on *meaning* (esp. the four-state/merge-outcome backport that changed under this PR); F1 is
  a warm-leaning catch, F2/F3 mechanical.
- **PRIOR ROUND — whole-canon holistic ship-readiness gate: my verdict SHIP (2026-07-10, findings
  `.working/vdti-canon-holistic-review-warm-findings.md`).** Swept **all 14 `docs/canon/` files in one pass**
  (read fresh from disk — invariants 874ln + federation-witnessing 672ln paginated in full) against the 7 Cs;
  the gate before the canon is promoted into human-facing `docs/design/`. **The canon is a sound, coherent,
  composable, consistent, threat-covering foundation — no blocker, no major.** `make all` **exit 0** (46/545/0).
  **Crown jewels re-attacked, not affirmed:** R1 (earliest issuance floor) genuinely closed + consistently
  stated (inv 5:218 / inv 10:317 / area-sel:94 — verifier derives earliest itself, never trusts a supplied
  later position; re-anchor accepted structurally, inert at the cred layer); fail-secure revocation closes all
  four escape routes (forge / silent-un-revoke / re-anchor / stale-IEL-hide); the freshness gate (whole
  transitive set, time-triggered, no-single-tip synthetic satisfies the bar); the effective-SAID synthetic
  (flood-stable, verdict-recoupled, converges with deferred-deps); federation never-bricks (self-attest under
  new key-windows, cold-8 F1). **The cross-layer theorem actually holds** (linear IEL ⇒ one anchored tip ⇒ a
  second same-serial SEL event is an inert re-anchor ⇒ SEL-fork forces IEL-fork; skip-unattributable prevents
  deadlock). **Seams verified sound:** KEL↔IEL↔SEL kind-strict + anchor-monotonicity + cross-layer theorem;
  the layering cut (chain=structure / feature=topic, R2 is a cred-layer check); federation-binding closed set;
  effective-SAID universal comparison; tier/threshold-vector. **Consistency sweep grep-clean** — every
  dead-model token (`privileged`=0 · `Ror`/`Rec`/`Rpr`/`Fld` · `T3`/`t_recover` · `Cnt`/`contested` ·
  `KILL_TOPIC` · `attribute-all`/`positive-presence`/`create-on-revoke` · `policyPin`/`grp`/`dev` ·
  direct-mode · raw `said(cred)`) is a negation or decision-history, never a live claim. **My Round C open
  item (the R3 doc-member bound-placement sweep) has LANDED** — verified from disk: every `only its pin` /
  `self-contained` / `never fetches` statement is now cred+delegate-scoped with the doc-member gated-rescind-doc
  carve-out (area-sel:145-150/281/289-290/309-313, inv:649-651, doc-policy:225, multi-party:181); no de-anon
  misread risk remains. **The FOUR findings are all [minor]/[nit], non-blocking:** F1 [consistency] KEL kind
  count stated "5 kinds" (area-kel:27, per-KEL) vs "KEL is 6" (federation-ref:25, total labels) — needs a
  bridging frame (5 per KEL, `Fcp` XOR `Icp`); F2 [completeness] doc-policy §E "policy-satisfaction matching"
  is `[fresh]`/unworked (:24; composer mechanics in §B/§C cover the substance — fold or work it at the feature
  encode); F3 [consistency] the token-store supplemental (:44) cites the archived `vdti-creds-issuance-
  revocation-model.md §4.2` + pre-rework "non-revocation proof" framing (absorbed into vdtid §1d — wants a
  status pointer); F4 [clarity][nit] inv:667's trailing "the `Trm` carries only its pin" grazes the doc-member
  exception (scoped correctly by inv:649-651 16 lines up — a re-scope at encode). **Cold-overlap flag:** the
  crown-jewel soundness rests on multi-round prior review both passes inherit from the same canon text — a
  cold re-read shares my priors (esp. the cross-layer theorem's linear-IEL step + the synthetic-satisfies-the-
  bar claim); best decorrelation is cold re-attacking the residual coverage claims (eclipse / just-closed-window
  lag / current-threshold-compromise), not re-blessing the crown jewels.
- **PRIOR ROUND — the fail-secure R1–R6 + layering FOLD: my verdict MERGE (2026-07-10, findings
  `.working/vdti-failsecure-fold-review-warm-findings.md`).** The fail-secure encode's dual-pass re-review
  returned HOLD/HOLD and **decorrelated-converged on ONE real break — the walk floor** (my F1 last round =
  cold's F1, found fresh with no spec → a genuine convergence, not a shared blind spot). Six resolutions
  (**R1–R6**) + a **layering principle** were folded, reconcile-not-redesign. `make all` **exit 0**. **The fold
  landed faithfully and the converged break (R1) is GENUINELY CLOSED — I verified it adversarially, not on
  faith:** R1 pins **both** the revocation floor AND the as-of to the **EARLIEST** issuance anchor (inv 5:218,
  area-sel:89-94, inv 10:316-318 — so a re-anchor is *fully* inert, stronger than my F1 ask which named only
  the floor); the verifier derives earliest itself + never trusts a supplied/cached later position (compatible
  with inv 8 caching); **no other mechanism moves the floor** (hiding the earliest needs a stale IEL → inv 8
  refuses; an earlier anchor only moves it earlier; as-of can't diverge from floor); **cred-only immunity is
  structural** — delegate/doc-member targets are grant-epoch-scoped AND their grant is a SEL event with
  anchor-monotonicity (re-anchor inert), while the cred issuance is a flat hash (no monotonicity) keyed only on
  `cred.said`. **The layering principle** (area-iel §1:15-25, kinds-vs-topic-labels, `kills[]`-only-on-`Rev`/`Dth`
  the one schema rule) is coherent + its key soundness check passes: the moved rules (R1/R2) are **feature-local**
  — skipping = a local wrong answer on one cred (R2 safe-direction), never a chain-validity break. **R2/R4/R5/R6
  sound:** R2 topic↔kind (cred revocation needs a `Rev`/`t_govern`; found-fast-path carries the check); R4 my F2
  closed (private lookup `Icp` recomputed-never-published, "CLOSED" rests on both halves); R5 my F3+minor closed
  (grep-clean no raw `said(cred)`; inv 4:110-114 back-check carve-out); R6 vdtid is a structural store not a
  revocation authority (grep-clean, freshness bar stays). **The ONE finding is [consistency], non-blocking:**
  R3's doc-member bound-placement carve-out isn't propagated to two secondary passages (area-sel:296, inv:662)
  that state the *delegate* case ("`bound` rides `kills[]`, `Trm` only its pin") as general — a de-anon misread
  risk if a doc-member impl follows it (the participant-identifying bound would land in public `kills[]` instead
  of the gated rescind-doc). Authoritative statements are all correct; just a propagation sweep.
- **PRIOR ROUND — the FAIL-SECURE revocation encode: my verdict HOLD (2026-07-09, findings
  `.working/vdti-failsecure-review-warm-findings.md`).** After re-review-2 broke the best-effort model's
  `attribute-all` escape hatch (my F1 last round), the design was reworked AGAIN — this time to **fail-secure
  by default**: revocation/rescission is a **`kills[] = [{target, bound?}]` declaration on the issuer's
  WITNESSED IEL `Rev`/`Dth`** (read by the fresh inv-8 walk, so detection rides the same freshness gate the
  verifier already runs to trust the issuer — "kill-freshness == authority-freshness"), with the
  content-addressed `{Icp, Trm}` lookup SEL demoted to a **fail-OPEN opt-out**; **the issuance SEL is dropped**
  (a cred is a direct-anchored SAD, `hash('{CRED_ISSUANCE_TOPIC}:{issuer}:{cred.said}')`); `target =
  hash('{topic}:{owner}:{data}')` (flat, distinct topics per kind). `make all` **exit 0**. **This is a genuine
  improvement and lands faithfully/completely/consistently in the main:** the core claim ("not-found in any
  `kills[]` at a confirmed-fresh tip → genuinely not-killed") **HOLDS** (forward-match your own target on the
  un-withholdable witnessed log — fixes re-review-2 F1 at the root, no reverse-attribution); the four flags,
  two reads, bound-per-kind (cred none / delegate public / doc-member gated), and `kills[]`-opacity all landed;
  completeness grep-clean (no live attribute-all/positive-presence/create-on-revoke/KILL_TOPIC); positive chain
  stays fail-closed (no over-correction); doc-member freeze hard again (multi-party:167-182, verified NOT stale
  — I re-read it after a momentary recall-confusion). **The HOLD is THREE reconcile items — two the exact
  unstated-assumption class the last two passes missed:** **F1 [soundness/under-spec]** the `[issuance-position
  .. tip]` lower bound doesn't say **earliest** issuance, and the inert-serial re-anchor guard was dropped with
  the issuance SEL — a re-anchored/claimed later issuance-position skips an intervening revocation ("no lossy
  cap" is unstated; lower-bound analog of the spec's named tip assumption). **F2 [soundness/privacy]** the
  private-cred "CLOSED" claim (inv 16:715) rests on non-computability of the address, but the lookup SEL's
  `Icp` carries `data = cred.said` **RAW** (area-sel:96) and the canon closes only "private cred **bodies** not
  published" (inv 16:719) — not the private lookup SEL `Icp`; if it's published for the O(1) path a replica
  reads cred.said raw (the holder-vs-replica gap; the encoder's own flag-1 target). **F3 [consistency]**
  inv 4:56/:66-67 still say the issuance anchor is raw `said(cred)`, contradicting the qualified-hash form
  everywhere else (inv 8:266, inv 16:686, area-sel:48) + flag-1. Plus an inv 4:106 back-check-precision minor.
  Reconcile-not-redesign; none fatal. F1's likely-intended close: earliest-issuance / re-anchor inert. F2's:
  only the pin-only `Trm` is served, the `Icp` recomputed-not-published.
- **PRIOR ROUND — re-review 2 (the best-effort rework across all three absence-reads): my verdict HOLD
  (2026-07-09, findings `.working/vdti-rereview2-warm-findings.md`).** Context: my PRIOR round called the
  positive-presence two-SEL revocation model "SOUND"; the cold pass then **broke it** (cold B-1 — a withheld
  serial-2 `Trm` reads a single Active tip → grants a revoked cred; positive presence defeats whole-SEL
  _absence_, not a withheld _tip_, SEL unwitnessed). **I reproduced the designer's error by trusting the
  spec's framing** — the correlated-blind-spot the decorrelated cold pass exists to catch. Jason reworked to
  the honest industry ceiling: **create-on-revoke `{Icp, Trm}`, best-effort / fail-OPEN** (matches KERI TEL /
  OCSP soft-fail), under an **inv-8 carve-out** (positive trust chain fails closed; revocation/rescission
  negative overlays fail open), extended to **delegate rescission** (`area-delegation`) and **doc-membership
  rescission** (`multi-party:167-181`) — all three the same create-on-X absence-read. `make all` **exit 0**
  (46 files). **The core rework is FAITHFUL, COMPLETE, CONSISTENT, and — this time — HONEST:** the default
  best-effort read is sound; the positive chain stays fail-closed (no over-correction); the present-object /
  closed-period asymmetry is kept in all three; the warm-F4 propagation is **recorded** (`multi-party:175-177`
  — reclassifying propagates Decision 1 (SELs unwitnessed), the premise F4's fail-secure rested on, NOT
  overturning F4); completeness grep-verified (no surviving positive-presence / "leaks nothing" / "CLOSED" /
  dual-Pin — only history / explicit-drops / the named future witnessed-revocation regime). **My PRIOR-round
  F1 (the "leaks nothing"/"CLOSED" over-claim) is RESOLVED** by this rework (inv 16 now states the
  revocation-list residual honestly). **The HOLD is ONE [soundness]/over-reach (F1) — the mirror of last
  round's error:** the **`attribute-all` fail-secure OPT-IN** (`area-sel:218-222`, `document-policy:219-226`,
  `inv 10:277-279`, `area-delegation:38-40`, `multi-party:178-179`) claims "attribute every `Rev`/`Dth`,
  **fetch each one's _derived_ SEL**, confirm none match → **confirmed clean** → grant." But a `Rev`/`Dth`
  names an **opaque `said(Trm)`, no prefix** (`area-sel:210`); cred-SELs are **by-prefix-only, no SAID→event
  index** (`inv 16:626/671-678`); a non-holder **can't derive a foreign address** (`plain-english:213` "no one
  else can find it"). So a client can address **only its own** cred's SEL; every **foreign** `Rev`/`Dth` is
  structurally unattributable, and the "(a withheld SEL)" parenthetical (`area-sel:220`) conflates
  "withheld" with "structurally-unaddressable" — the **same class of error** the rework just fixed. The
  "confirm clean" path is unreachable for any issuer with revocations the client doesn't hold. **NOT a safety
  break** (attribute-all fails secure — refuses, never false-grants; the default merges). The design's own
  model file uses the honest coarse form ("**refuse any cred whose revocation it can't positively check**",
  `plain-english:227`). Reconcile: restate as the coarse deny-by-default, or specify + reconcile the
  replica-enumeration `attribute-all` secretly needs (widens the inv-16 correlation residual). Jason's call —
  reconcile, not redesign. C1 minor: delegation states the present-object asymmetry least explicitly.
- **PRIOR ROUND — whole-canon re-review after the encode-review folds: my verdict HOLD (2026-07-09,
  findings `.working/vdti-rereview-warm-findings.md`).** The cold encode-review HOLD's fixes were folded:
  **B1** (NEW design — the two-SEL credential-revocation model, its first review), C1/C2, M1–M5. `make
  all` **exit 0** (46 files — the supplemental stub is now deleted, M1 folded). **The fold is faithful,
  complete, consistent; the `:57` "cred-SELs are witnessed" contradiction is FULLY GONE; C1/C2/M1–M5
  landed.** **B1's revocation SAFETY is SOUND** — the two-SEL split (issuance SEL `{Icp,Pin}` serial-≥2-inert
  + a derived **positive-presence** revocation SEL, always-published, `Trm@2` `Rev`-anchored) closes the
  hidden-revocation hole: "not revoked" is a positive read of an always-published Active object, so
  can't-confirm → fail-secure REFUSE (a denial, never a false grant); inert-not-reject encoded with
  reasoning (a T1 thief's serial-2 append is a no-op DoS-safe); the eclipse edge is pinned + fail-secure
  (not a new hole). **The HOLD is ONE soundness finding (F1):** the published revocation SEL's `Icp`
  stores `owner=issuer` + `data=issuance.prefix` in the clear and is replicated to the mesh, so a witness
  reads `(issuer, issuance.prefix)` + per-cred revocation status — **reopening the "issuer ↔ private-prefix"
  correlation `inv 16:661` claims CLOSED (§2c Decision 1)**, via the published body instead of the retired
  receipt. NOT a safety break (opaque hash, no content/holder), but `area-sel:61` "leaks nothing" +
  `inv 16:661` "CLOSED" + the model narrative :215/:222 over-claim it. The correlation edge IS pinned
  (`inv 16:665` — good), the pin just resolves negative. Reconcile (state the residual / accept the trade)
  or mitigate with a blinded derivation — Jason's threat-model call. Nit: `area-sel:187` keeps "third-tier"
  (greenfield-exempt history; applied-log's "without the dead token" over-states). Everything else MERGES.
- **PRIOR ROUND — first-seen CANON ENCODE review: my verdict MERGE (2026-07-09, findings
  `.working/vdti-first-seen-encode-review-warm-findings.md`).** The ground-up divergence/recovery rewrite
  across 12 `docs/canon/` files + the repair-proof deletion (1016 ins / 1250 del) landed in the working
  tree (uncommitted; commits are "Working surface" only). **`make all` exit 0** (47 files / 545 OK / 0
  errors / prettier clean — done-gate met). **The encode is faithful, complete, consistent; no blocker.**
  The **three KEEPs all survived** (checked hardest per the brief): inv 13 F-F pure-walk KEPT+reworded
  (invariants:436-438 — the F4 dependency the effective-SAID recoupling rests on; explicitly tied at
  vdtid §1e:121-123); `Fcp` genesis carve-out KEPT (area-kel:32 "not direct mode"); seal-cap KEPT,
  satisfiers narrowed `{Rot,Wit}` (area-kel:104). **Completeness verified from disk** (not on faith):
  `privileged`=0 (rename clean, `sealed-on-arrival` survived — 13 intact); every Ror/Rec/Rpr/Fld/
  t_recover/T3/direct-mode hit in the 12 files is a negative/history/guard. **F1 resolved cleanly** —
  lint-terminology is closest-file-wins, so `docs/canon/.terminology-forbidden` omits the `forked:`/
  `disputed:` ban (allows the synthetic) while `docs/.terminology-forbidden:181-182` keeps it for phase-2
  `docs/design/`. **The NOT-previously-reviewed block (§2b/§2c/§5/§9) — SOUND on first review:** §1g
  receipt spec (verify-first holds — every SEL kind rides an IEL anchor; Decision-1 makes plain-prefix
  safe; refuse-not-sign-then-not-count avoids self-forking; rebind-`Wit` T2), §1f second conjunct
  (forward-of-last-confirmed-tip, NOT pairwise/NOT seal — tightens the F5 just-closed-window residual),
  §1j SAD-store kind filter (closes a real inversion oracle), §1k receipt-threshold (exact-match-on-pull
  sound). **Effective-SAID consistent across vdtid §1e / inv 17 / area-kel.** Both encoder flags resolve
  SOUND: rebind-`Wit` T2 (ledger's "T3 rotation" is a typo — flag for Jason); roster floor ≥4 structural
  /≥5 recommended is forced (signers≥3 + exclude-self ⇒ |roster|≥4) + consistent (inv 12 + fed §1a/§1c).
  **Four MINOR/NIT:** M1 grep-canon-clean overstated (supplemental/vdti-lib-storage-stub.md:15,38 has live
  ancient-taxonomy `Rec`/`Ror`/`Fed`/`Dip`/`Dec` — out of scope, lint-green, stale-by-many-rounds); M2
  §1k [REVIEW-PENDING] hint-vs-authoritative scope (state it at encode); M3 fed §1a:94 "naive ≥ 3 floor"
  vestige; M4 impl-notes `forked:` vs `disputed:{prefix}` shorthand. No design blocker.
- **⟳ DISPOSED (2026-07-08, by the design session).** All my effective-SAID re-review findings are **folded**
  into the ledger + model files: F1 (`.terminology-forbidden:174-175` un-ban — the `make all` breaker, flagged
  in §2a's canon-edit list to do first), F2 (`area-kel:89`), F3 (inv 17 multiple passages), F4 (§2a + §3 KEEP
  `inv 13:484-487`, the F-F pure-walk the recoupling rests on), F5 (§1h edit site + inv 8 note). The cold pass's
  B1/B2/C1/M1–M3 are folded too. **The encode review is DONE (the CURRENT ROUND bullet above, MERGE);
  both watch-items confirmed** — the synthetic tokens are un-banned (scoped to `docs/canon/`) and the F-F
  pure-walk is kept (invariants:436-438). Findings now in `archived/`.
- **CURRENT ROUND — effective-SAID resolution re-review: my verdict HOLD (2026-07-08, findings now
  `archived/vdti-effective-said-warm-review-findings.md`).** The focused re-review the DISPOSED bullet
  queued. **The reversal is SOUND and NECESSARY — verified hard, both load-bearing claims survive:**
  (P1) the flood-instability premise HOLDS — §1e's convergence (:154 "hold the same branches") assumed
  honest first-seen witnesses; the dishonest-signer flood is a *witnessed* flood, outside §1e:168's
  "un-witnessed flood dropped" defense, and no canon mechanism bounds the witnessed sealed breadth
  (fork-cost prices not caps; retention keeps a non-deterministic ≥2; seal-cap bounds depth not breadth);
  (P2) **no consumer needs branch-sensitivity** — swept ALL readers (§1d token-reuse, §1e/§1i anti-entropy,
  §1g merge, §1h deferred-deps, document-policy §F, inv 8 multi-source), every one uses the digest as a
  change-detector + reads the VERDICT for trust; §1e's "Required"(branch-sensitive)+"Safer"(fail-open) are
  defeated correctly by verdict-recoupling (R4-masking only masks OUTCOME-PRESERVING branches; the M=1→M=2
  crossing moves `forked`→`disputed` and fires); resolution is owner-driven (root-bury `Rot`), never
  anti-entropy-assembly. (P3) "no silent forgery" — grep-confirmed ZERO "no silent breach" in canon
  (design-docs-only, §5 fixes it). (P4) "early-terminate at 2 sealed" squares with inv 17:761. **HOLD is on
  §2a COMPLETENESS:** **F1 [breaks make all]** `docs/.terminology-forbidden:174-175` ENFORCE `forked:` /
  `disputed:` as banned tokens (written to forbid the exact reversed model) — the reversal reintroduces
  them → lint fails; §2a omits `.terminology-forbidden` (un-ban 174/175, keep 172/173 divergent/irrec.,
  rewrite the canon comment :150-155); **F2** area-kel:89 asserts "real digest over live tips, not a
  synthetic" — inverts, not in §2a; **F4** the re-coupling is sound ONLY under the F-F pure-walk
  (inv 13:484-487) — §3 "delete inv 13's divergence rules" risks deleting the foundation; §2a must name it;
  F3 (inv 17 is 4+ live-tips passages :745/:748/:769-772/:779-782, not one) + F5 (§1h:193-194
  DeferredDepsResponse edit site + the inv 8:272-273 multi-source note) ride along. No design blocker.
- **⟳ DISPOSED (2026-07-08, by the design session).** Jason resolved the L2 crux: the effective-SAID is
  **single confirmed tip → real SAID; no single tip → a synthetic recoupled to the verdict** (`forked` /
  `disputed`) — **no live-tips digest** (flood-unstable under dishonest signers), **no branch-assembly**
  (root-bury resolves by position, owner-driven). L1's omitted files are now in the ledger (§2a lists
  vdtid-services §1e/§1i, implementation-notes, document-policy §F). The cold blockers were dispositioned
  too (A = a doc-precision fix, verified not a hole; B = "no silent breach" → "no silent forgery"; C/D/E
  folded into the model files). All of it is in the updated `.working/` model files + ledger; the first-seen
  **findings are now in `archived/`**. **The focused effective-SAID re-review is DONE (the CURRENT ROUND
  bullet above, HOLD); next is the encode review** once §2a's F1–F5 are folded.
- **CURRENT ROUND — first-seen model → canon reconciliation review: my verdict HOLD (2026-07-07,
  findings now `archived/vdti-first-seen-warm-review-findings.md`).** THE BIG CHANGE Jason flagged: a
  **design reversal** captured in `.working/vdti-{model-plain-english,event-kinds,adversary-cases}.md`
  + a delete/keep/rewrite ledger `.working/vdti-first-seen-reconciliation.md`. **Two tiers only** (T1
  signing / T2 rotation reserve — **drop T3 recovery key + `t_recover`**); **drop kinds** KEL
  `Ror`+`Rec`, IEL `Rpr`, SEL `Fld`+`Rpr`; **all key changes single-signed** (no dual-sig). **First-seen
  pivot:** witnesses take first-seen for content AND *single-key* key changes (KEL rotation, solo
  governance — the Rot'@v_M fix); record-both→`disputed` only for *multi-signer* key changes (federation
  IEL, multi-member IEL governance). **Recovery = a plain `Rot` at the fork position** (buries by descent
  + privileged-buries-content); **eviction = `Evl`-with-`cut`**; **DELETE the repair-completeness proof**.
  Roster cap → 32 all IELs; majority floor `t_govern`/`t_authorize > |roster|/2`; **direct mode removed**.
  **The DESIGN is SOUND** — no soundness break; the recovery mechanism (cross-tier co-sign + first-seen
  rotation + privileged-buries-content + deadness-descends) verifies, all 5 load-bearing claims hold,
  anchor re-homing is clean (only `Trm`: `Ror`→`Rot`, user + fed IEL both), the proof deletion leaves
  nothing unreplaced, FORCE-by-provenance survives scoped to key-change `disputed`. **The HOLD is on
  LEDGER COMPLETENESS, not the design:** L1 three affected canon files omitted (**`vdti-area-vdtid-services.md`
  §1e/§1i, `vdti-implementation-notes.md`:22-91/128-140, `vdti-area-document-policy.md` §R4** — none in
  the ledger or the brief's list); **L2 the effective-SAID change (§2) reverses a four-round-reviewed
  decision** — the ledger's `forked:<seal>` synthetic reverses vdtid-services §1e's "real live-tips, NO
  synthetics" (which explicitly retired the synthetics: "Required: branch-sensitive" + "Safer: fail-secure")
  and re-couples digest↔verdict — asserted without tracing or justifying (the one item needing Jason, not
  just the encoder); L3 SEL `Fld` deletion collides with area-sel §4's explicit "NOT transitive" finding
  (deletion sound — no-repair⇒no-page-atomicity — but unstated); L4 direct-mode removal under-lists its
  canonical §1d home + the "both modes" shape-gate simplification; L5 multi-party §3/§7 carry
  repair-proof citations + deleted anchor pairs. L6-9 minor. **Answer to "encodable as-is?": NO** —
  fix L1+L2 first.
- **PRIOR ROUND — fold + mermaid + removal review (2026-07-04, HOLD-with-findings,
  `.working/vdti-fold-and-diagrams-review-warm-findings.md`).** Disposition from THIS session unknown
  (a new brief arrived instead of a fold). Three MAJORs were: W1 event-shape role-vocabulary table
  malformed GFM (`content` spliced into `delegates`, :132-136); W2 six parent→child `|previous|` arrows
  in the stubs; W3 event-shape:377-384 §Anchoring omits `Ath ↔ Gnt` + retains retired "uniformly on the
  serial-1 `Pin`". MINORs W4-7 + NITs N1-4 (see the findings file). If a fold lands, re-verify from disk.
- **THE TAXONOMY (renamed 2026-07-04 — memorized names are STALE; use these).** `Del` → **`Ath`**
  (authorize, T2 `t_authorize` — two roles at once: `delegates` for act-for-delegator, `anchors` →
  the new SEL **`Gnt`** doc-membership grant for act-as-self); `Kil` → split **`Rev`** (revoke an
  owned artifact, `t_govern`) + **`Dth`** (deauthorize a grant, `t_authorize`) — the `threshold`
  slot-name field is retired, every kind prices from exactly one slot; `Dec` → **`Trm`**
  (terminate), chain state `Decommissioned` → **`Terminated`**; `t_delegate` → **`t_authorize`**.
  Kind counts: KEL 8 (`Fcp`/`Icp`/`Ixn`/`Rot`/`Ror`/`Rec`/`Wit`/`Trm`), IEL 9
  (`Icp`/`Ixn`/`Evl`/`Ath`/`Rev`/`Dth`/`Rpr`/`Trm`/`Wit`), SEL 7
  (`Icp`/`Ixn`/`Gnt`/`Trm`/`Pin`/`Fld`/`Rpr`). Anchor matrix (five pairs): `Ixn`↔content,
  `Evl`↔`Fld`, `Ath`↔`Gnt`, `Rev`/`Dth`↔`Trm` (discriminated by SEL type — the total rule:
  `Dth` iff authorization-rescission (delegation or doc-membership), `Rev` otherwise), `Rpr`↔`Rpr`.
  `Gnt` is privileged/seal-advancing/non-archivable (walk back = rescind forward via `Dth`).
- **PRIOR ROUND (detail) — fold + mermaid + removal review: HOLD-with-findings (2026-07-04,
  findings `.working/vdti-fold-and-diagrams-review-warm-findings.md`).** The
  taxonomy-round fold is **faithful and complete** — every warm W1–W10+N1–3 and cold M1–7/MIN1–5/
  NIT1–3 verified folded from disk (map in the findings file); the four rebuilt model surfaces
  (seal-advancer sets, `{Ixn, Pin}` archivable set, five-pair anchor matrix, SEL-`Icp`-never-anchored
  + fallback floor) agree at every normative site. The new **`grant` role is sound** (inv 4:74-76 +
  event-shape:137/:354; back-checked via the `Ath` kind-strict anchor, not allowlist-dependent; no
  S1). The 11 mermaid diagrams are current-model + kind-strict-correct with structural captions; the
  multi-party stub is rebuilt from the current canon (per-period `Gnt`←`Ath` grants,
  `hash(G | said_b)`, `{Icp, Pin}` versions, `ancestors[]` — no `authors[]`). Removal grep-clean;
  `make all` 0 (48 files / 545 xrefs / 31 fwd-refs). Three MAJORs: **W1** event-shape's
  role-vocabulary table is malformed GFM — 3-cell header vs 7-cell delimiter, the `content` row
  spliced into `delegates` (:132-136; a FRESH regression of the fold's own GFM fix — the allowlist
  table renders as raw text); **W2** the three stubs draw `previous` edges parent→child with the
  `|previous|` label (6 edges — inverts the field; landed diagrams draw child→parent); **W3**
  event-shape:377-384 §Anchoring omits `Ath ↔ Gnt` from its "only its matching kinds" pair list AND
  retains retired "uniformly on the serial-1 `Pin`". MINORs W4–W7 + NITs N1–4 (see Open items).
- **Taxonomy encode round — CLOSED (2026-07-04).** My HOLD (4 MAJOR / 6 MINOR / 3 NIT) and cold's
  HOLD (7 MAJOR / 5 MINOR / 3 NIT) are both fully folded in `1289bef` — verified from disk this
  round, findings archived. One residue became this round's W3 (the §Anchoring half-fix); one fix
  regressed into this round's W1 (the role-table splice).
- **Multi-party documents, SECOND CUT — my HOLD-4 is FOLDED (2026-07-04).** The 2nd-cut note
  (`docs/canon/vdti-area-multi-party-documents.md`) absorbed all of F1–F15+N1–3: rescission keying is
  now `hash(G | said_b)` (participant-blind AND grant-blind — the F1 fix done properly), the nonce
  rule landed for every gated doc on public structure (F2), DAG-descent is derived as a placement
  consequence with structural language (F3), the honored predicate carries the inv-8 freshness bar
  (F4), grants became **T2 `Gnt` ← `Ath`** (resolving my F13 constraint properly — the taxonomy
  refactor was the mechanism), disjoint-periods at doc-validation, `MAX_GRANT_ADDS = 64`,
  reserved-name convention `vdti/doc/v1/...`, custody.md backport noted at §8. Editors/commenters
  role split (view/comment/edit triad); comments mechanism deferred. Nothing outstanding from that
  round; findings file archived.

- **Prior arc (convergence / effective-SAID) — SETTLED + FOLDED, warm fold re-review WAIVED.** The
  live-tips + pure-walk + gate-in-both-modes model is canon (inv 13 F-F, inv 17, vdtid-services
  §1e/§1i, fed §1e gate bullet) and landed (`e369180`): pure-walk reading with a DERIVED seal
  ("frozen" = origination posture only; a content fork resolves by `Rec` OR a burying
  seal-advancer; identical held sets ⇒ identical reading + digest — verified both arrival orders),
  live-tips digest (settled content drops out, privileged never settles), shape-validity gate at
  the acceptance point in both modes. My re-encode HOLD-4 (Matrix-2 burial cells; system-thesis
  freeze section; derived-seal rule pinning; `Dec`-burial seam + L1–L5) was **folded in
  `47d98af`..`ef8539f`** (residue removal, polish, SAID/prefix rationale, glossary + SAD mods,
  canon/working-surface sync) — **Jason waived the warm re-review of that fold** (2026-07-04; canon
  was expected to keep moving). Digest-model history (one day, three generations): seal-relative
  `4beb456` (HOLD-2) → all-tips `fc6c91b`+`5119814` (HOLD-2 + my adjudication of the cold findings)
  → **live-tips + pure-walk** (Jason's fix — kels recall; reviewed HOLD-4, folded). Nothing
  outstanding from that arc; both convergence findings files are archive-ready.

## Prior arc state (content-fork prevention, settled + encoded)

- **Content-fork prevention — SETTLED, ENCODED, REVIEWED, POLISHED.** The model: witness-config
  **majority floor `threshold > signers/2`** + the kind-scoped witnessing ladder (content
  first-seen, one sibling per `(prefix, serial)`; privileged up to **two** per position — two
  both-witnessed siblings ARE the `disputed` proof; the resolving repair = the first privileged
  sibling, no separate clause) ⇒ **content forks on witnessed chains are prevented below
  fork-cost `2·threshold − signers`** (a priced dial: `fork-cost = threshold − slack`;
  double-signing attributable). Option (b): user-IEL content gated at its own position alongside
  Q1 anchors; federation IEL exempt; SEL rides the cross-layer theorem. Counting is
  **selection-scoped**. Recoverability cap **`threshold ≤ min(|roster| − 2, signers − 1)`**,
  `signers = 1` waiver ({1,1} evict-one = position-luck, warned); re-check on **any
  config-changing `Wit`** (incl. config-only). **Single-add federation `Wit`** (`add` scalar,
  `Fcp` exempt, `cut` a list). **`forks` → `fork`** (one root; unnamed branches close below-seal +
  by-descent — verified closure equivalence). Serialization: governance safety-critical
  everywhere; content-rail = liveness on witnessed chains, safety-critical direct-mode/solo.
  Propagation premise = success-rate/latency only, never safety. §1a reachability property
  verified (one `Wit` carries the full config delta → no forced invalid intermediates).
- **My verdicts this arc (all archived):** majority-quorum canon review **HOLD-2** → fold review
  **MERGE** (both Fable completions verified: waiver necessary+honest; collapse
  outcome-identical) → encode review **MERGE** (clusters A–J faithful; manifest independently
  clean incl. sad/policy/diagram; no cross-doc contradiction). Cold ran HOLD-11 on the canon
  round; its seam findings (config-transition F1, single-add P5) landed as the canon seam layer.
- **All my open findings are folded** (verified from disk 2026-07-03): the four fold-review LOWs
  (proof premise now lists the roster-delta straddle; area-fed elliptical bounds fixed;
  first-seen naming unified — 0 "first-receive" hits; area-sel has the transitive fork-cost
  note) and ALL of encode F1–F5 in `89f74cd` — F1 (content-rail uniformly "safety-critical on
  direct-mode") and the F2–F5 de-dup collapses exactly as recommended (verification's FORCE
  content-leg → split + §Federation-convergence ref; event-shape's witnesses/bounds/roster rows →
  shape/bound + ref, rationale prose removed). The "(verify at review)" tag is resolved out of
  area-fed.
- **Commit sequence (this layer):** `fbc62eb` majority-quorum canon → `a3e371e` re-encode landed
  design → `89f74cd` review polish → `5a5932b` **new `docs/design/README.md`** (reading-order map —
  I have not reviewed it) → `4b6c62c` clarify reconciliation.md → `b526dd3` SiblingLocked/retention
  split → `4beb456` **Eliminate synthetic SAIDs** (seal-relative digest; reviewed HOLD-2) →
  `fc6c91b`+`5119814` **all-tips** (reviewed HOLD-2) → `e369180` **Separation of duties
  (merge/persist)** = the live-tips + pure-walk re-encode (reviewed HOLD-4) → `47d98af`..`ef8539f`
  the fold + polish/glossary/custody layer (warm fold re-review waived by Jason, 2026-07-04).
- **Repair-completeness model (settled r1–r5, re-scoped to the residual):** root-pointing
  (`fork` = one root condemning its subtree) + deadness-descends (same-chain + **IEL→SEL anchor
  edge only**) + bounded fork (depth ≤ 64/lineage; retention ≥ 2/position; the ladder) + two
  guards (no-self-condemnation over the full-span walk — tight form
  `root.parent = v_{d-1} ∧ root ∉ walkback` in impl-notes; content-only) + retain-and-count
  (scoped: passes hard auth, fails content-only; junk dropped) + `{Dec, content}` tier-rank +
  D1 two-valued finality (no-resurrection unconditional; resolution-stability gated;
  residuals: eclipse + historical reserve compromise + withheld-body split + roster-delta
  straddle) + cross-layer theorem (valid SEL fork ⇒ IEL fork; anchor-monotonicity with
  skip-unattributable). Runs against the residual population (direct-mode, fork-cost byzantine,
  straddles, split-stalls, mixed races).
- **Canon:** `.working/vdti-repair-completeness-proof.md`, `vdti-invariants.md` (inv 4/12/13/14/17),
  `vdti-area-{kel,iel,sel,federation-witnessing}.md`, `vdti-implementation-notes.md`. **Landed:**
  protocol-doctrine, system-thesis, **design/README.md (new)**, event-shape, six `kel/` docs,
  sad/ + policy/ trees, `docs/.terminology-forbidden` (root-pointing + fork-scalar bans).

## Open items

- **Phase-2 `docs/design/` PR#11 (KEL primitive) — FINAL PASS DONE → MERGE (clear to merge).** The reconcile
  round's MERGE/MERGE fold: **all 8 folded findings verified landed faithfully** from disk (list in the CURRENT
  ROUND bullet + `.working/vdti-final-review-warm-findings.md`), all **9 properties re-verified against canon**,
  `make all` 0, greenfield clean, supplemental internally consistent. **My reconcile-round F1/F2/F3 are FOLDED**
  (F1→fold #3 event-shape:476 rescind-doc; F2→fold #5 reconciliation:149-151 below-seal; F3→fold #6
  reconciliation:238-242 Matrix-2 Row note). **ONE new carry-forward, OUT of this PR's scope (for the `iel/`
  PR):** the `iel/delegation.md` diagram stub carries the **retired** delegate-`manifest.bound`-on-`Trm` shape
  (canon puts delegate `bound` in the `Dth`'s `kills[]`, `Trm` only its pin; only the **doc-member** `Trm`
  commits a gated rescind-doc) + `RSC_TOPIC` vs `DLG_RSC_TOPIC` + fail-open-only framing — same class as fold #3,
  reconcile when `iel/` lands. **Deferred to later PRs (out of scope, not gaps):** `iel/`, `sel/`,
  `federation/witnessing.md`, `features/` (credentials + multi-party), services docs — the 31 forward-refs into
  them are sanctioned (`lint-docs` errors:0 so no in-surface break); `iel/delegation.md` +
  `features/multi-party/documents.md` exist as **diagram stubs** (like `federation/bootstrap.md`), doctrine
  deferred. **Two whole-canon items RESOLVED by this encode:** SAID §Rule-1 (said.md:120-130 form-dependent) and
  KEL 5-vs-6 (design uses "5 kinds, 2 inception variants"). **Whole-canon SHIP minors' disposition:** F1 (KEL
  5-vs-6) resolved; F2 (doc-policy §E `[fresh]`), F3 (token-store supplemental dead-file pointer), F4 (inv:667
  tail) are **canon-side** polish, unaffected by this design PR — still open on the canon, non-blocking. **When
  the next design PR arrives (likely `iel/` or `sel/`):** re-read the canon regions it encodes + the landed
  design from disk; watch that the `iel/delegation.md` delegate-bound carry-forward got folded; confirm the
  deferred-doc forward-refs resolve as those docs land.
- **Prior fold-and-diagrams HOLD (2026-07-04) — disposition unknown from this session:** W1–W3 (MAJOR, mechanical: de-splice event-shape's
  role-vocabulary table (:132-136 — 3-cell header vs 7-cell delimiter, `content` row spliced into
  `delegates`; a FRESH fold regression, renders as raw text); flip the six parent→child
  `|previous|` arrows in the three stubs (bootstrap ×3, delegation ×2, reconciliation ×1); add
  `Ath ↔ Gnt` to event-shape:377-381's pair list + kill the retired "uniformly on the serial-1
  `Pin`" at :383) then W4–W7 (multi-party stub's `|content|`-on-a-`Pin` label → `Icp.data`; inv 18 +
  inv 4 class enumerations missing `grant`/`bound`; reconciliation stub "losing branch" → root;
  multi-party stub orphaned — no inbound link) + N1–4. A cold pass ran in parallel — expect overlap
  on W1/W2/W4/W6 (render-and-read-reachable).
- **Unreviewed surfaces:** `docs/design/README.md` (5a5932b) — still no dedicated round (this round
  read only its forthcoming section). The convergence-arc fold landed without a warm re-review
  (waived). `vdti-protocol-doctrine-freshread-brief.md` sits in `.working/` (queued, not yet mine).
- **Deferred in canon (tracked there, not by me):** the `compaction.md`/`said.md` §Rule-1
  SAID-invariance fix (multi-party §7 "Deferred to the encode"). The excalidraw→mermaid re-encoding
  is DONE (this round's target; drawing + lint-diagrams deleted, exclusion removed).

## Pending externally

- Forward-ref'd / unbuilt: `iel/` + `sel/` (the cross-layer bundle lands there),
  `federation/{witnessing,bootstrap}.md`, `operations/{multi-party-governance,recovery-workflow}.md`,
  `features/credentials/`, `infrastructure/vdtid.md`. Full-out design encoding planned after this
  review iteration set.

## My findings files

**Active (round open):** `.working/vdti-final-review-warm-findings.md` (MERGE — final confirmation pass,
fidelity-to-canon, pre-merge; PR#11 KEL primitive; **all 8 folded findings verified landed faithfully**, all 9
properties re-verified design↔canon, `make all` 0 (0 errors / 31 sanctioned forward-refs), greenfield clean,
merged supplemental internally consistent; **one out-of-scope carry-forward** — `iel/delegation.md` stub carries
the retired delegate-`manifest.bound`-on-`Trm` shape (canon: delegate `bound` in `Dth`'s `kills[]`); the two
diagram stubs (`iel/delegation.md`, `features/multi-party/documents.md`) are the `bootstrap.md` species,
doctrine deferred; 2026-07-10). **Prior (MERGE delivered; its F1/F2/F3 all FOLDED as folds #3/#5/#6 in PR#11):**
`.working/vdti-reconcile-review-warm-findings.md` (MERGE — phase-2 reconciliation, fidelity-to-canon; the first
design PR is a faithful/complete/consistent/greenfield encode of the ship-reviewed canon; all 9 properties
verified design↔canon; SAID §Rule-1 fix + four-state/merge-outcome backport landed; 3 [minor] — event-shape:476
grant-doc-vs-rescind-doc mislabel, reconciliation.md Matrix-1 below-seal position, Matrix-2 Disputed-source
cross-ref; `make all` 0, 2026-07-10). **Prior (SHIP delivered; whole-canon promotion gate):**
`.working/vdti-canon-holistic-review-warm-findings.md` (SHIP — all 14 canon files; no blocker/major; seams +
crown jewels verified adversarially; my Round C R3 sweep verified LANDED; 4 [minor]/[nit] — KEL 5-vs-6 (resolved
in the design PR), doc-policy §E `[fresh]`, token-store supplemental pointer, inv:667 tail; `make all` 0,
2026-07-10). **Prior (MERGE delivered; its one [consistency] sweep RESOLVED):**
`.working/vdti-failsecure-fold-review-warm-findings.md` (MERGE — R1–R6 + layering fold faithful; the converged
break R1 GENUINELY CLOSED (earliest floor + as-of, verified adversarially); layering sound; R2/R4/R5/R6 sound;
one [consistency] sweep — R3 doc-member carve-out, since propagated; `make all` 0, 2026-07-10). **Prior (HOLD
delivered; its F1/F2/F3 RESOLVED by the fold → R1/R4/R5):** `.working/vdti-failsecure-review-warm-findings.md`
(HOLD — 3 reconcile items:
earliest-issuance lower bound, private lookup-`Icp` publication, inv 4 stale raw `said(cred)`, 2026-07-09).
**Prior (HOLD; F1 the `attribute-all` over-reach RESOLVED at the root by the fail-secure rework):**
`.working/vdti-rereview2-warm-findings.md` (HOLD — the `attribute-all` opt-in over-claims a selective "confirm
clean" the addressing model forbids, 2026-07-09). **Prior (HOLD; the two-SEL correlation over-claim RESOLVED
by the B1 rework):** `.working/vdti-rereview-warm-findings.md` (HOLD — B1 positive-presence safety called
"sound", later BROKEN by cold B-1 + reworked, 2026-07-09). **Prior (folded — the encode-review HOLD's fixes
landed):**
`.working/vdti-first-seen-encode-review-warm-findings.md` (MERGE — the canon encode,
faithful/complete/consistent, 4 minor/nit — all folded, 2026-07-09) + the cold encode HOLD (B1/C1/C2/M1–M5,
folded). **Earlier (folded):** `.working/vdti-effective-said-warm-review-findings.md` (HOLD — reversal
sound+necessary, §2a completeness gaps F1–F5, folded into the encode). **DISPOSED + archived (2026-07-08 — L2
resolved + folded):** `archived/vdti-first-seen-warm-review-findings.md` (HOLD — ledger-completeness, the
first-seen reversal review, 2026-07-07). **Prior (disposition unknown this session):**
`.working/vdti-fold-and-diagrams-review-warm-findings.md`
(HOLD-with-findings, the fold + mermaid + removal round, 2026-07-04). **Closed/archived:** the
taxonomy-encode dual-pass findings (`vdti-taxonomy-encode-review-{warm,cold}-findings.md`, both in
`.working/archived/`) — every finding verified folded this round (the faithfulness map is in the
active findings file); the multi-party second-cut HOLD-4 is folded into
`docs/canon/vdti-area-multi-party-documents.md`; both convergence-round findings files are archived
(that arc closed, fold waived).

**Archived (`.working/archived/`):** `vdti-repair-completeness-findings-warm-r{1..5}.md` ·
`vdti-repair-completeness-encode-findings-warm.md` ·
`vdti-doctrine-quality-reverify-canon-findings.md` ·
`vdti-majority-quorum-canon-review-warm-findings.md` ·
`vdti-content-fork-prevention-fold-review-warm-findings.md` ·
`vdti-content-fork-prevention-encode-review-warm-findings.md`.
