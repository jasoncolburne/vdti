# warm-resume — warm-session context restore (post-compaction)

**This is the WARM session's resume. Never hand it to a cold pass** (asymmetric decorrelation:
warm gets everything, cold gets nothing — memory `feedback_dual_review_protocol`).

**On resume: LOAD THE FULL CANON BEFORE BEGINNING (standing, Jason 2026-07-03).** As the warm
reviewer you need a primed context — that priming IS what makes the warm pass warm. Before taking
any brief, read from disk: the whole canon (`vdti-repair-completeness-proof.md`,
`vdti-invariants.md`, `vdti-implementation-notes.md`, all `vdti-area-*.md`). Do **not** load the
landed `docs/design/` tree up front — canon and landed docs are two encodings of ONE design; only
one set belongs in memory, and **canon is canonical** (docs are re-read per-brief as review
evidence, when a brief requires them or Jason asks). This is the default every compaction; Jason
overrides with a note when he wants otherwise.

**Maintenance (standing, Jason 2026-07-02): update this file at the end of every review round** —
verdict delivered ⇒ refresh arc state / open items here, same-turn (the warm twin of
`design-resume.md`). Standing rules live in project memory (auto-loaded); this file carries
**arc state only**. For reasoning detail the compaction summary lost, grep the prior transcript:
`/Users/jason/.claude/projects/-Users-jason-github-com-jasoncolburne-vdti/a98d268e-b7e9-4ad1-bfb6-51fb9c87edd3.jsonl`.
Re-read every file from disk each round regardless — this file is orientation, never evidence.

## Role

Warm (contextual) reviewer, one effort level up, in Jason's hand-coordinated dual-pass topology.
Jason drives all design decisions and all git. A brief arrives as a `.working/*.md` path each
turn; findings go to the brief-named file — MERGE / HOLD-N at top, tagged findings, quoted
doc:line, `make all` exit 0 as a done-gate, edit nothing while reviewing. Warm sees prior cold
output by design (passes run simultaneously, so the in-flight cold is invisible by timing only);
derive findings independently, then state where cold would converge as a shared-blind-spot flag.

## Arc state (2026-07-03, HEAD `4b6c62c`; uncommitted: a reconciliation.md clarify pass in flight)

- **Content-fork prevention — SETTLED, ENCODED, REVIEWED, POLISHED.** The model: witness-config
  **majority floor `threshold > signers/2`** + the kind-scoped witnessing ladder (content
  first-seen, one sibling per `(prefix, serial)`; privileged up to **two** per position — two
  both-witnessed siblings ARE the `disputed:` proof; the resolving repair = the first privileged
  sibling, no separate clause) ⇒ **content forks on witnessed chains are prevented below
  fork-cost `2·threshold − signers`** (a priced dial: `fork-cost = threshold − slack`;
  double-signing attributable). Option (b): user-IEL content gated at its own position alongside
  Q1 anchors; federation IEL exempt; SEL rides the cross-layer theorem. Counting is
  **selection-scoped**. Recoverability cap **`threshold ≤ min(|roster| − 2, signers − 1)`**,
  `signers = 1` waiver ({1,1} evict-one = position-luck, warned); re-check on **any
  config-changing `Wit`** (incl. config-only). **Single-add federation `Wit`** (`add` scalar,
  `Fcp` exempt, `cut` a list). **`forks` → `fork`** (one root; unnamed branches close below-seal +
  by-descent — verified closure equivalence). Serialization: governance safety-critical
  everywhere; content-rail = liveness on witnessed chains, safety-critical direct-mode/solo.
  Propagation premise = success-rate/latency only, never safety. §1a reachability property
  verified (one `Wit` carries the full config delta → no forced invalid intermediates).
- **My verdicts this arc (all archived):** majority-quorum canon review **HOLD-2** → fold review
  **MERGE** (both Fable completions verified: waiver necessary+honest; collapse
  outcome-identical) → encode review **MERGE** (clusters A–J faithful; manifest independently
  clean incl. sad/policy/diagram; no cross-doc contradiction). Cold ran HOLD-11 on the canon
  round; its seam findings (config-transition F1, single-add P5) landed as the canon seam layer.
- **All my open findings are folded** (verified from disk 2026-07-03): the four fold-review LOWs
  (proof premise now lists the roster-delta straddle; area-fed elliptical bounds fixed;
  first-seen naming unified — 0 "first-receive" hits; area-sel has the transitive fork-cost
  note) and ALL of encode F1–F5 in `89f74cd` — F1 (content-rail uniformly "safety-critical on
  direct-mode") and the F2–F5 de-dup collapses exactly as recommended (verification's FORCE
  content-leg → split + §Federation-convergence ref; event-shape's witnesses/bounds/roster rows →
  shape/bound + ref, rationale prose removed). The "(verify at review)" tag is resolved out of
  area-fed.
- **Commit sequence (this layer):** `fbc62eb` majority-quorum canon → canon seam round
  (uncommitted fold I reviewed) → `a3e371e` re-encode landed design → `259968e`/`42ef536`
  format/CI → `89f74cd` review polish (encode-review folds + inception-exception Terminology
  clarification) → `5a5932b` **new `docs/design/README.md`** (reading-order map — I have not
  reviewed it) → `4b6c62c` + an uncommitted diff: reconciliation.md clarification in flight.
- **Repair-completeness model (settled r1–r5, re-scoped to the residual):** root-pointing
  (`fork` = one root condemning its subtree) + deadness-descends (same-chain + **IEL→SEL anchor
  edge only**) + bounded fork (depth ≤ 64/lineage; retention ≥ 2/position; the ladder) + two
  guards (no-self-condemnation over the full-span walk — tight form
  `root.parent = v_{d-1} ∧ root ∉ walkback` in impl-notes; content-only) + retain-and-count
  (scoped: passes hard auth, fails content-only; junk dropped) + `{Dec, content}` tier-rank +
  D1 two-valued finality (no-resurrection unconditional; resolution-stability gated;
  residuals: eclipse + historical reserve compromise + withheld-body split + roster-delta
  straddle) + cross-layer theorem (valid SEL fork ⇒ IEL fork; anchor-monotonicity with
  skip-unattributable). Runs against the residual population (direct-mode, fork-cost byzantine,
  straddles, split-stalls, mixed races).
- **Canon:** `.working/vdti-repair-completeness-proof.md`, `vdti-invariants.md` (inv 4/12/13/14/17),
  `vdti-area-{kel,iel,sel,federation-witnessing}.md`, `vdti-implementation-notes.md`. **Landed:**
  protocol-doctrine, system-thesis, **design/README.md (new)**, event-shape, six `kel/` docs,
  sad/ + policy/ trees, `docs/.terminology-forbidden` (root-pointing + fork-scalar bans).

## Open items

- **Unreviewed surfaces:** `docs/design/README.md` (5a5932b) and the in-flight reconciliation.md
  clarify diff — no review round has covered either yet. (Nothing of mine is outstanding.)

## Pending externally

- Forward-ref'd / unbuilt: `iel/` + `sel/` (the cross-layer bundle lands there),
  `federation/{witnessing,bootstrap}.md`, `operations/{multi-party-governance,recovery-workflow}.md`,
  `features/credentials/`, `infrastructure/vdtid.md`. Full-out design encoding planned after this
  review iteration set.

## My findings files (all in `.working/archived/`)

`vdti-repair-completeness-findings-warm-r{1..5}.md` ·
`vdti-repair-completeness-encode-findings-warm.md` ·
`vdti-doctrine-quality-reverify-canon-findings.md` ·
`vdti-majority-quorum-canon-review-warm-findings.md` ·
`vdti-content-fork-prevention-fold-review-warm-findings.md` ·
`vdti-content-fork-prevention-encode-review-warm-findings.md`.
