# VDTI first-seen model → canon reconciliation ledger

**What this is.** The encoding roadmap: what changes in `docs/canon/` when the first-seen model
(captured in `vdti-model-plain-english.md`, `vdti-event-kinds.md`, `vdti-adversary-cases.md`) is encoded.
The design is **settled and captured**; the canon is **untouched**. This ledger is the delete/keep/rewrite
list — the "residue sweep." (2026-07-07)

**Two hardening threads are folded in** (§2b receipt-threshold, §9 SAD-store `kind` filter — from
`vdti-witnessing-storage-hardening.md`, 2026-07-08). They are witnessing/storage-layer hardenings *adjacent
to* — not part of — the settled first-seen design, so they carry a **not-yet-independently-reviewed** status:
the encode-review is their **first decorrelated pass**. (§2b's match-check *safety* was verified this session;
§9 is a pure inv-16 enforcement — a subtraction.) Flag both to the encode-reviewer as not-previously-reviewed;
everything else in this ledger is review-settled.

Reading order for the model itself: `vdti-model-plain-english.md` (concepts) → `vdti-event-kinds.md`
(kind tables) → `vdti-adversary-cases.md` (the stress-test + what-we-tried-to-break).

---

## 1. Tiers & kinds

- **Two tiers only** — T1 (signing key) / T2 (rotation reserve). **Drop the recovery key** and everything
  that existed only for it.
- **Drop kinds:** KEL `Ror` + `Rec`; IEL `Rpr`; SEL `Fld` + `Rpr`. **Drop** tier T3, the `t_recover`
  threshold, and the `t_govern ≤ t_recover` floor.
- **Final kind sets** (per `vdti-event-kinds.md`):
  - KEL `Icp/Ixn/Rot/Wit/Trm`; **Federated KEL** `Fcp/Ixn/Rot/Wit/Trm` (`Fcp` root, `Wit` = governance).
  - IEL `Icp/Ixn/Evl/Ath/Rev/Dth/Trm/Wit`; **Federated IEL** `Fcp/Wit/Trm` (restricted).
  - SEL `Icp/Ixn/Pin/Gnt/Trm`.
- **All key changes single-signed** with the rotation reserve (no dual-sig anywhere).
- **Kind-strict anchor matrix re-homing:** IEL/SEL acts that anchored to the deleted `Ror`/`Rec` re-home to
  `Rot`/`Wit` (e.g. the federation `Trm` was `Ror`-anchored). A deliberate sweep; flag any that don't
  re-home cleanly.
- Threshold vector becomes `{t_use, t_govern, t_authorize}` (drop `t_recover`).

## 2. Witnessing & divergence — the first-seen pivot

- **Witnessing rule is scoped by chain**, one test: *could a single already-revealed secret author a
  competing sealed sibling?*
  - **Yes → first-seen** (one sealed sibling; decline the rest): single-key chains — KEL, single-member
    IEL, single-owner SEL. Forced by Rot'@v_M.
  - **No → record-both**: threshold chains — federation IEL, multi-member IEL governance.
- **Terminology:** **`sealed`** replaces **`privileged`** everywhere (a sealed event = a seal-advancing
  event). Leaner, and it doesn't collide with "sealed on arrival" (that stays for the kill *timing*).
  Global rename across canon + the model files — mechanical, do as its own verifiable pass.
- **Cross-tier co-sign + the per-serial bound.** A witness's slot is `{≤ 1 content, ≤ 2 sealed}` per
  serial. **Double-signer forensics count by tier** — a cross-tier `{content, sealed}` pair is a legit
  co-sign, never misbehavior (else honest witnesses recording a fork get evicted); two *same-tier*
  signatures (`{content, content}` or `{sealed, sealed}`) is the cheat.
- **The bound is early-termination, not a production cap.** Under dishonest signers there is **no**
  production cap — a compromised quorum can threshold-witness a 3rd/Nth competing sealed event. The
  verifier's work is bounded instead: it **early-terminates at 2 witnessed sealed SAIDs → Disputed →
  terminal** (monotone; a 3rd is redundant, reincept regardless). **Sub-threshold sealed events are
  fail-secure ignored** (a lone dishonest witness's flood never reaches "real"). Per-serial materialization
  is **O(1), flood-independent**: **≤ 2 content** (a race is majority-floor-capped at two content branches)
  **+ ≤ 2 sealed** = 4 worst-case; on the `fork-cost`-only (recoverable) path it is **≤ 3** (a 2-content race
  and a 2-sealed dispute co-occurring at one serial needs reserve theft → already terminal — cold M1).
  Forming even the 2 sealed is the attributable boundary (`fork-cost` forced double-signers, §5).
- **Forked vs Disputed are distinct, derived states** (not "both disputed"). **Forked** = a fork with ≤ 1
  sealed branch past it. **Disputed** = ≥ 2 sealed branches → **terminal** (reincept). The walk derives
  which; the verdict rides the sealed-branch count M (Forked iff M ≤ 1, Disputed iff M ≥ 2; content count N
  is irrelevant — all content is buriable). **Forked resolves to its single surviving sealed tip —
  recoverable *if* that tip is the owner's recovery `Rot`; a *hostile* sealed tip at a contested position is
  the reserve-theft takeover** (terminal/silent, owner-vigilance only), **not** a recoverable fork (cold C1
  — the owner's counter-`Rot` makes it M = 2 → disputed; a hostile late fork with only a stolen *signing*
  key is inert, case 4). *(Supersedes the earlier "call them both disputed" simplification.)*
- **Effective-SAID = single confirmed tip → its real SAID; no single tip → a `synthetic`** marker
  **recoupled to the verdict** (`forked` / `disputed`), qualified by prefix + position, and **type-tagged so
  it is structurally distinct from any real SAID** (cold M3 — so the "single-tip SAID ≠ synthetic" inequality
  that fires anti-entropy is structural, never a probabilistic collision; the encoder must not reduce it to a
  bare SAID-shaped digest). **No digest over the competing tips** (the old live-tips hash is deleted). *Why:*
  a real digest over the competing set is
  **flood-unstable** — under dishonest signers the set grows, the hash changes, differently-viewed
  verifiers disagree / thrash; "which 2" is view-dependent. A synthetic is **set-independent →
  flood-stable**, still **triggers anti-entropy** (a single-tip SAID ≠ a synthetic), and is
  **verdict-sufficient**. The exact set is never needed for the value — root-bury kills all content
  branches by position (masking harmless), Disputed reincepts (outcome invariant to the set), and
  attribution walks the **stored events**, not the digest. Detail + the consumer read: **§2a**.
- **Delete:** two-per-position on single-key chains; the deliberate-`disputed` manufacture on single-key
  chains; the live-tips hash; anti-entropy branch-assembly (§2a).

### 2a. Effective-SAID resolution — the L2 companion (consumer analysis + machinery deletions)

The effective-SAID above **reverses** `vdtid-services §1e` ("real digest over LIVE held tips, NO
synthetics" — high-confidence, four-round-reviewed). §1e was sound **under live, honest, first-seen
witnesses** (which bound the branch count); the first-seen pivot + federation-death + dishonest-signer
adversary voids that assumption. This session's break + consumer read:

- **The break.** A digest over the competing branch set can't give the stable arbiter-free agreement §1e
  wanted — the set is adversarially extensible (no production cap), so it thrashes and differently-viewed
  verifiers disagree. §1e's own defense (`§1e:168`, "the un-witnessed flood is dropped") covers only
  *un*-witnessed floods — exactly the case first-seen can't lean on.
- **No consumer's *trust* decision needs branch-sensitivity** (narrowed per cold B2 — see the eviction
  caveat below). §1e already **decouples the digest (change-detector) from the verdict (walk reading)**;
  every consumer's *trust* decision reads the **verdict** (from held events), never the digest's branch
  content:
  - *§1e / §1i (anti-entropy):* needs the value to move on tip-advance + verdict-transition → a synthetic
    does (single-tip SAID ≠ `forked` ≠ `disputed`). Auto-**assembly** of every branch was a repair-era
    need; root-bury resolves by position, never assembles → convergence becomes **owner-driven** (the
    root-bury `Rot` propagates as a normal witnessed event), not anti-entropy-driven.
  - *§1i:* `since: {seal}` survives as a **branch-agnostic pull**; the branch-assembly + condemned-branch
    send-side ordering (`§1i:250-262`) **dies** with `Rpr`.
  - *document-policy §F (revocation-freshness):* needs the value to move when a `Trm` lands (a new sealed
    tip → it moves) + the verdict. **Any non-single-tip state — `forked` *or* `disputed` — grounds no new
    trust → fail-secure refuse** (cold B1: a `forked` cred-SEL can't advance past the fork, so a pending
    revocation `Trm` can't land; if `forked` granted trust, a T1 thief who wins one content race would read
    "not revoked" and get a being-revoked cred accepted — a blast-radius extension. `forked`→refuse degrades
    the induced fork to a *denial*, never a *grant*). So the value can't *hide* a revocation; no branch
    identity needed. **Canon home: `document-policy §F` / `inv 8` honor decision — refuse *any* non-single-
    tip chain, not just `disputed`.**
- **The one thing branch-sensitivity *did* give (cold B2): forensic eviction-completeness.** Cheating-witness
  eviction needs the **union** of competing sealed events (which witness double-signed which pair). The old
  real-digest made two same-verdict nodes with different sealed sets disagree → anti-entropy synced them →
  the union assembled for free; the synthetic doesn't. This is **not a safety break** — the identity outcome
  is set-independent, each fork stays detected/attributable, and incomplete eviction only means "contained
  again next time" (a liveness/hygiene cost). The events *are* recoverable from stored data **iff** gossiped,
  so **eviction-completeness rides the independent receipt/event-gossip channel (best-effort, per-node), not
  the effective-SAID anti-entropy.** State this so the narrowed claim isn't misread as "the union is free."
- **Canon edits this adds (warm L1 + the effective-SAID re-review F1–F5 — not previously in the ledger):**
  - `vdti-area-vdtid-services.md` **§1e** — rewrite: single-tip → real SAID; no single tip → synthetic,
    verdict-recoupled; delete the live-tips hash + the "real not synthetic" argument. **§1i** — delete the
    branch-assembly `since`-drag + condemned-branch send-side ordering; `since:{seal}` stays a plain pull.
    **§1h:193-194** (re-review F5) — the `DeferredDepsResponse` `chainEffSaid` clause ("the effective-SAID is
    now the real branch-derived digest") inverts, and `chainEffSaid` + `transientChainState` converge (the
    synthetic now *carries* the forked/disputed reading).
  - **`docs/.terminology-forbidden` (re-review F1 — BREAKS `make all`; do this first).** Lines **:174
    (`forked:`) + :175 (`disputed:`) are banned tokens the lint walks** — the reversal reintroduces the
    verdict-recoupled `forked:`/`disputed:` synthetic → `scripts/lint-terminology.sh` rejects it → gate red.
    **Un-ban :174/:175; KEEP :172 (`divergent:`) + :173 (`irreconcilable:`)** (the truly-dead kels
    synthetics). And **rewrite the `docs/canon/.terminology-forbidden:148-156` comment** (it asserts "the
    effective SAID is a real digest… no hash-prefix strings" — the reversed model verbatim).
  - **`vdti-area-kel.md:89` (re-review F2)** — "the effective-SAID is a **real digest over the live tips**,
    not a synthetic" **inverts** → single-tip → real SAID; no single tip → synthetic.
  - `vdti-implementation-notes.md` **:22-91** — the "live-tips, no synthetic" build spec inverts.
  - `vdti-area-document-policy.md` **§F** — state the revocation-freshness read is verdict-based, and add the
    **B1** rule (refuse *any* non-single-tip chain, `forked` too).
  - `inv 17` — **multiple** live-tips passages, not one (re-review F3): **:745, :748, :769-772, :779-782**
    (incl. the "no synthetics" assertion at :781) all invert to single-tip-real / no-single-tip-synthetic;
    plus the receipt-cap wording (≤ 2 content + ≤ 2 sealed, §2 M1).
  - **`inv 8:272-273` (re-review F5)** — the multi-source freshness bar is **satisfied**: the synthetic is
    derived from **witnessed** events → multi-source by construction; a non-single-tip chain grounds no new
    trust. One confirming line, since revocation-freshness rests on this gate.
- **Load-bearing dependency to preserve (re-review F4): the verdict-recoupling is sound *only* under the F-F
  pure-walk.** `inv 13:484-487` makes the verdict a **pure walk of the held set, seal derived**
  (arrival-order-independent) — the very decoupling §1e did to fix F2/H1. Re-coupling the synthetic to the
  verdict is safe **only because** the verdict stays order-independent, so §3's "delete inv 13's divergence
  rules" must **KEEP `inv 13:484-487`** (see §3).

### 2b. Receipt-encoded threshold — cheap witnessed-detection (hardening thread)

**Status: folded from `vdti-witnessing-storage-hardening.md`; NOT independently design-reviewed — the
encode-review is its first decorrelated pass.** The match-check *safety* was verified this session (below);
one *value* point is flagged review-pending. Adjacent to §2 (witnessing layer) but a distinct addition — it
touches receipt structure + `vdtid-services` routing, not the first-seen pivot.

- **The idea.** Encode the **witness-config `threshold`** in each receipt, so witnessed-detection becomes
  **count `threshold`-many agreeing receipts** on `(event SAID, threshold)` — **no chain-walk to resolve the
  in-effect threshold**. Receipts are bare attestation data today (`federation-witnessing:197`); the config
  `{said, threshold, signers}` is chain-committed (inv 12 / `:319`) but receipts don't carry it.
- **What it buys — and its true scope [REVIEW-PENDING].** Detection becomes a receipt count; it **defers,
  not eliminates**, the chain read to pull-and-validate (done once anyway). It is cheap **because the
  detecting witness already holds the live roster as mesh state** (`:60`) — so the receipt saves the
  *in-effect-threshold walk* specifically, **not** the roster/selection (still needed to know a receipt is
  from a selected witness). State this scope explicitly at encode, else "no chain read" reads bigger than it
  is.
- **The match check (load-bearing; safety verified).** On pull, the receipts' threshold must **exactly match
  the chain-authoritative threshold** — the committed witness-config SAD **in effect at that position**,
  never the self-asserted receipt field. Mismatch → **invalid, even if higher**:
  - *Receipts < real:* an adversary reports a low bar so fewer receipts "witness" it → forgery. Caught at
    pull (the real config needs more).
  - *Receipts > real:* still invalid — **faithfulness** (a witness misrepresenting one field can't be
    trusted on the rest; "higher = safer" is false) + **liveness/DoS** (an inflated bar stalls honest nodes)
    + the `(SAID, threshold)` agreement makes an inflated receipt **disagree** with honest ones → detected.
  - *The consistent lie* (event + receipts both say 2, real config is 4) is defeated **because the match is
    against the committed SAD, not the receipt field** — the crux, and it holds.
- **Position-determinism.** The encoded threshold must be the config in effect **at that position**
  (committed at-or-before the serial). A **stale-config** witness (lagging `Wit` / governance change) emits a
  non-matching receipt → discarded (a liveness cost around config changes, not a safety hole). Composes with
  the **key-window** gate (`:108-117`): a valid receipt needs {valid sig, inside key-window, threshold-matches}.
- **Keep straight.** *Witnessed*-detection (is it backed?) is distinct from *disputed*-detection (data-local,
  ≥ 2 sealed branches, `:305`). They compose — the receipt-threshold makes "should I pull" cheap; disputed
  stays a data-local re-validation.
- **Gossip / relay mechanics (reconciled).** The mesh is **witness-only and encrypted** (`:286`) — no
  non-witness observer (else correlation). The event **body never floods** (targeted transfer); only receipts
  flood. Flow: user → their **preferred witness** (usually *not* selected — fine) → that witness **computes
  the selection locally** from `(prefix, serial)` + the roster it holds (`:60`) and **routes the body to the
  ~`signers` selected witnesses** → they **receipt + sub-gossip** the body (`:272`) → **receipts flood** →
  the preferred witness answers **"witnessed?" from receipts alone** (no body, no walk) → the body is
  **pulled on-demand** only when the content is wanted. **Not load-bearing that the user reach the selected
  witnesses** — any witness relays the body in and reports the status out.
- **Canon edits:** receipt structure gains `threshold` (+ the `(SAID, threshold)` agreement + the match
  rule); `federation-witnessing §1e:272` ("counts toward an event's threshold") picks up the match check +
  the position-deterministic-config / stale-witness-receipt rule; the routing-computed-on-the-receiving-node
  mechanic lands in `vdtid-services`.

## 3. Recovery & eviction — replacing the repair machinery

- **Recovery = a plain rotation** that buries at the **root** (the first compromised position; the whole
  run below dies by descent). No repair/recover *kind*, no recovery key.
- **Eviction = a governance `Evl`-with-`cut`** — one seal buries the fork *and* evicts, atomically. No
  repair-and-evict *fold* (there's no `Rpr`).
- **DELETE `docs/canon/vdti-repair-completeness-proof.md`** entirely — nothing to prove once there's no
  repair event.
- **Delete:** inv 13's two divergence rules + all repair machinery; inv 4's `fork` manifest role;
  root-condemnation; FORCE-by-provenance *(check: does any of it survive scoped to federation `disputed`?)*.
  **But KEEP `inv 13:484-487` — the F-F pure-walk** (the verdict is an arrival-order-independent walk of the
  held set, seal derived); the verdict-recoupled effective-SAID rests on it (§2a re-review F4). Update its
  repair-era wording (burying-seal-advancer / direct-mode / `Rec`/`Rpr`) to first-seen; don't delete the
  principle — losing it reopens F2/H1.
- **Keep:** content burying (deadness-descends), the **spine + seal-cap** (uniform, all chains),
  keep-all-data, cross-layer deadness-descent.

## 4. Bounds & floors

- **Roster cap = 32** for **all** IELs (federation included), walk-enforced (reject any change that would
  push the live set past 32). Change `federation-witnessing.md:85` ≈128/256 → 32; **add** the same
  walk-enforced cap to user IEL rosters (only stated for the federation today).
- **Majority floor on the authority thresholds:** `t_govern`, `t_authorize > |roster|/2`. Add to inv 12
  alongside `≥ 2` and `≤ |roster| − 1` (compatible for every `|roster| ≥ 3`). **`t_use` exempt** (content
  is first-seen / recoverable). This closes the disjoint-quorum attribution loss.
- **Witness-config floors** — a *distinct* floor set from the governance floor above: these bound the
  **witness pool `{threshold, signers}`**, not the identity's own `t_*`. (Extracted from the held
  pre-first-seen backport plan; model-independent, still valid.) Every witnessed chain's config satisfies
  `signers ≥ 3` (byzantine tolerance), majority `threshold > signers/2` (the fork-cost floor), and
  availability `threshold ≤ signers − 1` (no single-witness brick). The `Fcp`-rooted federation IEL
  witness roster is **≥ 4 structural, ≥ 5 recommended** (evict-one / survive-1-loss at 4; the fork-cost
  dial + survive-2 at 5). **Delete all `signers = 1` waiver machinery** (`{1,1}` lone-witness,
  position-luck-evict-one, `signers − 1`-leg waivers) — `signers ≥ 3` removes the degenerate. Homes:
  inv 4 (config bounds), inv 12/14 (federation floor), federation-witnessing §1a/§1c/§1e.
- **Fork-cost is a dial, not a warned footgun** (extends §5's observable-breach). `fork-cost =
  2·threshold − signers = threshold − slack` (`slack = signers − threshold`), floored at 1 (majority) and
  `slack ≥ 1` (availability), raised toward `threshold` via `{signers, threshold}`. Drop any `minForkCost`
  field — cost 1 is the structural floor, not a footgun. Content-fork resistance and availability
  over-provisioning trade one-for-one, by construction.
- **Config-enforcement principle:** the verifier disallows the genuinely unsafe (a zero-byzantine content
  fork, a single-witness brick, sub-majority, an un-evictable / un-recoverable federation) and leaves the
  widest safe space open.

## 5. New / promoted invariants

- **Observable-breach guarantee → explicit invariant.** `fork-cost = 2·threshold − signers` is the number
  of *forced, attributable* double-signers, so **no *forced fork* is silent** — it surfaces as `disputed`
  on an active chain, or a staleness flag on a dormant one. Boundary: a full `threshold`-witness compromise
  (the trust-root limit).
- **Scope correction (cold blocker B): the guarantee is "no silent *forgery* (forced fork)", NOT "no
  silent breach".** A reserve-theft **takeover-by-extend** on a *dormant* chain forces nothing (witnesses
  sign it willingly as a valid first event at the tip) → it is neither `disputed` (no conflict) nor stale
  (fresh receipts), so to a third party it reads as an ordinary rotation. It is caught only by **owner
  vigilance** — the owner knows they didn't author that `Rot`. Name owner-recognition as the dormant-chain
  signal; reserve theft stays unrecoverable (→ reincept once the owner surfaces it as a fork). Fix the
  headline claim in `vdti-model-plain-english.md` ("no silent breach" → "no silent forgery") and
  `vdti-adversary-cases.md`.
- **Freshness → mandatory trust gate + witness-sig monotonicity** (dormant-forgery defense). Fold freshness
  into the *definition* of "trusted"; monotonicity (receipts march forward in time) blocks a harvested-key
  forgery on any active chain. Lands in federation §1f.

## 6. Structural removals

- **Direct mode removed** — every identity is federation-witnessed. Strike the direct-mode `Icp` (omitting
  the binding), the "witnessing starts from a later `Wit`, early range unwitnessed" allowance, and the
  direct-mode fork caveats in federation-witnessing §1e. (The `Fcp` federation-genesis bootstrap is **not**
  direct mode — keep it.)

## 7. Cross-layer (SEL ↔ IEL)

- SEL keeps its spine (`Gnt`/`Trm`). Cross-layer resolution = the owner IEL's burying + deadness-descends
  across the anchor edge. **Re-verify** the "*a valid SEL fork implies an IEL fork*" theorem under
  first-seen (should hold — anchor-monotonicity is unchanged).

## 8. Warm-review residue (L3–L9) — additional canon edits the encode must carry

From the first-seen warm review (findings in `archived/`); L1–L2 are folded above (§2a). The rest:

- **L3 — SEL `Fld` deletion collides with area-sel §4's "NOT transitive" finding.** area-sel §4 explicitly
  rejected "just don't fold the SEL" (Jason 2026-06-27); the `Fld` bounded the content run for *page-atomic
  repair*. Deletion is sound — **no repair ⇒ no page-atomicity requirement ⇒ no `Fld` bounding** (finality
  still floors to the owner IEL via the pin) — but state that justification. Sweep area-sel: the `Fld`
  taxonomy row (:95), "seals itself via `Fld`" (:108), §4's `Fld`-SEPARATED block (:185-193), the anchor pair
  `Evl ↔ Fld` (:104, :131). The SEL keeps `Gnt`/`Trm` as seal-advancers.
- **L4 — direct-mode removal is under-listed; §1d is the canonical home, not §1e.** Fullest definition:
  `federation-witnessing §1d:182-191` ("Direct mode is a reachable mode") + a second copy in
  `document-policy §R4:52-58`; also inv 13:487 + §1e:359-371's "in BOTH modes" (collapses to witnessed-only —
  a real simplification to claim), area-kel:33, area-iel:33, vdtid §1d. §6 above names only §1e.
- **L5 — multi-party-documents carries repair citations to retarget.** §3:227-243 cites "the repair proof's
  §Cross-layer" + "the IEL resolves [via `Rpr`]" → point at the cross-layer rule / "the IEL fork is buried by
  the recovering key change". §7:383 anchor matrix lists the deleted `Evl ↔ Fld` and `Rpr ↔ Rpr` → strike.
  §4:264-274 "archival tail" vocabulary → the conclusion (a privileged/sealed event forces reincept)
  survives, the vocabulary references deleted machinery.
- **L6 — federation `Trm` clock reason references `Ror`.** area-iel:33 + inv 14:401: the federation `Trm` is
  "`Ror`-anchored… self-attesting under the windows its `Ror`s reveal" → re-home to the federation KEL `Rot`
  (a `Rot` reveals fresh windows too); the *user* IEL `Trm` re-homes identically.
- **L7 — "no unwitnessed mode" (design docs) vs the KEPT `Fcp` self-attested genesis.** The `Fcp` genesis IS
  unwitnessed (a config-pinned trust root); add the carve-out to the design docs' absolute phrasing so it
  doesn't read as contradicting the retained bootstrap.
- **L8 — the roster cap 32 shrinks the max federation 4–8×** (from ~128/256). Intended (§4), but confirm no
  deployment wants > 32 witnesses (operator doctrine is ≥ 5, so 6× headroom).
- **L9 — the majority floor is a real `t_authorize` tightening for `|roster| ≥ 4`** (forces > half to sign
  every grant). Justified by the pigeonhole attribution; confirm intended alongside `t_govern`.

## 9. SAD-store hardening — the `kind` filter (hardening thread)

**Status: folded from `vdti-witnessing-storage-hardening.md`; NOT independently design-reviewed.** Unlike
§2b this is a **pure subtraction enforcing an existing invariant (inv 16) at the storage boundary** — low
review surface; the encode-review suffices. One *factual* to-do before encode (not a design question):
**verify `kind` is populated everywhere on SAD data.**

- **The attack.** Event SAIDs float free of their prefix by design (`said ≠ prefix`; the opaque `anchors[]`
  commitment, `area-sel:129`). From a **public** issuer IEL, harvest every `anchors[]` SAID (commitments to
  the issuer's cred-SEL events). If the SAD store answers a **fetch-by-SAID for an event body**, look each
  up → get the SEL `v1` / `Icp` → recompute `derive(owner, topic, data)` → recover the cred-SEL prefix →
  **enumerate and de-anonymize every credential the issuer issued** (and holders), using VDTI's own store as
  the inversion oracle.
- **The fix.** Detect an event by **`kind`** and **reject it from the SAD store.** Enforces inv 16 (logs are
  **prefix**-addressed, never SAID-fetched) **at the write boundary** — nothing legitimate needs an event
  body in the SAD store (events live in the chain log), so fetch-by-SAID **physically cannot return an
  event**. Bypass-robust: stripping the `kind` changes the content → changes the SAID → misses the
  attacker's harvested *real* event SAID.
- **Make `kind` required on SAD data** → a clean **per-kind store policy** (allow content kinds, reject event
  kinds, mark any "opaque" kind not-fetchable-by-SAID); `kind` is the authoritative classifier, no fragile
  shape-match. Needs **event-kinds and content-SAD-kinds cleanly partitioned**; making `kind` required
  changes those SADs' SAIDs (free at design stage); a `kind` on a fetchable SAD leaks nothing (type already
  public), an opaque one isn't fetchable to read the kind.
- **Preferred over the availability alternative.** SADs already carry availability (`nodes: []` → won't
  propagate); the alternative would add an availability field to *events*. The **kind filter is better** —
  don't add availability to all events.
- **Write it as the principle, not a bare kind list:** *"nothing whose SAID must stay opaque is fetchable by
  SAID from the store"* — catches a future free-floating SAD type too. **Scope to events (by kind) now** —
  manifest-role SADs (roster/threshold delta, `pins`-SAD) also carry identifiers, but their SAIDs are
  reachable only *through* a chain you already have the prefix for (not free-floating like `anchors[]`), so
  they give the attacker nothing new; events are the sharp case.
- **Canon edits:** the `vdtid-services` SAD-store write path rejects event-kinded submissions; inv 16 gains
  the enforcement note (+ the "opaque-SAID ⇒ not SAID-fetchable" principle); `kind` required on SAD data
  (pending the usage check).

---

## Encoding order (suggested)

Doctrine/tiers (§1) → event-shape kinds (§1) → witnessing/first-seen (§2 + the §2a effective-SAID + the §2b
receipt-threshold) → divergence rewrite + delete the proof (§3) → bounds/floors (§4) → new invariants (§5) →
structural removals (§6) → cross-layer (§7) → the SAD-store `kind` filter (§9) → the warm residue (§8). Get a
fresh cold review of the *encoding* after — and a focused re-review of the effective-SAID resolution (§2/§2a)
first, since it reverses the four-round-reviewed §1e and post-dates the design review this ledger accompanies.
**The two hardening threads (§2b, §9) get their first decorrelated look in that encode-review — flag them to
the reviewer as not-previously-reviewed.**
