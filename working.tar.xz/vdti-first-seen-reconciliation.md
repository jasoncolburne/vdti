# VDTI first-seen model → canon reconciliation ledger

**What this is.** The encoding roadmap: what changes in `docs/canon/` when the first-seen model
(captured in `vdti-model-plain-english.md`, `vdti-event-kinds.md`, `vdti-adversary-cases.md`) is encoded.
The design is **settled and captured**; the canon is **untouched**. This ledger is the delete/keep/rewrite
list — the "residue sweep." (2026-07-07)

Reading order for the model itself: `vdti-model-plain-english.md` (concepts) → `vdti-event-kinds.md`
(kind tables) → `vdti-adversary-cases.md` (the stress-test + what-we-tried-to-break).

---

## 1. Tiers & kinds

- **Two tiers only** — T1 (signing key) / T2 (rotation reserve). **Drop the recovery key** and everything
  that existed only for it.
- **Drop kinds:** KEL `Ror` + `Rec`; IEL `Rpr`; SEL `Fld` + `Rpr`. **Drop** tier T3, the `t_recover`
  threshold, and the `t_govern ≤ t_recover` floor.
- **Final kind sets** (per `vdti-event-kinds.md`):
  - KEL `Icp/Ixn/Rot/Wit/Trm`; **Federated KEL** `Fcp/Ixn/Rot/Wit/Trm` (`Fcp` root, `Wit` = governance).
  - IEL `Icp/Ixn/Evl/Ath/Rev/Dth/Trm/Wit`; **Federated IEL** `Fcp/Wit/Trm` (restricted).
  - SEL `Icp/Ixn/Pin/Gnt/Trm`.
- **All key changes single-signed** with the rotation reserve (no dual-sig anywhere).
- **Kind-strict anchor matrix re-homing:** IEL/SEL acts that anchored to the deleted `Ror`/`Rec` re-home to
  `Rot`/`Wit` (e.g. the federation `Trm` was `Ror`-anchored). A deliberate sweep; flag any that don't
  re-home cleanly.
- Threshold vector becomes `{t_use, t_govern, t_authorize}` (drop `t_recover`).

## 2. Witnessing & divergence — the first-seen pivot

- **Witnessing rule is scoped by chain**, one test: *could a single already-revealed secret author a
  competing privileged sibling?*
  - **Yes → first-seen** (one privileged sibling; decline the rest): single-key chains — KEL, single-member
    IEL, single-owner SEL. Forced by Rot'@v_M.
  - **No → record-both → `disputed`**: threshold chains — federation IEL, multi-member IEL governance.
- **Cross-tier co-sign:** the witness slot is `{≤1 content, ≤N privileged}` per serial (N=1 single-key,
  N=2 group). **Double-signer forensics must count by tier and by config cap** — cross-tier pairs are never
  misbehavior (else honest witnesses doing the stall-exit / record-both get evicted).
- **`disputed` = observable divergence, everywhere.** The recover-vs-reincept verdict rides the fork's
  **tier** (content fork → recoverable; key-change fork → terminal). No `forked`/`disputed` split in the
  *state name*.
- **Effective-SAID:** content fork → synthetic `forked:<last seal>` (flags it, branches doomed);
  key-change fork → real `disputed:` digest over the competing seals (must expose all → converge).
- **Delete:** two-per-position on single-key chains; the deliberate-`disputed` manufacture on single-key
  chains.

## 3. Recovery & eviction — replacing the repair machinery

- **Recovery = a plain rotation** that buries at the **root** (the first compromised position; the whole
  run below dies by descent). No repair/recover *kind*, no recovery key.
- **Eviction = a governance `Evl`-with-`cut`** — one seal buries the fork *and* evicts, atomically. No
  repair-and-evict *fold* (there's no `Rpr`).
- **DELETE `docs/canon/vdti-repair-completeness-proof.md`** entirely — nothing to prove once there's no
  repair event.
- **Delete:** inv 13's two divergence rules + all repair machinery; inv 4's `fork` manifest role;
  root-condemnation; FORCE-by-provenance *(check: does any of it survive scoped to federation `disputed`?)*.
- **Keep:** content burying (deadness-descends), the **spine + seal-cap** (uniform, all chains),
  keep-all-data, cross-layer deadness-descent.

## 4. Bounds & floors

- **Roster cap = 32** for **all** IELs (federation included), walk-enforced (reject any change that would
  push the live set past 32). Change `federation-witnessing.md:85` ≈128/256 → 32; **add** the same
  walk-enforced cap to user IEL rosters (only stated for the federation today).
- **Majority floor on the authority thresholds:** `t_govern`, `t_authorize > |roster|/2`. Add to inv 12
  alongside `≥ 2` and `≤ |roster| − 1` (compatible for every `|roster| ≥ 3`). **`t_use` exempt** (content
  is first-seen / recoverable). This closes the disjoint-quorum attribution loss.
- **Witness-config floors** — a *distinct* floor set from the governance floor above: these bound the
  **witness pool `{threshold, signers}`**, not the identity's own `t_*`. (Extracted from the held
  pre-first-seen backport plan; model-independent, still valid.) Every witnessed chain's config satisfies
  `signers ≥ 3` (byzantine tolerance), majority `threshold > signers/2` (the fork-cost floor), and
  availability `threshold ≤ signers − 1` (no single-witness brick). The `Fcp`-rooted federation IEL
  witness roster is **≥ 4 structural, ≥ 5 recommended** (evict-one / survive-1-loss at 4; the fork-cost
  dial + survive-2 at 5). **Delete all `signers = 1` waiver machinery** (`{1,1}` lone-witness,
  position-luck-evict-one, `signers − 1`-leg waivers) — `signers ≥ 3` removes the degenerate. Homes:
  inv 4 (config bounds), inv 12/14 (federation floor), federation-witnessing §1a/§1c/§1e.
- **Fork-cost is a dial, not a warned footgun** (extends §5's observable-breach). `fork-cost =
  2·threshold − signers = threshold − slack` (`slack = signers − threshold`), floored at 1 (majority) and
  `slack ≥ 1` (availability), raised toward `threshold` via `{signers, threshold}`. Drop any `minForkCost`
  field — cost 1 is the structural floor, not a footgun. Content-fork resistance and availability
  over-provisioning trade one-for-one, by construction.
- **Config-enforcement principle:** the verifier disallows the genuinely unsafe (a zero-byzantine content
  fork, a single-witness brick, sub-majority, an un-evictable / un-recoverable federation) and leaves the
  widest safe space open.

## 5. New / promoted invariants

- **Observable-breach guarantee → explicit invariant.** `fork-cost = 2·threshold − signers` is the number
  of *forced, attributable* double-signers, so **no trusted forgery is silent** — it surfaces as `disputed`
  on an active chain, or a staleness flag on a dormant one. Boundary: a full `threshold`-witness compromise
  (the trust-root limit).
- **Freshness → mandatory trust gate + witness-sig monotonicity** (dormant-forgery defense). Fold freshness
  into the *definition* of "trusted"; monotonicity (receipts march forward in time) blocks a harvested-key
  forgery on any active chain. Lands in federation §1f.

## 6. Structural removals

- **Direct mode removed** — every identity is federation-witnessed. Strike the direct-mode `Icp` (omitting
  the binding), the "witnessing starts from a later `Wit`, early range unwitnessed" allowance, and the
  direct-mode fork caveats in federation-witnessing §1e. (The `Fcp` federation-genesis bootstrap is **not**
  direct mode — keep it.)

## 7. Cross-layer (SEL ↔ IEL)

- SEL keeps its spine (`Gnt`/`Trm`). Cross-layer resolution = the owner IEL's burying + deadness-descends
  across the anchor edge. **Re-verify** the "*a valid SEL fork implies an IEL fork*" theorem under
  first-seen (should hold — anchor-monotonicity is unchanged).

---

## Encoding order (suggested)

Doctrine/tiers (§1) → event-shape kinds (§1) → witnessing/first-seen (§2) → divergence rewrite + delete the
proof (§3) → bounds/floors (§4) → new invariants (§5) → structural removals (§6) → cross-layer (§7). Get a
fresh cold review of the *encoding* after, separate from the design review this ledger accompanies.
