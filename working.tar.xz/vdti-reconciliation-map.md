# docs/design ← docs/canon reconciliation map

**What this is.** The plan for the **phase-2 reconciliation**: bring the landed `docs/design/` docs into
alignment with the ship-reviewed `docs/canon/`. One concept per PR, in build order, dual-pass reviewed
(warm fidelity-to-canon + cold standalone-soundness), `make all` 0 the done-gate. **Jason drives sequencing
and does all git; this file is the map, not a mandate.** Built 2026-07-10 after a full canon re-read + a
stale-token scan of `docs/design/`.

> **This is reconciliation of already-landed docs, not a greenfield encode.** `docs/design/` exists; the
> canon has moved ahead. Where a primitive's docs are only stubs (IEL) or absent (SEL, services), that leg is
> write-fresh-from-canon; everywhere else it is bring-the-existing-doc-current. Greenfield voice throughout
> (state the model, no "previously X" / history — the canon keeps the history; the landed docs don't).

## Scope — the reconciliation surface, sized

The whole redesign since the last `docs/design/` land is un-propagated (expected — the canon is the leading
edge). The reconciliation spans **first-seen + two-tier collapse + fail-secure + layering + SS-3**, so it hits
**KEL heavily** too, not just IEL/SEL onward. A stale-token scan sizes each doc's reconcile:

- **Already landed** (0 stale hits): the 2026-07-04 taxonomy renames — `Del`→`Ath`, `Kil`→`Rev`/`Dth`,
  `Dec`→`Trm`, and `policyPin` / `grp` / `dev` / `federationBinding` all gone.
- **Still on the old model** (per-file `Ror|Rec|t_recover|recovery key|three-tier|Rpr|recoveryHash|recoveryKey|T3`
  hits): `event-shape.md` 55 · `protocol-doctrine.md` 53 · `kel/reconciliation.md` 78 · `kel/events.md` 74 ·
  `kel/recovery.md` 65 · `kel/merge.md` 50 · `kel/log.md` 31 · `kel/verification.md` 28 · `glossary.md` 7 ·
  `system-thesis.md` 6 · `iel/reconciliation.md` 14 · `federation/bootstrap.md` 2 · `README.md` 2. (The KEL
  docs still carry the three-tier / recovery-key / `Ror`/`Rec`/`Rpr` model — the biggest single leg.)
- **Fail-secure revocation** also un-landed: `cred-SEL` still in `event-shape.md` + `policy/documents.md`; the
  landed revocation model predates `kills[]`.

## The canon delta to propagate (what's new since the landed docs)

1. **First-seen + two-tier collapse (2026-07-08).** KEL = 5 kinds / 2 tiers; drop the recovery key + `Ror`/`Rec`
   + `t_recover` + T3 + `recoveryKey`/`recoveryHash`. **No repair event** — drop `Rpr`, the `fork` role, the
   archival-tail / root-condemnation machinery. Recovery = a **plain `Rot`** (root-bury + deadness-descends);
   divergence = **forked (≤1 sealed) vs disputed (≥2 sealed)**; eviction = an **`Evl` with a roster `cut`**.
   [inv 11/13, area-kel, area-iel §4, area-sel §4]
2. **Fail-secure revocation/rescission (2026-07-09/10).** `kills[] = [{target, bound?}]` on the issuer's
   **witnessed** IEL `Rev`/`Dth`; `target = hash('{topic}:{owner}:{data}')` (per-kind topic). **Two reads** —
   fail-secure walk (default) / fail-open content-addressed lookup (opt-out). **Issuance SEL dropped → a cred
   is a direct-anchored SAD.** **Custody rule:** direct-anchor an immutable *presented* SAD; SEL-wrap anything
   *mutable* or *looked-up-by-address*. [inv 8/10/15/16, area-sel §1, document-policy §F]
3. **The layering principle.** The IEL/SEL validate **structure only** (kinds, not topic-labels); a chain
   **never returns invalid because of the application it serves**. **R1** — the revocation floor is the
   **earliest** issuance anchor, a re-anchor is inert (cred feature layer). **R2** — the cred walk enforces
   topic↔kind. **R6** — `vdtid` is a **structural store, not a revocation authority** (no revocation walk at
   `vdtid`; the check is the consumer's). [inv 5/10, area-iel §1, area-sel §1, vdtid-services §1d]
4. **SS-3 KEL key-state = single-stream pre-rotation (KERI-style).** The reserve committed at each epoch is
   revealed to sign the next rotation and becomes that epoch's signing key. [area-kel:39-52]
5. **SS-1 / SS-2 = pinned cross-node protocol constants.** `select(prefix, serial, roster, signers)` bytes
   (SS-1) and the effective-SAID synthetic bytes (SS-2) must be byte-identical across conforming impls (vdti =
   a Rust reference lib; the ecosystem is deliberately multi-impl). [federation §1e, impl-notes, vdtid §1e]
6. **No direct mode.** Every chain is federation-witnessed from birth; a user `Icp` must carry
   `{federation, federationPin}`. [federation §1d]
7. **SAD-layer fixes.** inv-16 custody = `{owner, topic, readPolicy}` via a SEL anchor (drop the self-asserted
   `pin`); the SAID-invariance correction (`said.md`/`compaction.md` §Rule 1 — one **canonical fully-compacted
   SAID**, re-derivable); the by-SAID `kind` filter (§1j). [inv 16, project_vdti_said_form_dependent]

## Per-building-block plan (build order = PR order)

Build-order dependency (roadmap): `sad → event-shape → kel/iel/sel → policy/documents → federation → services
→ features`. `event-shape.md` is the **lynchpin** (every chain primitive shares it).

### Shared / foundational — reconciled in the CURRENT PR (with the KEL primitive)
`event-shape.md` and the other landed foundational docs are reconciled **now**, in the current PR alongside the
new KEL primitive — so by the time IEL/SEL are written, `event-shape` is already current and those PRs build on
it. (Jason 2026-07-10: "everything that is landed needs to be reconciled, so when we do IEL/SEL event shape will
be done.")
- **`event-shape.md`** (673L, 55 stale) — drop `Ror`/`Rec`/`recoveryKey`/`recoveryHash`/`Rpr`/`fork`; two-tier
  key-state (SS-3); seal-cap satisfiers `{Rot, Wit}`; `kills[]` role on `Rev`/`Dth`; the anchor matrix
  kind-strict; cred = anchored SAD. Src: area-kel §5, area-iel §5, inv 4.
- **`glossary.md`** (172L, 7 stale) — two tiers, no recovery key, first-seen, forked/disputed, `kills[]`,
  fail-secure. **`system-thesis.md`** (263L, 6 stale) — first-seen + two-tier orientation.
  **`protocol-doctrine.md`** (1321L, 53 stale) — the big narrative: first-seen, two-tier, fail-secure
  revocation, layering. (Already partly uses "first-seen".)
- **SAD layer** `primitives/data/sad/` — `custody.md` (209): inv-16 `{owner, topic, readPolicy}` + SEL anchor,
  drop self-asserted pin, custody rule, v1(`Pin`) anchored not `Icp`. `said.md` (201) + `compaction.md` (162):
  the SAID-invariance fix (§Rule 1). `sad.md` (109) + `availability.md` (89): the custody wrapper shape. Src:
  inv 16, multi-party §8 backport, project_vdti_said_form_dependent.

### KEL primitive — `primitives/data/event-logs/kel/` (6 docs exist, heavily stale) — CURRENT PR
- `events.md` (74) · `log.md` (31) · `merge.md` (50) · `reconciliation.md` (78) · `recovery.md` (65) ·
  `verification.md` (28). Reconcile to first-seen: **5 kinds / 2 tiers** (SS-3 single-stream pre-rotation),
  no recovery key, no `Rpr`; **recovery = a plain `Rot`** (root-bury + deadness-descends); first-seen decline;
  **forked vs disputed** by sealed-branch count; `SiblingLocked`; seal-cap satisfiers `{Rot, Wit}`. Src:
  area-kel.

### IEL primitive — `primitives/data/event-logs/iel/` (only 2 stubs: `delegation.md` 32L, `reconciliation.md` 53L)
- **Write fresh:** `log.md` / `events.md` / `merge.md` / `reconciliation.md` / `verification.md`.
  `events.md` carries: `Rev`/`Dth` sealed kill-anchors + `kills[]`; the `Wit` kind (facet-specific field-match);
  the `Fcp` marker; `Evl` = roster/threshold + `cut` eviction; `Ath` + the `Ath ↔ Gnt` pair; the **layering
  lead** (structure-only, kinds-vs-topic-labels); 8 kinds. Flesh out the `delegation.md` stub (lookup-SEL
  rescission model) and the `reconciliation.md` stub (first-seen). **Operations note** (F7: designated
  governance submitter, hold-governance-under-split, content-rail serialization). Src: area-iel §5,
  area-delegation.

### SEL primitive — `primitives/data/event-logs/sel/` (does not exist — write fresh)
- **Write fresh** from area-sel: **5 kinds** `Icp`/`Ixn`/`Pin`/`Gnt`/`Trm`; **cred = anchored SAD** (no
  cred-SEL); lookup SEL `{Icp, Trm}` (revocation/rescission); fail-secure `kills[]`; anchor-monotonicity +
  cross-layer deadness-descends (the IEL is the SEL's clock). Src: area-sel §5.

### Policy / document layer — `primitives/policy/` (3 docs exist)
- `policy.md` (165) · `documents.md` (131, cred-SEL hit) · `evaluation.md` (124). Reconcile: the **gate
  evaluator dissolves** (`evaluate_gate_policy`); leaf set `id`/`del`/`pol` + `thr`/`wgt`/`and` (`dev`/`grp`
  already gone); the **two-function model** (`evaluate_as_issued` / `evaluate_current`, one composer + two
  resolvers); **cred = anchored SAD**; **revocation = fail-secure `kills[]`** (+ fail-open opt-out); **R6**
  (vdtid ≠ revocation authority). **Creds live here** (`documents.md`). Src: document-policy, delegation.
- **Carries SS-4** (import the policy-DSL composer mechanics from the archived DSL canon) and **C-1** (the
  worked earliest-floor R1 counter-example).

### Federation — `federation/` (`bootstrap.md` 52L stub; no `witnessing.md`)
- `bootstrap.md` — genesis `Fcp → Rot`, config-pinned trust root, **no direct mode**. **Write `witnessing.md`
  fresh:** as-of-context witnessing, majority floor + one-content-sibling, the federation clock (365-day
  auto-expiry, staleness), the receipt shape (§1g), no direct mode. Src: federation §5.
- **Carries SS-1** (pin the `select(prefix, serial, roster, signers)` bytes byte-exactly).

### Services / architecture — does not exist (write fresh)
- **Write** the `lib/vdti` + `vdtid` + `witnessd` boundary doc: the effective-SAID/transfer-engine spine,
  deferred-deps, anti-entropy, **R6** (structural store, no revocation walk), the by-SAID `kind` filter (§1j).
  Src: vdtid-services §5. Also fix the `project_vdti_compacted_only_submission` memory (`eventsd`/`sadd` →
  `vdtid`/`witnessd`).
- **Carries SS-2** (pin the effective-SAID synthetic bytes byte-exactly).

### Features — `features/multi-party/documents.md` (51L stub)
- **Write fresh** (greenfield, credentials as the *contrast*): the version DAG, creator-governed per-period
  access list, `Gnt`←`Ath` grants + `Dth` rescissions, the honored predicate, doc-member rescission `bound`
  gated. Backport: `custody.md`'s "SEL inception anchored" → "v1 (`Pin`) anchored". Src: multi-party §8.

## The 4 encode job-list items (ride into their building blocks)
- **SS-1** → `federation/witnessing.md` — pin the witness-selection algorithm bytes.
- **SS-2** → the services/architecture doc — pin the effective-SAID synthetic bytes.
- **SS-4** → `primitives/policy/documents.md` — import the policy-DSL composer mechanics.
- **C-1** → `primitives/policy/documents.md` (or `sel/`) — a worked counter-example for the cred earliest-anchor
  floor (R1); flooring at *latest* silently un-revokes — the most mis-implementable feature-layer rule.

## Sequence (resolved 2026-07-10)
1. **Current PR** — the new KEL primitive + `event-shape.md` + the landed foundational docs
   (`protocol-doctrine` / `glossary` / `system-thesis` / the SAD layer / `policy`), all reconciled to
   first-seen + fail-secure + layering. Everything already landed gets reconciled here, so the shared lynchpin
   (`event-shape`) is current before the next PRs.
2. **IEL** — write `iel/` fresh (`event-shape` already done).
3. **SEL** — write `sel/` fresh.
4. **Policy / documents** (creds, revocation, SS-4, C-1) · **Federation** (`witnessing.md`, SS-1) ·
   **Services/architecture** (SS-2) · **Features/multi-party** — in build order.
