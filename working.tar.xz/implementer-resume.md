# implementer-resume

**My bootstrap.** I am the **implementation agent** for vdti docs/code work. Canon (`docs/canon/`) is
authoritative; when a landed doc and canon disagree, **canon wins**. Read this file first on every (re)start.

## Role + standing rules

- **I am the implementer.** Faithful encode of settled design, not new design. If I hit a genuine gap or
  contradiction while encoding, **stop and flag it** — don't resolve it myself.
- **Read the actual current files before editing** — never work from recall.
- **Greenfield voice** for design docs: state THE current model, no transition language (previously /
  formerly / dropped / renamed / reshape / "there is no X"); **no jargon** (strip review codes like
  `cold-8 F3`, `inv 12`→"invariant 12", bare vars like `M ≤ 1`→"one or fewer"); **human-readable slug
  refs** (`[§Section name](…)`, not bare anchors/issue numbers). The landed KEL docs
  (`docs/design/primitives/data/event-logs/kel/*.md`) are the voice exemplar.
- **`make all` green is the done-gate** at every stop (lint-terminology + check-doc-xrefs + prettier
  fmt-md-check). Use `make` targets, never direct script/prettier invocation. Run `make fmt-md` before
  the gate. `docs/canon/` is **prettier-exempt** (don't expect reflow); design docs are not.
- **git-add any new/renamed file before trusting `make all`** — the doc-lint only checks git-tracked files.
- **Git is Jason's.** I stop at clean boundaries; he commits. I never run git (use `rm` for deletions).
- **Do not launch reviews.** Jason drives the dual-pass review; findings come to me as briefs in `.working/`.
- `.working/` is gitignored + prettier-exempt.
- **perl -i is byte-safe for ASCII-only substitutions** (multibyte em-dashes/arrows pass through untouched);
  for multibyte *content* edits use the Edit/Write tool (perl mojibakes without `use utf8;`). Always
  grep-check for mojibake after a perl pass on canon.

## Current state — VDTI-16 (IEL primitive docs), branch `VDTI-16_iel-primitive`

**Done, `make all` green, awaiting Jason's commit/next brief.** Five IEL docs written fresh under
`docs/design/primitives/data/event-logs/iel/` (`log`, `events`, `merge`, `reconciliation`,
`verification`), encoding `docs/canon/vdti-area-iel.md` against the KEL template. `delegation.md`
(landed stub) cross-referenced, not rewritten. Then, in sequence, these briefs were folded (all landed):

1. **Greenfield/voice fixes** — dropped bare `M`/`M ≤ 1` verdict shorthand and `(Rule A)` labels.
2. **Review fold (F1–F7 + N1–N2)** — F1: `Evl` carries no `anchors[]` (it's a `roster`-carrier only;
   fixed across iel + `event-shape.md`); F3: split the overloaded "majority floor" (→ "position gate" for
   content-fork prevention); F2/F4/F5/F6/F7/N1/N2 minor. (Detail:
   `.working/vdti-16-iel-review-{cold,warm}-findings.md`, `vdti-16-iel-fold-brief.md`.)
3. **F-2 narrow** — `iel/log.md` burying-seal claim now splits: non-terminal governance seal → Active, a
   `Trm` → Terminated (matches `reconciliation.md`).
4. **Floor terminology rename** (`.working/vdti-floor-terminology-brief.md`) — cross-primitive, design +
   canon: **"majority floor" is banned**; split into **witnessing floor** (`threshold > signers/2`, over
   witness signers — content-fork prevention, KEL+IEL) and **authorization floor**
   (`t_govern`/`t_authorize > |roster|/2`, over roster members — IEL only, `t_use` exempt). **position
   gate** kept (the IEL applying the witnessing floor at its own `(prefix, serial)`). Distinct again from
   the pre-existing **roster-floor `|roster| ≥ 1`** and **security floor `≥ 2`**. Ban added to BOTH
   `.terminology-forbidden` files; distinction note added to `vdti-area-iel.md`. `grep -rn "majority
   floor" docs/` → empty.

**Two incidental fixes during the floor rename (Jason-directed):**

- **`docs/canon/.terminology-forbidden` had 71 mangled `\b` bytes** — literal `\b` word boundaries were
  stored as raw backspace (0x08), making those canon bans **dead** (0x08 matched a literal backspace,
  never the token). Fixed with `perl -i -pe 's/\x08/\\b/g'`. If canon bans look dead again, check for 0x08.
- **Latent `grp(` bug** — reactivating the bans caught `\bgrp\(` firing on a legitimate history quote in
  `vdti-keri-acdc-comparison.md` ("the reshape dropped foreign-`grp`"). The canon forbidden file is by
  design "the parent MINUS patterns the canon quotes as history," so the fix was to **drop `\bgrp\(`** from
  the canon ban list (with a comment) — not reword the canon's historical record. `\bdev\(` stays (not quoted).

**Earlier:** phase-2 `docs/design/` ← canon reconciliation is COMPLETE and MERGED (first-seen + two-tier +
four-state + fail-secure revocation + layering + verdict-recoupled effective-SAID synthetic).

## Not in this pass (LATER PRs), written fresh

SEL primitive docs (`sel/`), `federation/`, `features/`, `operations/`, `infrastructure/`. Their
forward-references are the acceptable ~46 forward-refs in the lint output. The IEL docs forward-ref an
`operations/governance-workflow.md` (governance-serialization playbook) — filename is provisional, easy to
change in 3 refs + the `.docs-xref-ignore` glob if a different name is chosen.

## Awaiting next assignment

No active task. On resume: re-read the canon, then take direction from Jason (briefs land in `.working/`).
Keep `make all` green.
