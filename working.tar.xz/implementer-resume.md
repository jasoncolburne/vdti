# implementer-resume — phase-2 `docs/design/` ← canon reconciliation

**My bootstrap.** I am the **implementation agent** for the phase-2 reconciliation: bringing the landed
`docs/design/` docs into alignment with the ship-reviewed `docs/canon/`. This is a **faithful encode of settled
design, not new design** — the canon is authoritative and whole-canon reviewed. Read this file first on every
(re)start.

## (a) Role + rules

- **I am the implementer.** Canon is authoritative; when a landed doc and canon disagree, **canon wins** (the
  landed docs lag; I close the lag).
- **Read the WHOLE canon before working** — the design is interlocking; editing from a slice produces
  self-inflicted contradictions (this bit the design agent repeatedly).
- **Greenfield voice** — the landed docs state the **current** model only. No "previously X" / "used to be" /
  "the old model" / migration language. Canon keeps the decision history; the landed docs don't.
- **Greenfield-voice for design docs specifically (Jason's standing rule):** no jargon, human-readable
  slug-style references, state THE model.
- **`make all` 0 is the done-gate** at every stop (lint-terminology + check-doc-xrefs + prettier fmt-md-check).
- **git-add any new/renamed file before trusting `make all`** — the doc-lint only checks git-tracked files.
- **Git is Jason's.** I stop at clean boundaries; he assesses compaction + commits. I never run git.
- **Do not launch reviews.** Jason drives the dual-pass review.
- `.working/` is gitignored + prettier-exempt; `make fmt-md` targets the human-read `docs/` + root markdown
  (100 cols).

## (b) Read-order (every start / after any compaction)

1. **The entire canon** — `docs/canon/vdti-invariants.md` + every `docs/canon/vdti-area-*.md` + the federation
   reference + implementation-notes + `supplemental/*`, in full.
2. **`.working/vdti-reconciliation-map.md`** — the scope (per-file canon delta, PR grouping, 4 encode items).
3. **`.working/vdti-reconcile-encode-brief.md`** — the process.
4. **This resume.**
5. **The actual target file on disk** before each edit.
6. On compaction: RE-READ 1–4, re-grep disk for stale tokens
   (`Ror|Rec|recovery key|three-tier|Rpr|t_recover|recoveryKey|recoveryHash|cred-SEL|T3`), continue from the
   first unchecked tracker item.

## The canon delta to propagate (from the map)

1. **First-seen + two-tier collapse.** KEL = 5 kinds / 2 tiers. Drop recovery key + `Ror`/`Rec`/`t_recover`/`T3`/
   `recoveryKey`/`recoveryHash`/"three-tier"; drop `Rpr` + the `fork` role + archival/repair machinery. Recovery
   = a plain `Rot` (root-bury + deadness-descends). Divergence = **forked (≤1 sealed) vs disputed (≥2 sealed)**.
   Eviction = an `Evl` with a roster `cut`. SS-3: KEL key-state = single-stream pre-rotation. Seal-cap
   satisfiers `{Rot, Wit}`.
2. **Fail-secure revocation.** `kills[] = [{target, bound?}]` on the issuer's witnessed IEL `Rev`/`Dth`;
   `target = hash('{topic}:{owner}:{data}')` (per-kind topic). A **credential is a direct-anchored SAD** (no
   cred-SEL; issuance commitment `hash('{CRED_ISSUANCE_TOPIC}:{issuer}:{cred.said}')`). Two reads (fail-secure
   walk = default / fail-open content-addressed lookup = opt-out). **Custody rule:** direct-anchor an immutable
   *presented* SAD; SEL-wrap anything *mutable* or *looked-up-by-address*.
3. **Layering principle.** The chain validates **structure only** (kinds, not topic-labels); never returns
   invalid because of the application it serves. R1 (revocation floor = earliest issuance anchor; re-anchor
   inert). R2 (cred walk enforces topic↔kind). R6 (`vdtid` = structural store, not a revocation authority).
4. **No direct mode.** Every chain federation-witnessed from birth; a user `Icp` must carry
   `{federation, federationPin}`.
5. **SAD layer.** inv-16 custody `{owner, topic, readPolicy}` via a SEL anchor — drop the self-asserted `pin`.
   SAID-invariance fix (`said.md`/`compaction.md` §Rule 1: one canonical fully-compacted SAID, re-derivable).
   custody backport ("SEL inception anchored" → "v1 (`Pin`) anchored, `Icp` rides `v1.previous`"). by-SAID
   `kind` filter. SS-4 (policy-DSL composer) → `policy/documents.md`. C-1 (worked earliest-floor R1
   counter-example) → policy or sel. SS-3 → `area-kel:39-52`.

## (c) Progress tracker — AUTHORITATIVE, update after every file

**Current PR (chunk 1 of the map's sequence): the new KEL primitive + `event-shape.md` + the landed
foundational docs, all reconciled to first-seen + fail-secure + layering.** (IEL/SEL/services/features are
write-fresh in LATER PRs — not this pass; but `event-shape.md` reconciles ALL its sections now per Jason.)

| Chunk | Files | Status |
|---|---|---|
| 1a | `event-shape.md` (55 stale), `glossary.md` (7 stale) | **DONE** — full rewrite of both; two-tier, first-seen burial, fail-secure `kills[]`, cred=anchored SAD, no direct mode, privileged→sealed. 7 mermaids re-rendered clean. terminology+prettier green. |
| 1b | `kel/{events,log,merge,reconciliation,recovery,verification}.md` (biggest leg) | **DONE** — all six full-rewritten to first-seen + the **four-state model** + concise proof format (below). Recovery = burying `Rot`; sealed not privileged; no `Rec`/`Ror`/`fork`-role/dual-sig/three-tier/recovery-key. glossary states-entry updated to four-state. terminology PASS, prettier clean. Only xref red = the `#divergence-and-recovery` forward-anchor (1c owns it). |
| 1c | `protocol-doctrine.md`, `system-thesis.md` | **DONE** — full first-seen reconcile of both narrative docs: two-tier (drop `Ror`/`Rec`/`Rpr`/`Fld`/recovery-key/recovery-reserve/three-tier/`t_recover`/dual-sig), four-state (Active/Forked/Disputed/Terminated), §Divergence-and-repair → **§Divergence-and-recovery** (full rewrite — recovery = a burying seal-advancer, burial by position+descent, no `fork` role/root-condemnation, eviction = `cut` `Evl`, `{Rot,Rot}` reserve-compromise proof), §Tiers→2-tier, threshold-vector drops `t_recover`, §Negative-checks→fail-secure-default kills[] walk + fail-open lookup opt-out (heading/anchor kept), cred=direct-anchored-SAD, §Effective-SAID→verdict-recoupled **synthetic** (reverses the real-digest-over-live-tips model), no direct mode, `signers>=3` (drop lone-witness carve-out), federation `|roster|>=4`. Heading rename **created** `#divergence-and-recovery` — cleared all danglers; also propagated the rename into `iel/reconciliation.md:6` (mechanical). **`make all` = 0** (523 OK / 0 err / 31 acceptable forward-refs; prettier clean; terminology PASS). Mermaid: 3 fences well-formed (blank-line-before + no paren-in-edge-label); mmdc not on PATH so not render-validated (label-only edits). |
| 1d | SAD layer: `sad/{custody,said,compaction,sad,availability}.md` | **DONE** — SAD files were already largely first-seen-clean (no `Ror`/`Rpr`/three-tier/privileged). Reconciled: custody `topic` namespaces → per-kind (`CRED_REVOCATION_TOPIC`/`DLG_RSC_TOPIC`/`DOC_RSC_TOPIC`); the **custody rule** (direct-anchor an immutable *presented* SAD; SEL-wrap *mutable*/*looked-up-by-address*) with **cred = direct-anchored SAD** (no `custody{owner,topic}`; SEL-anchor path is for looked-up docs) — replaces the stale "credential pattern generalized" framing + the "cred's SEL" ref; `sad.md` "credential SEL inception's data" → "lookup SEL"; **by-SAID `kind` filter** added to `sad.md §Structural shapes` (events never fetchable by SAID from the store — inv 16 correlation defense); `compaction.md` cred-anchor "issuer's anchor in a KEL" → "issuance-commitment anchor on its IEL". **SAID-invariance framing fixed** (Jason confirmed 2026-07-10 "canonical = fully-compacted, re-derived by compacting"): `said.md` §Canonical-form intro + Rule 1, `compaction.md` §SAID-preservation intro/opening/Rule-1-bullet, `sad.md §Composition-by-reference` — all restated to **the SAID is defined over the fully-compacted canonical form, re-derived from any wire form by compacting down; SAIDs are form-dependent** (kept the Rule-2 verify-each-child mechanism). custody `{owner,topic,readPolicy}` + self-asserted-pin-drop + v1-anchored backport were **already present** (verified). **`make all` = 0** (524 OK / 0 err / 32 fwd-refs; prettier clean; terminology PASS). |
| 1e | `policy/{policy,documents,evaluation}.md` (+ SS-4, C-1) | **DONE** — policy docs were already largely reconciled (`dev`/`grp` dropped; the composer mechanics = **SS-4** already present in `policy.md §Composition rules` — distinct-by-prefix, per-identity-max weight, `and`-over-disjoint, fail-secure-on-unknown, verifier-wide budget). Fixes: `documents.md §anchoring-position` — **cred = direct-anchored SAD** (issuance commitment `hash('{CRED_ISSUANCE_TOPIC}:{issuer}:{cred.said}')`, not a cred-SEL Pin); **C-1 added** (earliest-floor R1: under multiple anchors of one issuance commitment the **earliest** is the floor, later re-anchor **inert** — worked tier-inversion counter-example: a T1 `Ixn` re-anchor after a T2 `Rev` would un-revoke); the checked-not-trusted serial-1 `Pin` re-scoped to the **looked-up / attestation-SEL** case (custody mechanism). `policy.md` `del(X,N)` rescission → **fail-secure kills[] match by default + fail-open lookup opt-out** (was fail-open-only "present→rescinded/absent→live"); `documents.md §Delegation` rescission phrasing made consistent. `evaluation.md` "pending its repair" → "pending its burying seal-advancer". **`make all` = 0** (527 OK / 0 err / 31 fwd-refs; prettier clean; terminology PASS). |
| 1f | `docs/design/`-scoped `.terminology-forbidden` hardening + final `make all` | **DONE** — added a first-seen ban block to `docs/.terminology-forbidden` (`\bRor\b`/`\bRec\b`/`\bRpr\b`/`\bFld\b`/`\bt_recover\b`/`\brecoveryKey\b`/`\brecoveryHash\b`/`three-tier`/`\bT3\b`/`\bprivileged\b`/`\bSiblingLocked\b`/`\bKelTerminated\b`), docs/-scoped only (NOT root — `.working/` catalogues quote old vocab; canon exempt via its own deeper file). **Un-banned `forked:` / `disputed:`** at docs/ scope (phase-2 landed the verdict-recoupled synthetic in design). Updated stale comments (Rec-now-forbidden; SiblingLocked→Sealed; ParentLocked block). **Landed-doc fold-ins to clear the bans:** removed the superseded `iel/reconciliation.md` (dead Ror/Rec/Rpr repair-cascade diagram-home — Jason: "if superseded just remove"; had no inbound refs; `iel/delegation.md` keeps the dir alive); `federation/bootstrap.md` tier-3/`T3↔T3` → tier-2/`T2↔T2` (genesis diagrams current, only the Wit tier label was wrong); `README.md` index scrubbed (three-tier→two, three-state→four, divergence-and-repair→recovery, archival-tail/`SiblingLocked`→burial+outcomes, `Rec`-vs-`Ror`→burying-`Rot`). **`make all` = 0** (46 files / 525 OK / 0 err / 31 fwd-refs into deferred IEL/SEL/federation/features docs; prettier clean; terminology PASS with new bans). |

Chunk order (suggested, use judgment): 1a → 1b → 1c → 1d → 1e → 1f. Each chunk is a coherent commit point.

## ✅ PHASE 2 COMPLETE (2026-07-10) — all six chunks (1a–1f) DONE, `make all` = 0 at the final boundary.

The landed `docs/design/` docs are reconciled to the ship-reviewed canon: first-seen + two-tier + four-state
(Active/Forked/Disputed/Terminated) + single-word merge outcomes (Sealed/Terminal/Invalid/Ignored) +
fail-secure revocation (kills[] default, fail-open opt-out) + cred=direct-anchored-SAD + the layering principle +
no direct mode + the verdict-recoupled effective-SAID synthetic + the SAID form-dependent/fully-compacted-canonical
framing. The designer landed the matching canon four-state + merge-outcome changes (consistent). Terminology
hardened against dead-model regression.

**⚠ REVIEW FIXES MAY FOLLOW (Jason 2026-07-10: "we may need to make some fixes after review").** On resume:
re-read this tracker, then address whatever the dual-pass review surfaces. Keep `make all` 0. The deferred
LATER-PR docs (IEL/SEL primitives, federation/, features/, services/) are out of THIS pass — their forward-refs
are the acceptable 31.

**Cross-chunk anchor policy (Jason 2026-07-10):** xref anchors into not-yet-reconciled targets may dangle at
intermediate boundaries — `make all` can be red between chunks; Jason commits locally and does not push, so CI
never sees it. Aim `make all` **0 at the final boundary (1f)**; keep terminology + prettier green at every stop.
**As of 1c end, `make all` is already 0** (the `#divergence-and-recovery` anchor is created and all danglers from
1a/1b cleared; remaining 31 are acceptable forward-refs into not-yet-created `federation/`, `iel/`, `policy/`
targets, which the lint reports as forward-refs, not errors).

## (d) Stop-point protocol

At each chunk boundary — **STOP**: leave the tree green (`make all` 0), update this resume's tracker, report
what's done + what's next in one clear summary, and hand back to Jason (he assesses compaction + commits). Do
not run git.

## Chunk-1b model decision (Jason 2026-07-10) — the FOUR-state proof format

The KEL docs (esp. `reconciliation.md` + `merge.md`) adopt the model in **stash@{0}** (`git show
stash@{0}:...` — WIP based on eebea0b, format-good but dead-model content). Apply its **format +
four-state model**, re-encoded to **first-seen content**:

- **Four derived per-node states:** Active / Forked / Disputed / Terminated. Each **computed by a
  data-local walk**, never a stored flag. **Forked** = a live fork, ≤ 1 sealed branch past it
  (recoverable). **Disputed** = ≥ 2 sealed branches (terminal → reincept). The walk that tells them
  apart *is* how the state is computed — not a "reading" on one Divergent state.
- **Single-word outcome vocabulary**, enumerated in two small tables above the matrices:
  - **Transitions** (name the resulting state): `Extended` (→ Active), `Recovered` (a burying
    seal-advancer resolved a fork → Active), `Terminated` (a `Trm` → Terminated), `Forked`,
    `Disputed`.
  - **Rejections** (nothing lands): `Sealed` (inert below-seal parent — the *inert* case ONLY),
    `Terminal` (chains from a `Trm`), `Invalid` (structurally inapplicable), `Ignored` (a well-formed
    event the witnesses decline — content-fork prevention, or a new event on a Disputed/Terminated
    chain). **A fork-FORMING below-seal-serial event is a `Forked`/`Disputed` transition, not
    `Sealed`** — `Sealed` is inert-only (the stash split the old flat SiblingLocked).
- **Proof format:** Matrix 1 (local submissions) split by **attach-position** for an Active chain
  (extends-the-tip / adjacent-to-the-seal / on-the-run-past-the-seal), tiny per-position tables, each
  row a kind → one-word outcome. Concise tables throughout. This is the "readable, clear" ask.
- **First-seen re-encode of the stash's dead content:** recovery = a **burying `Rot`** (there is NO
  `Rec`/`Ror`); a sealed event that buries competing content → `Recovered`; **position-3 (a sealed
  event competing with content) → `Recovered`** in first-seen (the burying Rot buries the run) — the
  stash said `Forked` because its dead model needed a separate `Rec`. `privileged` → `sealed`; no
  `fork` role / discriminator / dual-sig / three-tier / recovery-key.
- Outcome NAME rename (Sealed/Terminal/Invalid vs canon's SiblingLocked/KelTerminated/Rejected) + the
  four-state framing are **CANON DELTAS** — see the flag below. Use the stash vocabulary in the six
  KEL docs for internal consistency; canon follows after this task.

**Ripple:** `glossary.md` (chunk 1a, already committed) used three-state + readings — its "Readings
and states" entry needs the four-state update too; fold it into 1b.

## CANON DELTAS — **RESOLVED by the designer** (Jason 2026-07-10: "the designer finished the four state/merge outcome changes")

The canon now carries the four-state model + the single-word merge-outcome names, matching my `docs/design/`
encode — the two are consistent, nothing owed here. Kept for historical context (what the deltas were):

1. **Three → four per-node states.** `area-kel` §1 ("Three-state per-node machine: Active / Divergent
   / Terminated ... no fourth per-node state") + `area-vdtid-services` §1e ("Per-node state stays
   {Active, Divergent, Terminated}; disputed is the data-local terminal reading") should follow to
   the four-state framing (Active / Forked / Disputed / Terminated, all data-local-derived).
2. **Merge-outcome names.** Canon uses `SiblingLocked` (area-kel:107) / `KelTerminated` / `Rejected`;
   the design now uses `Sealed` / `Terminal` / `Invalid` + `Ignored`, with `Sealed` split from the
   fork-forming case. Reconcile canon to match (or decide the reverse) at the canon pass.

## Open flags to raise

- **Chunk 1f terminology scoping (flag before doing it).** "deeper replaces shallower": creating a literal
  `docs/design/.terminology-forbidden` would REPLACE `docs/.terminology-forbidden` for the design subtree,
  requiring the whole root+docs ruleset to be copied in (error-prone). The existing `docs/.terminology-forbidden`
  ALREADY scopes docs/design (canon is exempt via its own deeper file), so **adding the first-seen bans there**
  is simpler and correct. Recommend that over a new nested file — confirm with Jason at 1f.

## Diagrams

Several landed docs carry inline `mermaid` (old excalidraw examples). Any showing the dead model (recovery key,
`Ror`/`Rec`, three tiers, a `fork` role) needs updating. Follow `project_vdti_excalidraw_to_mermaid`: a **blank
line before ` ```mermaid `** (else prettier flattens the fence → doc-lint cascade), **no `()` in edge labels**,
terse `layer: Kind` labels, validate with `mermaid-cli`.
