# vdti `.working/` — current surface index

**Fresh session: read these to get current. Everything in `archived/` is historical — do NOT treat it as
canonical (it predates current decisions and _will_ mislead you, including making confident wrong claims).**

## ★★ CURRENT — IEL primitive + sealing rename + holistic-3 refactor pass FOLDED (design + canon); `grep-terms` tooling added; round-4 review next

**This session (post-PR#11).** The KEL primitive PR#11 is merged (history below). Since then, the **IEL primitive
went up as the OPEN PR #17** (branch `VDTI-16_iel-primitive`, checks passing — **mid-PR, not merged**): five IEL docs written fresh
(`log`/`events`/`merge`/`reconciliation`/`verification`) + the delegation stub, two dual-pass reviews folded. Plus
three cross-cutting changes, all folded into the same branch (we fix everything in the current context — Jason
commits):

- **Floor terminology (KEL + IEL + canon).** The overloaded "majority floor" split into **witnessing floor**
  (`> signers/2`, content-fork prevention, both primitives) / **authorization floor** (`t_govern`/`t_authorize
  > |roster|/2`, IEL governance) / **position gate** (the IEL applying the witnessing floor at its own position).
  `majority floor` is banned in both `.terminology-forbidden` files; `lint-terminology` is now **wrap-tolerant**
  (`scripts/lint-terminology.sh` pass 2, a perl slurp-match — a multi-word ban that wraps a line no longer slips
  through).
- **KEL `recovery.md` → `compromise.md` re-scope.** Renamed + retitled **"KEL Compromise & Structural Defense."**
  The recovery-mechanics + attach shapes folded into `merge.md`, cross-node races into `reconciliation.md`; the doc
  keeps the compromise model + reserve boundary + pre-seal verifiability + defense-layers. **Burial generalized to
  seal-advancer** (deliberate recovery = a `Rot`, for availability; incidental burial = any seal-advancer; a `Trm`
  buries then terminates). Fresh-eyes "In short" opener added.
- **Trust-tree direction (NEW convention) — COMPLETE across canon + design.** The **root of trust is the base** —
  device keys (KEL) at the bottom; identity (IEL) and data (SEL) compose **up**. Convention: **anchor = up, pin/floor
  = down, verifier resolves down to the KEL, KEL has no chain below it**; layer-stack diagrams `flowchart BT` (base on
  the left when horizontal). The exhaustive sweep ran across **both** surfaces — the canon's own `inv 4`
  (`Manifest-down + pin-up`) was the **seed** and was flipped too, so a canon-reasoning LLM can't re-seed it. The
  chain-position `at-or-below-seal` axis and the **delegation-graph** "walk up to the root delegator" are separate
  axes, kept.

**`make all` GREEN** (683 OK, 0 errors, prettier clean; 46 sanctioned forward-refs).

**Holistic dual-pass ROUND 1 FOLDED + archived (2026-07-10).** Cold **HOLD-2** + warm **HOLD-1**, all resolved — the
one real finding was the **half-applied trust-tree inversion** (above), fixed across canon + design; F2s folded too.
`make all` green (683 OK, 0 errors, prettier clean). Round-1 briefs + findings → `archived/`.

**Holistic dual-pass ROUND 2 FOLDED (2026-07-10).** Cold **HOLD-5** + warm **HOLD-1** — all findings folded
(`vdti-holistic-review-2-{cold,warm}-findings.md` §RESOLVED): the trust-tree regression driven to **zero** (the
bolded `floors/pins up` survivors), the KEL merge Forked-routing aligned to Matrix 4 (F3), the glossary added to the
reading order, "seal" glossed at first use, and the dense-doctrine sentences split. `make all` green (685 OK, 0
errors); every touched diagram `mmdc`-validated (exit 0).

**Post-round-2 keep-current polish (2026-07-11).**

- **`features/multi-party/documents.md` version-DAG diagram** — settled on `flowchart BT` with **"ancestor of"**
  lineage arrows (V0 base → vM top; docs above their SELs) + an explanatory **note**: literal `ancestors`
  (child→parent) arrows AND that build-up layout are inexpressible in one mermaid flowchart (arrow direction _is_
  the layout rank; only Graphviz `constraint=false` decouples them, which would clash with every other diagram).
  The note records it so the one non-linkage-faithful arrow is explained, not silent. `mmdc` renders confirmed by eye.
- **IEL keep-current** — the IEL docs are on the branch now, so stale "(forthcoming)" markers dropped (`protocol-doctrine`,
  `event-shape`); joint "SEL / IEL" refs re-attributed to the SEL side (SEL still forthcoming). **README completed:**
  IEL added to the reading order (items 15–20, incl. the delegation stub), dropped from the forthcoming list.
- **"landed" build-status vocabulary removed** surface-wide (README → "design surface"; `## Not yet landed` →
  `## Forthcoming` + TOC anchor; `event-shape`/`evaluation` drop "landed separately") — greenfield voice; the
  design-vocabulary "an event landed cleanly" stays (it names the model, not the doc build).
- **PR#17 body pushed to gh** with the trust-tree + `compromise.md` re-scope sections added.

**`make all` GREEN (691 OK, 0 errors, prettier clean; 46 forward-refs).**

**Governance → sealed/sealing rename FOLDED + committed (`4f6a1f7`, 2026-07-11).** The IEL threshold
vector prices two seal-advancing tiers (`t_govern` / `t_authorize`), so calling the whole seal-advancing
spine "governance" conflated the umbrella with the `t_govern` slot. The split: **`sealed`** =
state/spine/category/fork; **`sealing`** = event/kind/act/decision; **`seal`** = the marker;
**`governance`** reserved for the narrow roster/authority acts (`Evl` + federation `Wit`) — kills
(`Rev`/`Dth`) and terminal (`Trm`) are their own categories, `t_govern`-priced but not "governance".
Federation "pure case" → **always-sealed**. KEL general-burial broadened to `Rot`/`Wit`/`Trm`; the
"recovery is a plain `Rot`" doctrine kept. Two dual-pass reviews folded (a glossary **bridge** entry
defines the narrow `governance`). ~17 files.

**Term-search tooling — `scripts/grep-terms.pl` (2026-07-11).** Decoration- + wrap- + word-initial-case-
tolerant phrase search — usable directly for straggler sweeps AND wired into `lint-terminology.sh`
pass 2 (multi-word bans now catch `majority **floor**` / bold-hidden / sentence-cap forms). Reference
memory: `reference_grep_terms_tool.md`. Use it, not plain grep, on terminology sweeps.

**Holistic dual-pass ROUND 3 FOLDED — readability + consistency + refactor/pointers (2026-07-11).**
Cold + warm findings folded (`archived/vdti-holistic-review-3-*`, §Fold-outcome). Headline: the
governance-glossary self-contradiction fixed (aligned to the corpus). The **de-duplication** ask
landed — prefix/SAID algorithm, threshold-vector bounds, synthetic-vs-digest rationale, and the
divergence/spine model each now have **one owner** (`said.md` / `iel/events` / `protocol-doctrine`),
the re-describers collapsed to a gloss + pointer; a `protocol-doctrine` orienting box (kinds/fields
legend, in lieu of a reading-order reorder); the `iel/log:15` direction inversion + a grep-missed
straggler (`kel/log:11` "anchor in" → "root in") fixed. `make all` green (**703 OK**, 0 errors,
prettier clean).

**NEXT = Jason reviews + commits; then a **ROUND-4** dual-pass holistic — **first-time-reader**
perspective, focused on **[soundness, readability (greenfield / no-jargon / human-slug-refs)]**.
Briefs being written now (`vdti-holistic-review-4-{warm,cold}-brief.md`). Then the SEL primitive per
`vdti-1-roadmap.md`.**

---

### Historical — PR#11 (KEL primitive) reconciliation (merged 2026-07-10)

**The redesign is landed on both surfaces.** `docs/canon/` (14 files) is COMMITTED + whole-canon SHIP-reviewed
(first-seen + two-tier + fail-secure + layering + SS-3). And now the landed **`docs/design/` docs are reconciled
to it and committed** — the implementer's 6-chunk one-pass: first-seen + two-tier + **four-state** + formalized
single-word merge outcomes + fail-secure revocation + credential = a direct-anchored SAD + no direct mode + the
verdict-recoupled effective-SAID synthetic. The designer's matching **four-state / merge-outcome canon backport**
(area-kel §1 + vdtid §1e) is also done. Spot-checked strong (big residue gone; `privileged`→`sealed` clean;
`policy/documents.md` landed fail-secure + the C-1 counter-example).

**Reconciliation + the 8 folds are COMMITTED** (the first dual-pass returned MERGE/MERGE; folds = stale-tier
`1/2/3`→`1/2` · KEL heading `5 kinds (+ Fcp variant)` · doc-member `Trm` `grant-doc`→`rescind-doc` · `Empty` vs the
four live-chain states · below-seal attach-position note · Matrix 2 "no Disputed source" row-note ·
state/`region()`/`effective_said` correspondence table · `Terminated`/`Terminal`/`Trm` disambiguation; canon fallout
checked — none). **`make all` GREEN** (0 errors, 527 OK; 31 tolerated forward-refs). This session also **rewrote
PR#11's title + body** (branch `VDTI-10_kel-primitive`) to current reality and **merged** the `.working/` KERI
comparison into `docs/canon/supplemental/vdti-keri-acdc-comparison.md`.

**FINAL confirmation dual-pass RETURNED — MERGE / MERGE.** The 5 real findings folded (`make all` green, 529 OK); the
two eye-items resolved — (A) the seal-cap phrasing (Jason 2026-07-10): the **expression** `parent.serial >= seal_serial`
stays (the canonical-extension gate; an `event.serial` swap would misframe it), but invariant 5's **framing** was
imprecise and was **reframed** (inv 5 in reconciliation.md + canon `vdti-area-kel` + the `.terminology-forbidden`
mirror) — refusal-**as-a-canonical-extension** is unconditional, the refused event's **disposition splits**
(strictly-below → `Sealed`/`Disputed`; a sibling at the seal's own serial `v_{seal−1}` is a retained live fork, not a
locked-portion rejection — the cap bounds content extended **from** the seal, not a sibling to it); and (B) the
model-stale **`iel/delegation.md`** stub is **fixed**. `make all` green. Briefs + findings + `pr-11-body.md` →
`archived/`.

**Read on re-entry:** `design-resume.md` (the authoritative Live edge — full current state) → this file →
`docs/canon/` (authoritative). **On resume:** the reconciliation PR (#11, KEL primitive) is **MERGED to `main`**
(2026-07-10). _(The IEL-fresh PR that this pointed to is the still-OPEN PR#17 — see the CURRENT block at the top
for the live state and next steps.)_ Build order after IEL: SEL-fresh → policy → federation → services → features
per `vdti-1-roadmap.md`.

## The `.working/` surface (current)

- **`design-resume.md`** — the design session's bootstrap; read FIRST after a `/clear` or `/compact`. Stable
  role/process framing + the authoritative **Live edge**.
- **`vdti-1-roadmap.md`** — the phase index + build sequencing, synced to **gh#1** (you keep it current + push).
  The forward plan (build order + the pinned SS/C items) lives here; the reconciliation PR's briefs / findings /
  map are consumed → `archived/`.
- **`vdti-adversary-cases.md`** — the attack case-matrix (a coverage input; **may lag the canon — canon wins**).
  _(The per-log event-kind tables and the KERI/ACDC contrast are superseded — by the landed design docs and by
  `docs/canon/supplemental/vdti-keri-acdc-comparison.md` respectively → `archived/`.)_
- **`vdti-holistic-review-2-{cold,warm}-brief.md`** + **`-findings.md`** — round-2 review (soundness / correctness +
  accessibility + readability + trust-tree regression). **FOLDED** (findings carry §RESOLVED). Archive the four on
  `VDTI-16` merge.

## Canonical surfaces (outside `.working/`)

- **`docs/canon/`** (14 files) — the machine-oriented, pressure-tested design canon; **authoritative**. Start at
  `vdti-invariants.md` (load-bearing) + the `vdti-area-*.md` notes; `docs/canon/README.md` orients.
- **`docs/design/`** — the human-facing **landed** design docs; **being reconciled to the canon** (phase-2 — see
  the map). When it and the canon disagree, the canon wins.
- **`../MODEL.md`** — the repo-root plain-english model (greenfield).

## Don't touch

- **`warm-resume.md`** — a review session's bootstrap. Do not edit or move.
- **`implementer-resume.md`** — the implementation agent's own bootstrap + progress tracker (its session). Read it
  on resume for the tracker; do not edit it.

## Archive

`archived/` holds the full historical trail — the redesign's round-by-round reviews + capture (the first-seen +
fail-secure rework; the effective-SAID / content-fork-prevention / federation-witnessing-remodel arcs; the
keep-all-data divergence rework; the KEL primitive (PR #11) + the vdti#12/#13 doctrine-land; and the large body
of pre-reshape design — policy DSL, pinning, credentials, KEL build, old service stubs). Area notes citing
"design-pass §X" / "keep-all-data §X" → look in `archived/`.

**Rule: a doc lives on this surface only while it is current. The day it's superseded, move it to `archived/` —
don't leave drift. Drift is what makes a fresh session (and its sub-agents) confidently wrong.**
