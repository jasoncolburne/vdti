# vdti `.working/` — current surface index

**Fresh session: read these to get current. Everything in `archived/` is historical — do NOT treat it as
canonical (it predates current decisions and _will_ mislead you, including making confident wrong claims).**

## ★★ CURRENT — canon COMMITTED + SHIP-reviewed (2026-07-10); next = the phase-2 `docs/design/` reconciliation

**The whole `docs/canon/` (14 files) is COMMITTED and SHIP-REVIEWED.** The full redesign — the **first-seen
pivot** (a two-tier KEL: signing key + rotation reserve; no recovery key; no repair event; recovery = a plain
rotation; divergence reads _forked_ vs _disputed_), **fail-secure revocation** (a `kills[]` declaration on the
issuer's witnessed IEL; a credential is a direct-anchored SAD, no issuance log), the **layering principle** (the
chain validates structure only), and **SS-3** (single-stream pre-rotation KEL key-state) — is captured and
pressure-tested in `docs/canon/`, committed over two commits (2026-07-10) and whole-canon dual-pass reviewed
**SHIP / SHIP** (no soundness break). `make all` 0. `docs/canon/` is the authoritative surface; `../MODEL.md`
is its plain-english companion.

**Next: the phase-2 `docs/design/` reconciliation** — bring the landed design docs current to the ship-reviewed
canon, one concept per PR in build order (dual-pass reviewed each). **The plan is `vdti-reconciliation-map.md`**
(target files per building block + the canon delta + PR grouping + the 4 encode job-list items SS-1/SS-2/SS-4/C-1).
The **current PR** reconciles the KEL primitive + `event-shape.md` + the landed foundational docs; then IEL /
SEL / policy·documents / federation / services / features.

**Read on re-entry:** `design-resume.md` (the authoritative Live edge) → this file → `docs/canon/`
(authoritative) + `../MODEL.md` + `vdti-reconciliation-map.md`. The reasoning trail is in `archived/` (never
cite as current).

## The `.working/` surface (current)

- **`design-resume.md`** — the design session's bootstrap; read FIRST after a `/clear` or `/compact`. Stable
  role/process framing + the authoritative **Live edge**.
- **`vdti-reconciliation-map.md`** — the phase-2 plan: per-building-block target files, the canon delta, PR
  grouping in build order, and where the 4 job-list items (SS-1/SS-2/SS-4/C-1) ride in.
- **`vdti-1-roadmap.md`** — the phase index + build sequencing, synced to **gh#1** (you keep it current + push).
- **`vdti-event-kinds.md`** / **`vdti-adversary-cases.md`** / **`vdti-keri-comparison.md`** — model/coverage
  explainers (per-log event-kind tables · the attack case-matrix, a coverage input for the encode · the
  KERI/ACDC contrast). **May lag the canon — canon wins.**

## Canonical surfaces (outside `.working/`)

- **`docs/canon/`** (14 files) — the machine-oriented, pressure-tested design canon; **authoritative**. Start at
  `vdti-invariants.md` (load-bearing) + the `vdti-area-*.md` notes; `docs/canon/README.md` orients.
- **`docs/design/`** — the human-facing **landed** design docs; **being reconciled to the canon** (phase-2 — see
  the map). When it and the canon disagree, the canon wins.
- **`../MODEL.md`** — the repo-root plain-english model (greenfield).

## Don't touch

- **`jason-notes.md`** — Jason's own notes. Do not edit or move.
- **`warm-resume.md`** — a review session's bootstrap. Do not edit or move.

## Archive

`archived/` holds the full historical trail — the redesign's round-by-round reviews + capture (the first-seen +
fail-secure rework; the effective-SAID / content-fork-prevention / federation-witnessing-remodel arcs; the
keep-all-data divergence rework; the KEL primitive (PR #11) + the vdti#12/#13 doctrine-land; and the large body
of pre-reshape design — policy DSL, pinning, credentials, KEL build, old service stubs). Area notes citing
"design-pass §X" / "keep-all-data §X" → look in `archived/`.

**Rule: a doc lives on this surface only while it is current. The day it's superseded, move it to `archived/` —
don't leave drift. Drift is what makes a fresh session (and its sub-agents) confidently wrong.**
