# vdti `.working/` — current surface index

**Fresh session: read these to get current. Everything in `archived/` is historical — do NOT treat it as
canonical (it predates current decisions and _will_ mislead you, including making confident wrong claims).**

## ★★ CURRENT — final dual-pass DONE (MERGE/MERGE), all findings folded (2026-07-10); PR#11 rewritten + merge-ready

**The redesign is landed on both surfaces.** `docs/canon/` (14 files) is COMMITTED + whole-canon SHIP-reviewed
(first-seen + two-tier + fail-secure + layering + SS-3). And now the landed **`docs/design/` docs are reconciled
to it and committed** — the implementer's 6-chunk one-pass: first-seen + two-tier + **four-state** + formalized
single-word merge outcomes + fail-secure revocation + credential = a direct-anchored SAD + no direct mode + the
verdict-recoupled effective-SAID synthetic. The designer's matching **four-state / merge-outcome canon backport**
(area-kel §1 + vdtid §1e) is also done. Spot-checked strong (big residue gone; `privileged`→`sealed` clean;
`policy/documents.md` landed fail-secure + the C-1 counter-example).

**Reconciliation + the 8 folds are COMMITTED** (the first dual-pass returned MERGE/MERGE; folds = stale-tier
`1/2/3`→`1/2` · KEL heading `5 kinds (+ Fcp variant)` · doc-member `Trm` `grant-doc`→`rescind-doc` · `Empty` vs the
four live-chain states · below-seal attach-position note · Matrix 2 "no Disputed source" row-note ·
state/`region()`/`effective_said` correspondence table · `Terminated`/`Terminal`/`Trm` disambiguation; canon fallout
checked — none). **`make all` GREEN** (0 errors, 527 OK; 31 tolerated forward-refs). This session also **rewrote
PR#11's title + body** (branch `VDTI-10_kel-primitive`) to current reality and **merged** the `.working/` KERI
comparison into `docs/canon/supplemental/vdti-keri-acdc-comparison.md`.

**FINAL confirmation dual-pass RETURNED — MERGE / MERGE.** The 5 real findings folded (`make all` green, 529 OK); the
two eye-items resolved — (A) the seal-cap phrasing (Jason 2026-07-10): the **expression** `parent.serial >= seal_serial`
stays (the canonical-extension gate; an `event.serial` swap would misframe it), but invariant 5's **framing** was
imprecise and was **reframed** (inv 5 in reconciliation.md + canon `vdti-area-kel` + the `.terminology-forbidden`
mirror) — refusal-**as-a-canonical-extension** is unconditional, the refused event's **disposition splits**
(strictly-below → `Sealed`/`Disputed`; a sibling at the seal's own serial `v_{seal−1}` is a retained live fork, not a
locked-portion rejection — the cap bounds content extended **from** the seal, not a sibling to it); and (B) the
model-stale **`iel/delegation.md`** stub is **fixed**. `make all` green. Briefs + findings + `pr-11-body.md` →
`archived/`.

**Read on re-entry:** `design-resume.md` (the authoritative Live edge — full current state) → this file →
`docs/canon/` (authoritative). **On resume:** the reconciliation PR (#11) is review-clean + green + **merge-ready**
(Jason commits + merges) — then the later building-block PRs (IEL-fresh → SEL-fresh → policy → federation → services →
features) per `vdti-1-roadmap.md`.

## The `.working/` surface (current)

- **`design-resume.md`** — the design session's bootstrap; read FIRST after a `/clear` or `/compact`. Stable
  role/process framing + the authoritative **Live edge**.
- **`vdti-1-roadmap.md`** — the phase index + build sequencing, synced to **gh#1** (you keep it current + push).
  The forward plan (build order + the pinned SS/C items) lives here; the reconciliation PR's briefs / findings /
  map are consumed → `archived/`.
- **`vdti-adversary-cases.md`** — the attack case-matrix (a coverage input; **may lag the canon — canon wins**).
  _(The per-log event-kind tables and the KERI/ACDC contrast are superseded — by the landed design docs and by
  `docs/canon/supplemental/vdti-keri-acdc-comparison.md` respectively → `archived/`.)_

## Canonical surfaces (outside `.working/`)

- **`docs/canon/`** (14 files) — the machine-oriented, pressure-tested design canon; **authoritative**. Start at
  `vdti-invariants.md` (load-bearing) + the `vdti-area-*.md` notes; `docs/canon/README.md` orients.
- **`docs/design/`** — the human-facing **landed** design docs; **being reconciled to the canon** (phase-2 — see
  the map). When it and the canon disagree, the canon wins.
- **`../MODEL.md`** — the repo-root plain-english model (greenfield).

## Don't touch

- **`warm-resume.md`** — a review session's bootstrap. Do not edit or move.
- **`implementer-resume.md`** — the implementation agent's own bootstrap + progress tracker (its session). Read it
  on resume for the tracker; do not edit it.

## Archive

`archived/` holds the full historical trail — the redesign's round-by-round reviews + capture (the first-seen +
fail-secure rework; the effective-SAID / content-fork-prevention / federation-witnessing-remodel arcs; the
keep-all-data divergence rework; the KEL primitive (PR #11) + the vdti#12/#13 doctrine-land; and the large body
of pre-reshape design — policy DSL, pinning, credentials, KEL build, old service stubs). Area notes citing
"design-pass §X" / "keep-all-data §X" → look in `archived/`.

**Rule: a doc lives on this surface only while it is current. The day it's superseded, move it to `archived/` —
don't leave drift. Drift is what makes a fresh session (and its sub-agents) confidently wrong.**
