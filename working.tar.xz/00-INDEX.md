# vdti `.working/` — current surface index

**Fresh session: read these to get current. Everything in `archived/` is historical — do NOT treat it as
canonical (it predates current decisions and *will* mislead you, including making confident wrong claims).**

## ★★ CURRENT ROUND (2026-07-08) — FIRST-SEEN: dual-pass reviewed, effective-SAID resolved, ledger current

The first-seen model is worked through, **captured**, and **dual-pass reviewed** (both HOLD, no soundness break —
the review flagged one item for Jason, the effective-SAID; this session resolved it and folded the dispositions
in). NOT yet encoded into the canon. Read in order:

- **`vdti-model-plain-english.md`** — the model in plain english (concepts + rules).
- **`vdti-event-kinds.md`** — the per-log event-kind tables (two tiers).
- **`vdti-adversary-cases.md`** — the attack case-matrix + "what we tried to break" + the SEL/delegation reduction.
- **`vdti-first-seen-reconciliation.md`** — the canon reconciliation ledger (delete/keep/rewrite; the encode
  roadmap). **§2/§2a** = the effective-SAID resolution; **§4** = the floors; **§5** = observable-breach (scoped).

**Decided / resolved (through 2026-07-08):** first-seen, **scoped** (single-key chains → first-seen; threshold
chains → record-both → disputed); **two tiers** (drop the recovery key + `Rec`/`Ror`/`Rpr`/`Fld` + T3 +
`t_recover`); recovery = a plain rotation (root-bury), eviction = a governance `Evl`-cut — **no repair machinery**
(delete the proof); **direct mode removed**; **roster cap 32** all IELs; **majority floor** on
`t_govern`/`t_authorize`; the **witness-config floors** (`signers ≥ 3`, availability `threshold ≤ signers − 1`,
federation roster ≥ 4 / ≥ 5 recommended, the fork-cost dial); observable-breach → invariant, **scoped to "no
silent *forgery*"** (a dormant takeover-by-extend is caught by owner vigilance, not disputed/staleness); freshness
→ mandatory gate + witness-sig monotonicity.
- **Terminology:** **`sealed`** replaces **`privileged`** everywhere (a seal-advancing event); the mechanical
  global rename is pending as its own verifiable pass.
- **Effective-SAID (L2, resolved this session):** single confirmed tip → its real SAID; no single tip → a
  **synthetic** marker recoupled to the verdict (`forked` / `disputed`). No live-tips hash (flood-unstable under
  dishonest signers); no anti-entropy branch-assembly (root-bury resolves by position → convergence is
  owner-driven). No consumer needs branch-sensitivity (ledger §2a: vdtid-services §1e/§1i, document-policy §F).
  Per-serial bound = **early-termination at 2 sealed → Disputed → terminal** + sub-threshold fail-secure
  (materialization ≤ 3), not a production cap.

**Status: CANDIDATE — design captured + reviewed + effective-SAID resolved; canon UNTOUCHED.** Next: a **focused
re-review** of the effective-SAID resolution (it reverses the four-round-reviewed §1e, and post-dates the first
review), then encode the ledger on its own branch. The first dual-pass review (briefs + findings) is in
`archived/`; `vdti-subchain-model.md` (the pivot's origin draft) is archived too.

**Everything below this block is prior-round historical context (pre-first-seen: PR #11, the repair-proof, the
fed-wit remodel — superseded; due for a prune).**

## ★ Active work — **★ CURRENT ROUND (2026-07-05):** the event-taxonomy refactor + diagrams (concept diagrams + minimal re-style + the `manifest.` prefix + `kel/events.md` §Anchors) are **committed** (Jason); the canon was re-read this session; a spot-check added the federation `Fcp` row to `event-shape.md`'s IEL kind table (**9 → 10 kinds**, `make all` 0, uncommitted). The active review is the **broadened freshread** (`vdti-protocol-doctrine-freshread-brief.md` — a no-canon exposition + core-model coherence pass across the whole doctrine, property-framed for Fable; **Jason launching**); the fold-and-diagrams dual-pass artifacts are **archived**. **`design-resume.md` Live edge is the authoritative current state.** _(Everything from here on is historical context — PR #11 / repair-proof.)_ PR #11 READY for Jason's gh review + commit. The reshaped design canon is fully landed into `docs/design/` (the KEL primitive + the manifest-role model + kind-strict anchoring + the SEL/credential/document/policy reshape + the `Fed`→`Wit` remodel + inv 18 + the doc/drawing tooling) — all reviewed, folded, green (2026-06-30). Latest: the inv-18 field-presence delta was dual-passed (warm HOLD-1 / cold HOLD-1, both folded — the cold blocker was the **4th `Wit`-federation sibling-miss** in `verification.md`'s dispatch). README/AGENTS drift fixed; `docs/design/canon.tar.xz` + `make canon-tarball`; **Branch `VDTI-10_kel-primitive` (PR #11, issue #10) — committed + pushed** (the reshaped canon; the folds→forks + the *old* repair-not-final-F4 doctrine encode; the `lint-drawings`→`lint-diagrams` tool rename + `--describe` layer-grouping / chain-order / per-example descriptions). **ACTIVE design work = the repair-completeness proof** (root-pointing + deadness-descends + the **cross-layer resolution**; **ENCODE DONE + REVIEWED; label-strip folded; doctrine-quality fold pending (fresh-read found real exposition defects — full pass)** — see the bullet below). **Pending housekeeping:** update the gh **issue #10 + PR #11 bodies** via `gh` (`vdti-pr11-body.md` drafted — `Closes #10`, lint-diagrams — but **NOT yet pushed to GitHub**; `gh pr edit 11 --body-file …`). (START HERE if resuming)
  - **In-flight (post-PR-11): the repair-and-evict fold** (2026-06-30) — a user IEL `Rpr` carries a roster `cut` + `threshold` (one-event repair-and-evict, retiring the `{Rpr, Evl}` batch + cold-4 A2; cut priced at the **outgoing** `t_recover`; **`t_govern ≤ t_recover` hard**; general roster-floor **`|roster| ≥ 1`**, every singleton downward-immutable). **Dual-reviewed TWICE (r1 blocker: the bounds re-check hadn't named the `Rpr`-cut; r1 cold MAJOR: outgoing pricing; r2: count-word/enumeration/set-precondition consistency) → all folded → MERGE.** Folded into inv 4/12/13 + area-iel + federation §1e + impl-notes. **ENCODE DONE** — landed into `event-shape.md` + `protocol-doctrine.md` (drawing reconciled to `manifest.roster`, gate clean); **all green, modified-uncommitted** (Jason's commit). Threshold-only `Rpr`: decided — require a non-empty `cut`. All review + encode artifacts in `archived/` (encode log there too). **Fully landed end-to-end; nothing outstanding.**
  - **In-flight (2026-07-01): the `folds` → `forks` simplification** — the `folds` SAD `{canonical, forks[]}` + boundary-SAIDs → a single **`forks`** manifest role (inline list of archived-branch tip SAIDs), **repair-only** (`Rec`/`Rpr`); `canonical` + boundary-SAIDs dropped (run = derivable `[previousSeal..previous]`, nodes keep full bodies; "folded" = `previous != previousSeal`). Landed in **inv 4/13/17/18 + area-sel** (`make all` green). Drawing field/prose reconciled; the per-Ixn `folds.canonical` arrows → one `previous` arrow to the tip (Jason, GUI). Doctrine `.md` docs NOT yet reconciled (encode after review). **Dual-reviewed → all HOLDs folded → MERGE** (stale `+folds` ×2, `forks` added to IEL/KEL role grids, the NIT, and the **F4 on-arrival rule** → inv 13); review artifacts **archived**; **ENCODED + committed** (event-shape grids + spine sections across the `kel/` docs + protocol-doctrine; `make all` green) on branch VDTI-10. **Fully landed.**
  - **a repair is NOT final-on-arrival — SUPERSEDED by root-pointing (2026-07-01; see the next bullet).** The original "re-freeze + a second repair" framing gave way to **root-condemnation + deadness-descends** (a repair names losing-branch *roots*, condemning subtrees; a missed branch's growth is dead by descent). ⚠ **The OLD F4 rule** ("a node stays frozen on an uncovered content branch") **was committed to the doctrine** — `kel/merge.md` §"A repair is validated on arrival, not auto-applied" + `protocol-doctrine.md` §Divergence — and is now **STALE**. The repair-completeness encode **has now overwritten those sections** (working tree, uncommitted — 2026-07-02) with the root-pointing rule; the committed doctrine updates on commit (canon = the root-pointing bullet below).
  - **The repair-completeness correctness proof (2026-07-01): ROOT-POINTING — canon rewritten, verification held** (`vdti-repair-completeness-proof.md`). Two drafts HELD (tip + stacking); working the findings against `vdti.excalidraw` ex 9 gave a **strict simplification — root-pointing — that subtracts stacking entirely.** `forks` names each losing branch's **ROOT** (first divergent event, off the retained chain) → **condemns the whole subtree**, so post-repair growth is dead by descent (ex 9: `Rec.forks → Ixn#2` kills `Ixn#2`+`Ixn#3`); a **missed** branch's growth is **dead by descent** (**deadness-descends** — parent dead ⇒ child dead; r3 fix, since the per-event seal-cap only locks the *first* event). Whole forked region 64-capped since the last seal, witnessed/non-canonical (ex 9's description). **Safety = three rules:** root-condemnation (2 guards: root off the retained chain · condemned subtree content-only) + deadness-descends + privileged-precedence (a `Rot` on a dead branch → `disputed`, tier-2 terminal). **RETIRED: stacking · valid-pointer set · below-seal carve-out · settle-out.** **r4 dual pass returned + FOLDED (2026-07-01):** cold HOLD-4 (F1 cross-layer, F2 64-cap-is-a-count-claim, F3 retain-and-count, F4 S1 full-span, F5 gate-content, F6 D1 honesty) + warm HOLD-1 (reviewed a **stale** proof — now moot; MINOR 64-cap converged w/ cold F2). **F1 resolved by Jason's cross-layer model** — the owner IEL is the SEL's clock: **anchor-monotonicity** (a SEL event must extend its SEL's latest IEL-anchored tip; re-anchor → inert) + **cross-layer deadness-descends** → theorem *a valid SEL fork implies an IEL fork beneath it* (no linear-IEL deadlock; cold's case rested on a node blind to the SEL tip) + **T1 fully deadenable**. **64-cap corrected** — NOT "unbounded but harmless" (my mis-fold) → **bounded fork** (depth ≤ 64/lineage; breadth bounded by the **divergent-position gate**: *no more witnessing once divergent*). All folded (proof wholesale rewrite + inv 4/13/17 + area-{sel,iel,kel,federation-witnessing}); r4 findings archived (`-r4`/`-r4-stale`). **r5 returned + FOLDED (2026-07-01):** both HOLD-2, converged on the **kind-blind gate** → fixed **kind-aware** (declines *content* siblings only; privileged + the **single repair** always witnessed — Jason's steer; retention is the primary breadth bound); cold **F2** attribution → **skip-unattributable** + a transient withheld-body residual; warm **MINOR** descent is **IEL→SEL only** (not KEL→IEL, forward-only) + nits. All folded; r5 artifacts archived (`-r5`). **Encode brief written** (`vdti-repair-completeness-encode-brief.md`) — **a FULL landed-doc reconciliation, one pass** (per `feedback_landed_docs_kept_current`, *not* a kel slice): event-shape + all 6 kel/ docs + protocol-doctrine + system-thesis, grep-verified whole `docs/` tree; 4th matrix + overwrite stale F4 + tips→roots/second-repair/re-freeze sweep. Only the **cross-layer SEL↔IEL** rule is forward (unbuilt `sel/`+`iel/` home → forward-ref, not a defer-reason for landed docs). **Encode DONE (working tree, uncommitted)** — full reconciliation landed (protocol-doctrine + all 6 kel/ docs + event-shape + system-thesis + **Matrix 4** + `.terminology-forbidden`; `make all` 0 + grep clean); cross-layer forward-ref'd. **Encode dual-pass review returned (2026-07-02): warm HOLD-1 / cold MERGE — CONVERGED on one `[voice]` fix** (canon `S1`–`S4` guard *labels* leaked into `kel/reconciliation.md`; prose excellent, other docs label-free) + nits; otherwise clean. Label-strip + nits folded. **Then a decorrelated third look (2026-07-02): my canon-diff + a no-canon fresh read** found real **exposition defects** in protocol-doctrine §Divergence (overstatements, undefined terms — *privileged*/*tier-rank*, a mis-attributed seal-cap, cross-doc drift) — all canon-faithful in substance. **Jason: full doctrine-quality pass. Fold-brief written** (`vdti-protocol-doctrine-quality-fold-brief.md`, canon-backed per finding; F4/F16 pins pending veto). **DONE + COMMITTED (2026-07-02): the doctrine-quality fold + dual re-review + this session's fold** — **Kil is NOT terminal** (Jason's ruling; `{Kil, content}` recoverable, `Dec`-only terminal tip), **A1** privileged-final split (no-resurrection + resolution-stability), **A2** attach = the controlling entity's last event, + prose/canon-syncs; `make all` green. Tier-rank `{Dec, content}` re-confirmed (necessary + safe; second-privileged → `disputed`). **Cold re-review round 1 returned + FOLDED (2026-07-02): 16 findings (F1–F16), all real exposition defects — all folded** into `protocol-doctrine` (uncommitted, `make all` green): attach-passage precision (F1/F2), first-arrival-keyed cross-node race (F3), empty-`forks` vs lagging-accept (F4), archived-vs-retained + held-roots + single-`v_{d-1}` (F5), tier-rank-on-tip (F6), + F7–F16 clarity/consistency. **Cold re-review round 2 returned + FOLDED (2026-07-02): 1 real finding (the `v_{d-1}` overload my own F1/F2 fold had introduced — fixed to "divergence at `d` ⇒ `d-1` agreed, always on the retained chain, no adversary-authored `v_{d-1}`") + 3 nits.** `make all` green. **Cold re-review round 3 returned + FOLDED (2026-07-02): 3 major + 4 medium + minors** — F1 cross-node `{Rot,Ixn}` = **Divergent** both orders, reconcilable iff ≤ 1 privileged (a `Rec` extends the `Rot`); F2 authorship framing **stripped** from the `v_{d-1}` passage (structural only: `d-1` agreed/attested-shared); F3 **tier-2 causes reincept** too (≥ 2 privileged, any tier); + fork-arity / retained-tip / self-cascade mediums + the `kel/recovery` `ownerPin`→`pin` nit. `make all` green. **Diagram + describe-tool fixed** (example-3 evict, example-11 KEL-only; tool now groups by connected component — no nearest-title bleed). **Deferred:** reserve-terminology consistency + cosmetic minors. **NEXT: one more cold pass** — same brief (KEPT); round-3 findings archived `-5.md`.
- **The remodel is CONVERGED + folded into the canon** (the `vdti-area-*.md` notes + `vdti-invariants.md` ARE the design now); the full round-by-round spec is **`archived/vdti-fed-wit-remodel.md`**.
  `Fed`→`Wit` at both layers (**one `Wit` kind, `Wit` anchors `Wit`, `Wit` IS the T3 rotation**), **`Fcp` marks the
  federation IEL inception** (structural disambiguator — interpretation, not trust; self-*witnessing* carve-out stays
  dead), federation infra cross-witnessed **exclude-self**, **single-federation** witnesses (migrate = new KEL).
  **The fold is applied across the canon** (`vdti-invariants.md` + `vdti-area-{iel,kel,federation-witnessing,
  document-policy}.md` + `vdti-federation-inception-reference.md`; ~170 touchpoints; `make all` green). **Rounds 7–13
  archived; round-14 dual-pass briefs written** (`vdti-anchors-v1-review-{warm,cold}-14-brief.md`). **Round-8 dual-pass
  returned (warm HOLD-3 / cold HOLD-1) + ALL findings folded (2026-06-29):** cold **F1** was a design correction →
  the federation IEL is **self-attested** (witnessed via its member KEL anchors; **exclude-self at the KEL level,
  pool `|roster| − 1`**; no aggregate IEL-receipt gate; never bricks — supersedes the round-8-draft `|roster| −
  |participants|`); **F2** clock = monotonic + `≤ now+band` ("ahead of member KELs" dropped — KELs timestamp-free);
  **F3** facet-dependent `allowed(Wit)` + root-before-payload; **F4** trust = config-pinned federation **set**
  (`Fcp`-rooted = well-formedness); **F5** roster-add pre-add-roster `t_govern` gate; + warm consistency sweep. **Opens
  Q1/Q2/Q3 all RESOLVED + folded** (reviews verify-landed, not re-decide): Q1 self-attestation (above), Q2 `Fcp`-rooted
  binding check, Q3 governance-facet match = witness-config only. **Diagram (Jason, 2026-06-29):** `vdti.excalidraw`
  ex-6/7 match the remodel — canonical. **The `manifest.folds` label is now CORRECT** — the manifest role is renamed
  `folded`→**`folds`** (dual-readable like `anchors`/`delegates`; Jason 2026-06-29), swept across the canon (landed
  `docs/design/` (the `kel/` docs) still say `folded` → the remodel-delta encode + a `docs/.terminology-forbidden` entry).
  **ROUND-9 + ROUND-10 dual-pass returned + folded (2026-06-29).** Round-9: cold-9 **B1** federation self-attestation
  `threshold ≤ |roster| − 2` (recoverability cap; `≥ 3` floor stays) + no-self-weakening; Q1/C1/C2/Q2/Q3 + warm-9
  consistency + the `folded`→`folds` rename. **Round-10:** cold-10 **F1** [blocker] — the cap is single-loss only,
  generalized to **`threshold ≤ |roster| − 1 − k`** (hard cap stays `|roster| − 2` = evict-one; §1c "≥5 tolerates 2
  losses" corrected — authoring ≠ self-attestation); **F2** (`threshold = 1` → 0 witnessing byzantine-tolerance, the
  `≥ 5` doctrine answers it), **F3** (federation chain has **no `federationPin`**), **F4 → 365-day key-window
  auto-expiry** (`MAX_WINDOW = 365 days`; rotate ≥ once/year), C1 into the D1 spots + cross-refs. **Plus a Jason design
  call: the federation IEL declares EXACTLY `{t_govern}`** — drops `t_use`/`t_delegate`/**`t_recover`** (it never
  repairs → nothing consumes `t_recover`; the E4 framing was a category confusion). **Round-11:** cold-11 **blocker** —
  the 365-day auto-expiry × self-attestation **bricked the federation on a single missed annual ceremony**; fixed by
  **carving the clock axis out of no-self-weakening** (a rotation self-attests under the **new** windows it
  establishes, F4-bounded → an all-windows-lapsed federation reads stale + recovers via a catch-up rotation, never
  bricked; threshold + roster stay pinned). **Plus a Jason call: a LOST key is operational** (evict-and-replace
  promptly, or reincept+swap; auto-expiry backstops but doesn't cure — never leave a lost key in the roster; distinct
  from a recoverable *missed* ceremony) + warm-11 low + cold-11 Qs + consistency. **Round-12:** cold-12 **blocker (F1)** —
  the 365-day auto-expiry is the first **time-triggered** trust transition (no chain event), but freshness/token-cache
  is **movement-triggered**; fixed by **caching the witnessing-time, not the verdict** + a **wall-clock decision-time
  staleness overlay** recomputed against `now` independent of effective-SAID movement (inv 8 / vdtid §1d / §1f). **Plus
  a Jason call: an at-risk flag** (a member whose window auto-expired ≥365d is flagged on the token; operators
  evict-or-reconfirm) + **the warn-vs-reject principle** (reject only un-usable configs; allow usable + warn) + F2a/F3/F5
  + warm-12 low. **Round-13:** warm **MERGE**; cold **blocker** — a bare `cut` could slide the federation to
  un-recoverable (`|roster| 5→4` at `threshold 3`); the post-delta recoverability re-check (inv 12) was scoped to
  `Evl`, which the federation never authors. Fixed: **re-check at every roster-delta event (`Evl` or federation
  `Wit`)** — a cut needs **post-cut `|roster| ≥ threshold + 2`** + the `t_govern` bounds, now *enforcing* the
  `[locked]` "never-unrecoverable" invariant; + F2 (inv 14 clock-guards: receipt-`τ` ceiling added, `F5` overload
  fixed) + F3 (consumer must keep its clock synced to within the `band` (1 min) — operational). **Round-14 dual-pass returned + folded (2026-06-29):** warm **HOLD-1** (area-iel §4 cross-ref scoped the re-check to `Evl` → "every roster-delta event — here the user-IEL `Evl`"); cold **MERGE + 1 LOW** (refuted the slide-to-unrecoverable from scratch; folded a same-event `{cut W1, add W1}` order-dependence — `add` now tested against the pre-delta roster, `cut ∩ add ≠ ∅` rejected, §1a). Both LOW + independent → effectively a clean dual MERGE. **Round-15 (the certifying pass) returned the clean green light — warm MERGE / cold MERGE (2026-06-29); the federation/witnessing model has CONVERGED** (one non-blocking cold F1, terminal-`Dec` doc-clarity, folded on top: `area-iel:32` carve-out + §1f `Dec`-carries-`clock`). **The full landed-docs ↔ canon reconciliation is DONE + dual-pass reviewed (2026-06-30):** warm **HOLD-1** + cold **HOLD-3** (1 HIGH, 2 MED) — all landed-doc staleness vs locked canon, triaged, no misframes. **Canon fixed this turn:** the clock carrier → `Fcp`/`Wit`/`Dec` uniformly (inv 4:63/147/189, inv 14:486, area-iel:50/77) + the federation-facet `Wit` phrasing clarified (a `Wit` **always modifies something** — the `federationPin` ratchet + participant rotation IS the change; the KEL↔IEL anchor-up/pin-down binding; area-iel:32). **Implementer fix-brief written** (`vdti-docs-canon-reconcile-fixes-brief.md`) for the 3 doc findings — **F1** verification.md §Inheritance (the user IEL carries its **own** federation, anti-straddle cold-3 B2; HIGH/security), **F2** the KEL `Wit` two-facet (add the `Fcp`-rooted governance facet + event-shape field-presence), **F3** direct-mode (`federation` opt on a user `Icp`). **Rereview-1 → warm MERGE / cold HOLD (1 MED + 3 LOW)** — the recurring `Wit`-change friction traced to a **canon error** (`area-iel:32` "ratchets the `federationPin`" — the federation chain has none, F3), fixed. **Fix-2 applied → rereview2 → warm MERGE / cold MERGE (2 non-blocking LOW).** **Then Jason-directed post-review folds (2026-06-30):** `root_facet` on the `KelVerification` token; **`witnesses` present-iff-changed** on `Wit` (mandatory only at inception; KEL carries / IEL field-matches); **NEW inv 18** ("events carry only changes; the established state is *used*, not re-stated; no empty events"); **F1/F2/F3 field-presence cleanup** (`federation`/`federationPin` `opt` on a user `Wit`; the re-seal `Evl` **omits `roster`** — renamed "roster-less re-seal `Evl`"; `clock` `req` on a federation `Dec`). `make all` green. **The full docs-canon-reconcile cycle artifacts are archived.** **Dual-pass DONE (warm HOLD-1 / cold HOLD-1, both folded — green; the cold blocker was the 4th `Wit`-federation sibling-miss in `verification.md`'s dispatch).** README/AGENTS drift fixed (KERI = a DKMI; kind-strict anchoring; `lib/vdti`); `docs/design/canon.tar.xz` + `make canon-tarball`; **PR #11 description (full scope, 42 commits) + roadmap (gh#1) pushed.** NEXT: Jason reviews PR #11 in gh + commits. Full detail in `design-resume.md`'s Live edge. *(The SEL-kill / KEL bullets below are historical context.)*

## ☾ Historical context (was the prior ★ active work)
- **SEL-kill / document-pin sweep + dual-pass review — DONE (2026-06-27).** Both passes returned HOLD and
  **converged** on one blocker (the SEL `Pin` was `t_use`/T1 *and* seal-advancing → tier-1 self-promotion);
  **folded** by splitting **`Pin`** (T1, re-pin) from a new **`Fld`** (T2, fold), plus C2 (documents.md
  overstatement) + C3 (immutable `bound`) + the consistency/nits. Both checkers green. The base decisions
  stand (drop the document/cred pin · rescission `{Icp, Dec}` · `Pin`+`Fld` split · `issuers[]` SAD · derived
  witness-key IEL). Review records (archived): **`archived/vdti-sel-pin-review-warm.md`** + **`…-cold.md`** (+ the `…-brief.md`s). **C7 + the area-sel staleness are now CLOSED**
  (`anchors` added to IEL `Evl`, symmetric with `Rpr`; gate green 2026-06-27) → the SEL `Pin`/`Fld` review is
  MERGE-ready, and the **`ownerIelEvent → ownerPin`** custody rename is landed. **Open items** — encode the
  **multi-party documents** feature (`vdti-area-multi-party-documents.md` → `features/multi-party/documents.md`; a
  *separate* type from credentials, **NOT** subsumed) and cold Q's **C4**/**C6** (C5 owner-rooting now lives in the
  multi-party note) — are in `design-resume.md`.
- **KEL primitive docs (`docs/design/primitives/data/event-logs/kel/`) — post-#13-reconciled + polished, pre the
  `Fed`→`Wit` remodel.** The 6 docs (events / log / merge / reconciliation / recovery / verification) are fully
  reconciled to the log-primitive reshape (the `manifest` role model, `previousSeal`/spine, data-local
  `forked`/`disputed` detection, the three-tier model, the reconciliation matrix) and in clean voice — through
  **4 review rounds + 3 design follow-ons** (all closed); both checkers green. On branch `VDTI-10_…` / PR #11
  (issue #10). The **active work** is the implementer fix-pass for the 3 review findings (brief: `vdti-docs-canon-reconcile-fixes-brief.md`; the full reconcile is `vdti-docs-canon-reconcile-brief.md`).
  *(The executed reconciliation plan + its review trail → `archived/`.)*
- **`design-resume.md`** — the design session's **bootstrap** (read FIRST, after a `/clear` or `/compact`):
  stable role/process framing + the live edge. (Merged in the old `post-compaction` prompt — 2026-06-27.) Current
  edge = KEL #11 design-complete (awaiting gh review); **major canon doctrine work this session** —
  `issues`/`revokes`/`rescinds` → `anchors`, the **v1 anchoring rule**, the `Pin`-generalization, **kind-strict
  anchoring everywhere** (KEL→IEL exact-kind; `Rec` hosts no anchor), and the **federation genesis fix + new
  `IEL Fed` kind** (no `Fed` on witnesses; `Fcp → Rot`; IEL now **8 kinds**), plus round-3's **`pins` = prior-KEL-tip**
  acyclicity (B1) and the **B2 federation-binding** fix (IEL-authoritative · exact-content match · migration window ·
  `Fcp`-no-`Fed`) + the **F8/direct-mode** note; round-4's **A2** (repair+evict `Ror`+`Rot`) + exact-content scoping +
  **B2**/**C1**; then round-5's **B1** → **`Wit` = the federation IEL's *single governance kind*** (T3, `Ror`-anchored,
  does roster + rotation; the federation has **no `Evl`** — set `Icp`/`Wit`/`Dec`; **corrected 2026-06-28** from a
  first mis-fold of `Wit` as a separate rotation-pin), plus **C1a** direct-mode now **reachable** (`Icp` federation
  optional, first-`Fed`-binds, per-**range** witnessing + `Fed` cap), **C2** fail-secure-refuse, **C3** atomic
  `{Rpr,Evl}`, **C4** closed `{federation,federationPin}`, **C5** one-position, **C6** consent-`Ixn` scoping.
  **Rounds 1–6 folded, gate-green.** Round-6 dual pass (warm HOLD-3 / cold HOLD-2) caught the incomplete
  `Evl`→`Wit` *prose* sweep + the federation roster-add consent gap; all folded 2026-06-28: **A1** = joiner-`Ixn`-alongside
  (option b, per example 6), **A2** = every `Wit` a full ceremony, **D1** = IEL carries its own witness-config (SEL inherits,
  KEL keeps own), + E1/E2/E4/F2/F3 + the prose sweep. **Round-7 dual-pass briefs written; round-6 records archived.**
  **Diagram fully clean** (ex-2/3/4/6/7; `lint-diagrams --describe` — layer-grouped nodes/arrows, chain-order numbering, and per-example descriptions).
  Next: reconcile the landed docs (`kel/events.md` et al., + `IEL Fed`/`Wit` + the IEL witness-config); multi-party round-3 folded +
  archived (cold-3 = MERGE-pending-review).
- **`vdti-invariants.md`** — the load-bearing cross-cutting rules (inv 4 manifest/spine · 13 divergence ·
  16 addressing/encryption · 17 spine/fold/detection). *The* constraints; the area notes ref them.
- **`vdti-implementation-notes.md`** — build-shaping decisions (Postgres storage, mesh encryption, advisory locks).
- **`vdti-area-document-policy.md`** — the document/policy layer (the spine: DSL, the two evaluators,
  cred-as-a-SEL, revocation/closure = `Dec`).
- **`vdti-area-iel.md`**, **`vdti-area-delegation.md`**, **`vdti-area-sel.md`**, **`vdti-area-kel.md`**,
  **`vdti-area-federation-witnessing.md`**, **`vdti-area-vdtid-services.md`** — area notes (locked-candidate).
- **`vdti-area-multi-party-documents.md`** — NEW (2026-06-27): the collaborative editable-document feature
  (V0 `authors[]` + per-author SELs + a multi-parent version DAG); a *separate* type from credentials. Pending encode.
- The **landed `docs/design/`** + these area notes + invariants are the **current truth**; `archived/` is historical.

## Current design — the canonical surface
**The landed `docs/design/` + the `vdti-area-*.md` notes + `vdti-invariants.md` ARE the design** (★ above). Supporting:
- `vdti-federation-inception-reference.md` — federation depth (genesis ceremony; companion to the federation note).
- `vdti-implementation-notes.md` — build-shaping decisions that aren't doctrine (storage, transport, locking).

## Open PR
- **PR #11** (issue #10, branch `VDTI-10_…`) — the KEL primitive, **design-complete & awaiting Jason's gh
  review**. *(VDTI-12 / PR #13 merged; its body + policy-review files now in `archived/`.)*

## Reference / ideas / planning
- `vdti-keri-acdc-comparison.md` — KERI/ACDC contrast (context; per-cred-SEL terminology current).
- `vdti-token-store-idea.md` — client-side verification-token cache idea (composes with pin-everything).
- `vdti-lib-storage-stub.md` — Phase-1 build planning for the absorbed `verifiable-storage-rs` (forward-looking).

## Always-current
- `vdti-1-roadmap.md` — phase index + build sequencing; synced to **gh#1** (you keep it current + push). Always stays.
- `jason-notes.md` — Jason's own notes. **Do not edit or move.**

## Archive
`archived/` holds the full historical trail — the converged design-pass + its soundness reviews; the design-review
rounds (1–5 + level-up); the **keep-all-data divergence rework** (the §1–§13 decision log) + its four model-review
rounds; the **docs-review rounds** (r1/r2 briefs + outputs); the **memory audit**; the VDTI-12 doctrine-land
briefs/reviews; and the large body of pre-reshape design (policy DSL, pinning, credentials, KEL build, old service
stubs). Area notes cite "design-pass §X" / "keep-all-data §X" → look in `archived/`.

**Rule: a doc lives on this surface only while it is current. The day it's superseded, move it to `archived/` —
don't leave drift. Drift is what makes a fresh session (and its sub-agents) confidently wrong.**
