# vdti `.working/` — current surface index

**Fresh session: read these to get current. Everything in `archived/` is historical — do NOT treat it as
canonical (it predates current decisions and _will_ mislead you, including making confident wrong claims).**

## ★★ CURRENT — ROUND-8 FOLD COMPLETE (same-serial dispute + KILLSWITCH); round-9 briefs written (open PR #17)

**2026-07-11 — two corrections, both folded** across **canon + design** (`make all` GREEN — **720 OK, 0 errors**;
on `VDTI-16`):

- **Acceptance = threshold, distinct from first-seen-decline (RESOLVED).** The round-7 pressure-test confirmed my
  "one predicate for both" was the error. `witnessed` / accepted = **threshold receipts**; a witness's own
  signature is **decline + one receipt + admits-valid**, never acceptance; a self-signed sub-threshold event is
  **deferred, never counted**.
- **Dead-by-descent — "you can't seal a buried chain" (NEW, live with Jason).** Cold's P0-3: "disputed ⇒ double-
  sign" was only true same-position. Constructed the cross-position case + confirmed it's precluded — a lineage is
  dead from its **first-seen loss**, and a seal forged on a dead lineage is **dead by descent**. This **collapses
  every dispute to the fork** (two accepted branches ⇒ same-position double-sign / collusion). Reserve-theft without
  collusion → inert loser, not a dispute.
- **Race narratives rewritten acceptance-gated** (honest race → stall/re-issue → Active; `Disputed` = collusion
  residual); **query-scoping + `all-data` audit flag** on the design surface; **`deferred-pending` lifecycle**;
  **verdict-predicate anchored** (§Terminology; the bare "≥ 2 sealed" sweep is **partial** — round 8 completes it);
  P2s (dated markers, SEL gloss, README stub links, floor-vs-cap).

**Round 8 (P0-clean) then FOLDED (724 OK):** dispute topology **resolved to _same serial_** (a dispute is two
accepted seals racing to one serial — the earlier seal buries the other branch _from the fork_; cross-serial can't
survive); the **"accepted" verdict-predicate sweep** completed corpus-wide; and a **NEW killswitch / forced-brick
rationale** landed (`kel/compromise.md` §killswitch + KERI §4): forging the rival seal at the live tip needs the
**signing key not the reserve** → reserve-gates-takeover / signing-key-only-bricks; a collision is irrecoverable →
the brick is **forced** (first-seen-final rejected — breaks convergence / grindable; **Mode-B kept**).

Details → `design-resume.md` (Live edge). **NEXT: round-9 dual-pass — briefs WRITTEN, ready to hand off**
(`vdti-holistic-review-9-{warm,cold}-brief.md` — validation of the round-8 fold; ★ pressure-test = the killswitch
rationale + the same-serial topology; rounds 1–8 archived) → fold findings → the SEL primitive.

**Earlier this session (post-PR#11).** The KEL primitive PR#11 is merged (history below). Since then, the **IEL primitive
went up as the OPEN PR #17** (branch `VDTI-16_iel-primitive`, checks passing — **mid-PR, not merged**): five IEL docs written fresh
(`log`/`events`/`merge`/`reconciliation`/`verification`) + the delegation stub, two dual-pass reviews folded. Plus
three cross-cutting changes, all folded into the same branch (we fix everything in the current context — Jason
commits):

- **Floor terminology (KEL + IEL + canon).** The overloaded "majority floor" split into **witnessing floor**
  (`> signers/2`, content-fork prevention, both primitives) / **authorization floor** (`t_govern`/`t_authorize
  > |roster|/2`, IEL governance) / **position gate** (the IEL applying the witnessing floor at its own position).
  `majority floor` is banned in both `.terminology-forbidden` files; `lint-terminology` is now **wrap-tolerant**
  (`scripts/lint-terminology.sh` pass 2, a perl slurp-match — a multi-word ban that wraps a line no longer slips
  through).
- **KEL `recovery.md` → `compromise.md` re-scope.** Renamed + retitled **"KEL Compromise & Structural Defense."**
  The recovery-mechanics + attach shapes folded into `merge.md`, cross-node races into `reconciliation.md`; the doc
  keeps the compromise model + reserve boundary + pre-seal verifiability + defense-layers. **Burial generalized to
  seal-advancer** (deliberate recovery = a `Rot`, for availability; incidental burial = any seal-advancer; a `Trm`
  buries then terminates). Fresh-eyes "In short" opener added.
- **Trust-tree direction (NEW convention) — COMPLETE across canon + design.** The **root of trust is the base** —
  device keys (KEL) at the bottom; identity (IEL) and data (SEL) compose **up**. Convention: **anchor = up, pin/floor
  = down, verifier resolves down to the KEL, KEL has no chain below it**; layer-stack diagrams `flowchart BT` (base on
  the left when horizontal). The exhaustive sweep ran across **both** surfaces — the canon's own `inv 4`
  (`Manifest-down + pin-up`) was the **seed** and was flipped too, so a canon-reasoning LLM can't re-seed it. The
  chain-position `at-or-below-seal` axis and the **delegation-graph** "walk up to the root delegator" are separate
  axes, kept.

**`make all` GREEN** (683 OK, 0 errors, prettier clean; 46 sanctioned forward-refs).

**Holistic dual-pass ROUND 1 FOLDED + archived (2026-07-10).** Cold **HOLD-2** + warm **HOLD-1**, all resolved — the
one real finding was the **half-applied trust-tree inversion** (above), fixed across canon + design; F2s folded too.
`make all` green (683 OK, 0 errors, prettier clean). Round-1 briefs + findings → `archived/`.

**Holistic dual-pass ROUND 2 FOLDED (2026-07-10).** Cold **HOLD-5** + warm **HOLD-1** — all findings folded
(`vdti-holistic-review-2-{cold,warm}-findings.md` §RESOLVED): the trust-tree regression driven to **zero** (the
bolded `floors/pins up` survivors), the KEL merge Forked-routing aligned to Matrix 4 (F3), the glossary added to the
reading order, "seal" glossed at first use, and the dense-doctrine sentences split. `make all` green (685 OK, 0
errors); every touched diagram `mmdc`-validated (exit 0).

**Post-round-2 keep-current polish (2026-07-11).**

- **`features/multi-party/documents.md` version-DAG diagram** — settled on `flowchart BT` with **"ancestor of"**
  lineage arrows (V0 base → vM top; docs above their SELs) + an explanatory **note**: literal `ancestors`
  (child→parent) arrows AND that build-up layout are inexpressible in one mermaid flowchart (arrow direction _is_
  the layout rank; only Graphviz `constraint=false` decouples them, which would clash with every other diagram).
  The note records it so the one non-linkage-faithful arrow is explained, not silent. `mmdc` renders confirmed by eye.
- **IEL keep-current** — the IEL docs are on the branch now, so stale "(forthcoming)" markers dropped (`protocol-doctrine`,
  `event-shape`); joint "SEL / IEL" refs re-attributed to the SEL side (SEL still forthcoming). **README completed:**
  IEL added to the reading order (items 15–20, incl. the delegation stub), dropped from the forthcoming list.
- **"landed" build-status vocabulary removed** surface-wide (README → "design surface"; `## Not yet landed` →
  `## Forthcoming` + TOC anchor; `event-shape`/`evaluation` drop "landed separately") — greenfield voice; the
  design-vocabulary "an event landed cleanly" stays (it names the model, not the doc build).
- **PR#17 body pushed to gh** with the trust-tree + `compromise.md` re-scope sections added.

**`make all` GREEN (691 OK, 0 errors, prettier clean; 46 forward-refs).**

**Governance → sealed/sealing rename FOLDED + committed (`4f6a1f7`, 2026-07-11).** The IEL threshold
vector prices two seal-advancing tiers (`t_govern` / `t_authorize`), so calling the whole seal-advancing
spine "governance" conflated the umbrella with the `t_govern` slot. The split: **`sealed`** =
state/spine/category/fork; **`sealing`** = event/kind/act/decision; **`seal`** = the marker;
**`governance`** reserved for the narrow roster/authority acts (`Evl` + federation `Wit`) — kills
(`Rev`/`Dth`) and terminal (`Trm`) are their own categories, `t_govern`-priced but not "governance".
Federation "pure case" → **always-sealed**. KEL general-burial broadened to `Rot`/`Wit`/`Trm`; the
"recovery is a plain `Rot`" doctrine kept. Two dual-pass reviews folded (a glossary **bridge** entry
defines the narrow `governance`). ~17 files.

**Term-search tooling — `scripts/grep-terms.pl` (2026-07-11).** Decoration- + wrap- + word-initial-case-
tolerant phrase search — usable directly for straggler sweeps AND wired into `lint-terminology.sh`
pass 2 (multi-word bans now catch `majority **floor**` / bold-hidden / sentence-cap forms). Reference
memory: `reference_grep_terms_tool.md`. Use it, not plain grep, on terminology sweeps.

**Holistic dual-pass ROUND 3 FOLDED — readability + consistency + refactor/pointers (2026-07-11).**
Cold + warm folded (`archived/vdti-holistic-review-3-*`). The governance-glossary self-contradiction
fixed; the **de-duplication** ask landed — prefix/SAID, threshold-vector bounds, synthetic-vs-digest
rationale, and the divergence/spine model each got **one owner** (`said.md` / `iel/events` /
`protocol-doctrine`), re-describers → gloss + pointer; a `protocol-doctrine` orienting box added.

**Holistic dual-pass ROUND 4 FOLDED — first-time-reader soundness + readability (2026-07-11).** Cold +
warm folded (`archived/vdti-holistic-review-4-*`, §Fold-outcome). Headline **F1 (warm, run at Opus):**
the federation threshold bounds looked non-jointly-satisfiable at `|roster| = 4, signers = 4` — a
**design-doc gap**, not a soundness hole. The canon already carried the fix (the federation
**exclude-self pool** `signers ≤ |roster| − 1`, plus its own joint-satisfiability proof); folded
**that** rule into `protocol-doctrine` + `iel/events` (NOT the reviewer's looser derived bound — it
would permit `signers = |roster|`, which exclude-self forbids). **Canon unchanged — already correct.**
Readability: glossary decoder fixed (per-log sealing set; ~8 new entries incl. seal-cap / locus /
rotation-reserve / content-rail); `sub-issue` repo-jargon swept to `(forthcoming)` corpus-wide (IEL
markers dropped — it landed); ~30 jargon / xref / voice fixes; the case-2/3 footgun prose lifted out of
the ASCII fences. **Then, on Jason's greenlight, the deferred P2 polish folded too:** the four wall
paragraphs reflowed to bullets (thesis layered-defense; protocol-doctrine post-seal-window / Termination
/ Retention), the deep internal repeats collapsed to pointers, and the Rust token generics glossed /
`Result<>` de-jargoned — logic / wording preserved, only structure changed.

**Post-round-4 conversational polish (2026-07-11) — committed on `VDTI-16`.** A run of Jason-driven
clarifications, each `make all`-green:

- **Mixed-chain framed by tier, not count** (`iel/{log,merge,reconciliation}`): "single-key content
  alongside a threshold sealed spine" → "tier-1 content alongside a tier-2 sealed spine" (+ "Like the
  KEL and SEL,"). All three chains are mixed; the split is **tier** (buriable vs terminal), orthogonal
  to count. "single-key" was a KEL-ism — the IEL is threshold on both rails.
- **Signature signs the SAID, not the full event** — stated plainly in `event-shape §Authentication`
  (agrees with `said.md` / `kel/verification`'s "over the SAID bytes").
- **Negative checks reframed O(1)-first** (`protocol-doctrine §Negative checks` + glossary ×2 +
  `iel/{verification,events,delegation}` + `policy.md`): the O(1) content-addressed read is the fast
  path, done **first** (present → killed); the fail-secure walk is the fall-through on a **miss**;
  fail-open opts out of it. Was mis-framed as "walk by default / O(1) = the fail-open mode."
- **Bound-trace correction (my error, Jason caught it):** on an O(1) hit, `Trm.pin` (= the killing
  `Rev`/`Dth`'s `previous`) points straight at the kill, so the `bound` is read from that `kills[]`
  directly — no exhaustive scan. (I'd wrongly claimed the hit needs a full walk for the bound.) Fixed
  in the three `iel/*` spots + noted in canon `vdti-area-delegation.md`.
- **`iel/delegation.md` de-stubbed** — the "_Forthcoming_ / diagram ahead of prose" intro retired;
  it's the landed **single-hop** grant-and-rescission primitive (multi-hop walk → `verification.md`;
  document-authorization use → `policy/documents.md`). README reading-order line updated.
- **PR #17 body refreshed + pushed, then archived** (`archived/pr-17-body.md`).

`make all` GREEN (**714 OK**, 0 errors, prettier clean).

**NEXT = ROUND-5 complete dual-pass holistic review.** Briefs ready:
`vdti-holistic-review-5-{warm,cold}-brief.md` — a **complete** review (all axes: soundness /
consistency / completeness / readability), each running **Fable** (property-framed, no adversarial
language). Warm reads the canon and owns **fidelity-to-canon**; cold reads **design-only** and owns
**standalone soundness / self-sufficiency**. Jason launches the two agents; I fold findings. PR #17
(`VDTI-16`) is committed through the polish above, body current on gh. Then the SEL primitive per
`vdti-1-roadmap.md` (SEL-fresh → policy → federation → services → features).

---

### Historical — PR#11 (KEL primitive) reconciliation (merged 2026-07-10)

**The redesign is landed on both surfaces.** `docs/canon/` (14 files) is COMMITTED + whole-canon SHIP-reviewed
(first-seen + two-tier + fail-secure + layering + SS-3). And now the landed **`docs/design/` docs are reconciled
to it and committed** — the implementer's 6-chunk one-pass: first-seen + two-tier + **four-state** + formalized
single-word merge outcomes + fail-secure revocation + credential = a direct-anchored SAD + no direct mode + the
verdict-recoupled effective-SAID synthetic. The designer's matching **four-state / merge-outcome canon backport**
(area-kel §1 + vdtid §1e) is also done. Spot-checked strong (big residue gone; `privileged`→`sealed` clean;
`policy/documents.md` landed fail-secure + the C-1 counter-example).

**Reconciliation + the 8 folds are COMMITTED** (the first dual-pass returned MERGE/MERGE; folds = stale-tier
`1/2/3`→`1/2` · KEL heading `5 kinds (+ Fcp variant)` · doc-member `Trm` `grant-doc`→`rescind-doc` · `Empty` vs the
four live-chain states · below-seal attach-position note · Matrix 2 "no Disputed source" row-note ·
state/`region()`/`effective_said` correspondence table · `Terminated`/`Terminal`/`Trm` disambiguation; canon fallout
checked — none). **`make all` GREEN** (0 errors, 527 OK; 31 tolerated forward-refs). This session also **rewrote
PR#11's title + body** (branch `VDTI-10_kel-primitive`) to current reality and **merged** the `.working/` KERI
comparison into `docs/canon/supplemental/vdti-keri-acdc-comparison.md`.

**FINAL confirmation dual-pass RETURNED — MERGE / MERGE.** The 5 real findings folded (`make all` green, 529 OK); the
two eye-items resolved — (A) the seal-cap phrasing (Jason 2026-07-10): the **expression** `parent.serial >= seal_serial`
stays (the canonical-extension gate; an `event.serial` swap would misframe it), but invariant 5's **framing** was
imprecise and was **reframed** (inv 5 in reconciliation.md + canon `vdti-area-kel` + the `.terminology-forbidden`
mirror) — refusal-**as-a-canonical-extension** is unconditional, the refused event's **disposition splits**
(strictly-below → `Sealed`/`Disputed`; a sibling at the seal's own serial `v_{seal−1}` is a retained live fork, not a
locked-portion rejection — the cap bounds content extended **from** the seal, not a sibling to it); and (B) the
model-stale **`iel/delegation.md`** stub is **fixed**. `make all` green. Briefs + findings + `pr-11-body.md` →
`archived/`.

**Read on re-entry:** `design-resume.md` (the authoritative Live edge — full current state) → this file →
`docs/canon/` (authoritative). **On resume:** the reconciliation PR (#11, KEL primitive) is **MERGED to `main`**
(2026-07-10). _(The IEL-fresh PR that this pointed to is the still-OPEN PR#17 — see the CURRENT block at the top
for the live state and next steps.)_ Build order after IEL: SEL-fresh → policy → federation → services → features
per `vdti-1-roadmap.md`.

## The `.working/` surface (current)

- **`design-resume.md`** — the design session's bootstrap; read FIRST after a `/clear` or `/compact`. Stable
  role/process framing + the authoritative **Live edge**.
- **`vdti-1-roadmap.md`** — the phase index + build sequencing, synced to **gh#1** (you keep it current + push).
  The forward plan (build order + the pinned SS/C items) lives here; the reconciliation PR's briefs / findings /
  map are consumed → `archived/`.
- **`vdti-adversary-cases.md`** — the attack case-matrix (a coverage input; **may lag the canon — canon wins**).
  _(The per-log event-kind tables and the KERI/ACDC contrast are superseded — by the landed design docs and by
  `docs/canon/supplemental/vdti-keri-acdc-comparison.md` respectively → `archived/`.)_
- **Holistic reviews (rounds 1–8)** — all FOLDED and **archived** (`archived/vdti-holistic-review-{1..8}-*`, each
  carrying a §Fold-outcome / §RESOLVED disposition block; round 8 came back P0-clean). **Round 9 briefs are WRITTEN,
  ready for Jason to hand off** (`vdti-holistic-review-9-{warm,cold}-brief.md` — validation of the round-8 fold;
  ★ pressure-test = the killswitch/forced-brick rationale + the same-serial topology; holistic on all axes).

## Canonical surfaces (outside `.working/`)

- **`docs/canon/`** (14 files) — the machine-oriented, pressure-tested design canon; **authoritative**. Start at
  `vdti-invariants.md` (load-bearing) + the `vdti-area-*.md` notes; `docs/canon/README.md` orients.
- **`docs/design/`** — the human-facing **landed** design docs; **being reconciled to the canon** (phase-2 — see
  the map). When it and the canon disagree, the canon wins.
- **`../MODEL.md`** — the repo-root plain-english model (greenfield).

## Don't touch

- **`warm-resume.md`** — a review session's bootstrap. Do not edit or move.
- **`implementer-resume.md`** — the implementation agent's own bootstrap + progress tracker (its session). Read it
  on resume for the tracker; do not edit it.

## Archive

`archived/` holds the full historical trail — the redesign's round-by-round reviews + capture (the first-seen +
fail-secure rework; the effective-SAID / content-fork-prevention / federation-witnessing-remodel arcs; the
keep-all-data divergence rework; the KEL primitive (PR #11) + the vdti#12/#13 doctrine-land; and the large body
of pre-reshape design — policy DSL, pinning, credentials, KEL build, old service stubs). Area notes citing
"design-pass §X" / "keep-all-data §X" → look in `archived/`.

**Rule: a doc lives on this surface only while it is current. The day it's superseded, move it to `archived/` —
don't leave drift. Drift is what makes a fresh session (and its sub-agents) confidently wrong.**
