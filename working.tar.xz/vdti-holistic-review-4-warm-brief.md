# Review Brief — Holistic round 4 · SOUNDNESS (first-time reader) pass

**You are a careful reviewer reading the VDTI design docs for the first time, one effort level up.**
Your focus is **soundness**: as the design is presented to you, verify that its **stated properties
actually follow from the mechanisms it describes**, and that the docs are **mutually consistent**.
Read the **actual current files** in the `README.md` reading order; quote `file:line`; **report-only**
→ a durable findings file.

**Framing.** This is a property-verification pass. Confirm each property below holds as the docs
describe it; flag where a stated property is not established by the rule, where two docs disagree on
a case, or where a case enumeration is incomplete. State findings as properties, rules, and cases.

## The load-bearing properties to verify

For each, confirm the mechanism the docs describe actually yields it; note where it is asserted
without support, or stated inconsistently across docs:

1. **End-verifiability** — any verifier determines system-wide state (forked / disputed / terminated)
   from the **data alone** plus the trusted federation set, trusting no service or peer.
2. **Fail-secure default** — when state cannot be determined with confidence, the outcome is refusal,
   not a guess. (Includes the negative-check / positive-lookup fail-secure-vs-fail-open split.)
3. **Compromise is permanent; authority belongs to current state** — pin-to-current, floored per
   chain; below-seal validity stays final regardless of later divergence.
4. **The seal is the trust boundary** — everything at-or-below the last seal is final; new trust
   requires clean-sealed-past state.
5. **Divergence resolves by tier, data-locally** — a content fork is recoverable (burying
   seal-advancer); **≥ 2 sealed branches** past a fork is terminal (reincept); the verdict is a
   branch-level fact any node walks from retained events, never delegated to the federation.
6. **Structural authorization** — a chain event is authorized by its own key state / threshold /
   owner; policy governs documents only, never chain events.
7. **Two-tier capability model** — T1 signing key / T2 rotation reserve; tiers are **orthogonal** to
   the threshold-vector counts.
8. **Kills are sealed; validity bounds are contiguous** — a revocation / rescission is permanent on
   arrival and read forward-only.
9. **Federation convergence** — all honest nodes that hold the same events converge on the same
   effective SAID; the synthetic is set-independent (flood-stable).
10. **Threshold-vector bounds hold** — the security floor, recoverability ceiling, authorization
    floor, never-emptied floor, roster cap, and the federation witness-config cap are individually
    consistent and jointly satisfiable.

## What to check (as a first reader following the argument)

- **Does each claim follow from the stated rule?** When a doc asserts a guarantee, is the mechanism it
  just described sufficient to establish it — or does it lean on something unstated / stated only
  later? Flag the gap with the property and the missing step.
- **Do the docs agree?** The same case (e.g. `{Evl, content}` at a fork; a below-seal straggler; a
  federation `{Wit, Wit}`) should resolve identically wherever it appears (`protocol-doctrine`,
  `event-shape`, the `kel/*` and `iel/*` sets, the `reconciliation` proofs). Flag any two passages
  that would yield different outcomes.
- **Are the case enumerations complete?** The `reconciliation` docs claim to be exhaustive
  correctness proofs. As a first reader, check the enumeration axes cover the stated space (per-node
  state × submission shape × cross-node state) — flag a combination that is asserted-handled but not
  shown, or a row whose outcome doesn't match the rule stated upstream.
- **Do the recent refactors preserve soundness?** Several mechanisms were just reduced to a
  gloss + pointer (prefix/SAID → `said.md`; threshold bounds → `iel/events`; synthetic rationale →
  `protocol-doctrine`; divergence detail → `protocol-doctrine`). Verify each **pointer target
  actually establishes** what the gloss now only summarizes — i.e., the collapse didn't drop a
  load-bearing step.
- **Is the narrow `governance` definition self-consistent with its uses?** The glossary now defines
  `governance` = the roster/authority acts (`Evl` + federation `Wit`), with kills/terminal as
  separate categories. Check every `governance` in the docs reads true under that definition.

## Scope

The `README.md` reading-order design docs (`docs/design/`): `system-thesis`, `glossary`, the `sad/`
substrate, `protocol-doctrine`, `event-shape`, the `kel/*` and `iel/*` primitives, `policy/*`. The
`reconciliation` docs are the correctness proofs — weight them.

## Output

- Save findings to `.working/vdti-holistic-review-4-warm-findings.md`.
- Per finding: **severity** (P0 = a stated guarantee not established / two docs contradict on a
  load-bearing case · P1 = a gap in the argument or an incomplete enumeration · P2 = imprecision),
  the **property** at issue, `file:line`(s), the quoted text, and what would make it hold (describe —
  do not edit).
- **Report-only.** **Done-criterion:** findings saved; confirm `make all` exits 0 (it does now — a
  red lint is itself a P0 finding).
