# VDTI event kinds — the logs under two tiers + first-seen

**What this is.** The event-kind tables after the two-tier collapse (signing key / rotation reserve) and
the first-seen pivot. A reference for the canon reconciliation; **supersedes the pre-reshape kind lists**
in the area docs. Derived from `vdti-area-kel.md` / `vdti-area-iel.md` / `vdti-area-sel.md` + the settled
decisions; **flag anything that looks off.** (2026-07-07)

## The one distinction that runs through every log

Each log splits its kinds into exactly two buckets:

- **Ordinary activity** — what the everyday signing key alone can do. **The only buriable/recoverable
  kind.** Two of these conflicting is a *recoverable* fork.
- **Key change** — anything that needs the **rotation reserve**. Never overturned. Two of these
  conflicting is **terminal**.

The two-key change means **every key change is now single-signed with the rotation reserve** (which reveals
the new signing key). No dual-signing, no recovery key — "key change" just means "needed the reserve."

## The federation is a variant, not a separate thing

The "federation" is not a new primitive — it's the **federated variant** of the KEL and the IEL, rooted
with **`Fcp`** instead of `Icp`. So there are five logs in two groups: the three **user-facing** logs, and
the two **federation-infrastructure** logs. (A plain SEL has no federated form — the federation issues no
artifacts.) *"Federated" here means the federation's own infrastructure, not a user log that merely binds
to a federation.*

---

# User-facing logs

## Key log (KEL)

| Kind | Plain name | What it does | Bucket | Signed with |
|------|-----------|--------------|--------|-------------|
| `Icp` | incept | start the identity | root | the inception key |
| `Ixn` | interact | ordinary activity; hosts anchors | **ordinary activity** | current signing key |
| `Rot` | rotate | change to a new signing key | key change | the rotation reserve |
| `Wit` | witness | change witnesses / federation binding (a *rebind*) | key change | the rotation reserve |
| `Trm` | terminate | end the identity | key change (final) | the rotation reserve |

Dropped: `Ror`, `Rec` — both existed only for the recovery key. Recovery is now just a `Rot`.

## Identity log (IEL) — single- or multi-member

| Kind | Plain name | What it does | Bucket | Threshold |
|------|-----------|--------------|--------|-----------|
| `Icp` | incept | start the identity log | root | — |
| `Ixn` | interact | ordinary activity; anchors artifacts | **ordinary activity** | `t_use` |
| `Evl` | evolve | change the roster or thresholds | key change | `t_govern` (outgoing) + consent of added |
| `Ath` | authorize | authorize a party — delegate, or grant doc-membership | key change | `t_authorize` |
| `Rev` | revoke | revoke an owned artifact (seals its `Trm`) | key change | `t_govern` |
| `Dth` | de-authorize | rescind a grant / delegate | key change | `t_authorize` |
| `Wit` | witness | change witnesses / federation | key change | `t_govern` |
| `Trm` | terminate | end the identity log (freezes its artifacts) | key change (final) | `t_govern` |

Dropped: `Rpr`, and the `t_recover` threshold with it → `{t_use, t_govern, t_authorize}`. Eviction of a
bad member is a plain `Evl` with a roster `cut` (one key change buries + evicts).

## Artifact log (SEL) — one per credential/document, single owner

| Kind | Plain name | What it does | Bucket | Threshold |
|------|-----------|--------------|--------|-----------|
| `Icp` | incept | create the artifact | root | `t_use` |
| `Ixn` | interact | ordinary activity / content | **ordinary activity** | `t_use` |
| `Pin` | pin | re-pin to the owner identity (fallback first event) | **ordinary activity** | `t_use` |
| `Gnt` | grant | grant doc-membership (editor/commenter) | key change | `t_authorize` |
| `Trm` | terminate | end the artifact (revoke / close) | key change (final) | `t_govern` |

Dropped: `Fld` (its jobs — batching, bounding, finality — move up to the owner identity) + `Rpr`. A plain
content artifact has no native re-seal; its content forks resolve **cross-layer** (the owner buries its
fork and the dead line descends across the pin).

**A credential is NOT a SEL — it is a direct-anchored SAD** (issuance SEL dropped, B1 fail-secure rework
2026-07-09). The issuer anchors the **issuance commitment `hash('{CRED_ISSUANCE_TOPIC}:{issuer}:{cred.said}')`** (a
flat, domain-qualified hash) on its own IEL via an `Ixn` (`t_use`); that anchor **is** the validity proof (no
cred-SEL, no `{Icp, Pin}` scaffolding, no "serial ≥ 2 inert" machinery; **custody rule:** direct-anchor an immutable
presented SAD, SEL-wrap anything mutable / looked-up). The cred is immutable and **presented by the holder**, never
looked up by address. **Revocation = a `kills[]` declaration on the issuer's witnessed IEL `Rev`** (`t_govern`) + a
`{Icp, Trm}` lookup SEL: the `Rev` declares `kills[] = [{ target }]` with `target =
hash('{CRED_REVOCATION_TOPIC}:{issuer}:{cred.said}')` (a flat hash ≠ the lookup SEL's two-pass prefix — distinct
topics per kind, never a shared one), and the sealed lookup-SEL `Trm` carries only its pin. Detection is
**fail-secure by default**: walk the issuer's fresh IEL and forward-match the `target` in each `Rev`/`Dth`'s
`kills[]` — in some → revoked; in none on the fully-walked fresh chain → not-revoked (hiding a revocation needs a
stale IEL, which the freshness gate already refuses — inv 8/10). `kills[]` is **opaque to the IEL** (placement is
the only structural rule). A content-addressed **fail-open** lookup is a deliberate opt-out (vdtid for latency; app
servers on a walk-timeout). Privacy: **`cred.said` appears nowhere raw** (issuance, kill target, SEL prefix/said are
all hashes of it). *(Reverses the create-on-revoke best-effort model — its `attribute-all` escape hatch broke,
cold/warm re-review-2 F1; see `vdti-b1-failsecure-rework.md`.)*

---

# Federation-infrastructure logs

## Federated KEL — a federation witness's own key log

| Kind | Plain name | What it does | Bucket | Signed with |
|------|-----------|--------------|--------|-------------|
| `Fcp` | fed-incept | inception marker — roots a witness's key log (self-attested at genesis) | root | the inception key |
| `Ixn` | interact | ordinary activity | **ordinary activity** | current signing key |
| `Rot` | rotate | change to a new signing key | key change | the rotation reserve |
| `Wit` | govern | federation **governance** — anchors the Federated IEL's `Wit` | key change | the rotation reserve |
| `Trm` | terminate | end the witness's key log | key change (final) | the rotation reserve |

Same working kinds as a user KEL, with two differences: it roots with **`Fcp`** (at genesis there is no
federation to bind to yet), and its **`Wit` means governance**, not a user rebind. Its first rotation
anchors the Federated IEL's own inception.

## Federated IEL — the federation's identity log (restricted)

| Kind | Plain name | What it does | Bucket | Threshold |
|------|-----------|--------------|--------|-----------|
| `Fcp` | fed-incept | inception marker — founds the federation | root | — |
| `Wit` | govern | the one governance kind — roster changes + witness rotation + the clock | key change | `t_govern` |
| `Trm` | terminate | end the federation | key change (final) | `t_govern` |

**No ordinary activity at all** — every event is a key change, so **every federation conflict is
terminal** (the "record both, raise the alarm" side of the rule). It takes several members to move, so a
conflict here is a real schism, never one stolen key.

---

## Open detail for the reconciliation

The **kind-strict anchor matrix** needs one pass under two tiers: several IEL/SEL key changes used to be
anchored by the KEL's now-deleted `Ror`/`Rec` (e.g. the federation `Trm` was `Ror`-anchored). With those
gone, each such anchor re-homes to `Rot` or `Wit`. Not hard, but a deliberate sweep, not a guess — I'll do
it when we encode and flag any case that doesn't re-home cleanly.
