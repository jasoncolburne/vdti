# VDTI witnessing + storage hardening — two design threads (capture)

**Status: DESIGN CAPTURE (2026-07-08), NOT yet reviewed or encoded.** Two ideas worked through with Jason
this session, adjacent to the first-seen/effective-SAID work but a distinct workstream (the witness-receipt
+ SAD-store layer — `federation-witnessing` / `vdtid-services`). Both need grounding against the current
receipt/SAD model + a review before they enter the encode. Companion to `vdti-first-seen-reconciliation.md`
(the settled+reviewed first-seen encode).

---

## 1. Receipt-encoded threshold — cheap witnessed-detection

**The idea (Jason).** Encode the **witness-config threshold** in each witness receipt, so a node determines
"is this event witnessed?" by **counting `threshold`-many agreeing receipts** (agreeing on **event SAID +
threshold**) — with **no chain walk** to compute the threshold. Today a node must resolve the chain's
witness-config to know the bar before accepting an event, which is a lot of work per gossiped batch. The
threshold `{said, threshold, signers}` is already chain-committed (the `witnesses` manifest-role SAD on
`Icp`/`Wit`, `federation-witnessing:319`); receipts just don't carry it yet (they're bare attestation data,
`:197`).

**What it buys.** Detection becomes a pure receipt count (no chain read). It does **not** eliminate the
chain read — it *defers* it to pull-and-validate (once, which you do anyway to use the event). The win: you
don't walk the chain just to decide whether an event is worth pulling / processing.

**The match check (Jason, load-bearing).** When you finally pull the event, verify the receipts' threshold
**matches the chain-authoritative threshold** (the witness-config SAD in effect at that position) — **never a
self-asserted field** (else a *consistent* lie — event says 2, receipts say 2, real config is 4 — passes).
Since the threshold is a committed SAD, that value is well-defined. **Exact match; mismatch → invalid, even
if the receipts' value is *higher***:

- **Receipts < real:** an adversary reports a low threshold so fewer receipts "witness" it → forgery. Caught.
- **Receipts > real:** still invalid — (a) *faithfulness*: the threshold is a single authoritative value; a
  receipt asserting a different one, either way, is a witness **misrepresenting the event**, and a witness
  that lies about one field can't be trusted on the rest ("higher = more secure" is a false intuition); (b)
  *liveness/DoS*: an inflated threshold makes honest nodes wait for receipts that never come → stall — and
  "all receipts agree on `(SAID, threshold)`" makes an inflated receipt **disagree** with honest ones →
  detected, not silently trusted.

**The position-deterministic edge.** The threshold a receipt encodes must be the config **in effect at that
position** (committed at-or-before that serial). A witness on a **stale** config (a lagging `Wit` rebind /
federation-governance change) produces a receipt whose threshold won't match → it fails both "all agree" and
the match check → discarded. Contained — a liveness cost around config changes, not a safety hole. Composes
with the existing **key-window** gate (`:108-117`): a receipt now needs {valid signature, inside its
key-window, threshold-matches}.

**Keep straight:** this is *witnessed*-detection (is it backed?), distinct from *disputed*-detection
(`receipts enumerate branches; the data decides`, `:305`). The receipt-threshold makes "is it witnessed /
should I pull" cheap; disputed stays data-local (hold + re-validate ≥ 2 sealed branches). They compose.

### The gossip / relay mechanics (reconciled)

Gossip is **witness-only and encrypted** (the mesh *is* the federation roster, `:286`) — an outsider can't
observe it (else correlation). So a user learns anything about the mesh only by asking a **witness**; there
is **no non-witness observer**. The event **body** never floods — it moves by targeted transfer; only
receipts (small) flood.

1. **User → their preferred witness** (any node; random selection means it's usually *not* selected — fine).
2. **The receiving witness computes the selection locally** from `(prefix, serial)` (in the event) + the
   roster it holds as a federation member — a simple deterministic computation (Jason) — and **routes the
   body to those ~`signers` selected witnesses**.
3. **The selection receipts** (encoding the threshold) and **sub-gossips the body among themselves** (`:272`).
4. **Receipts flood the witness mesh.**
5. **The user's preferred witness answers "witnessed?" from the receipts alone** — `threshold`-many agreeing
   for the event SAID — **no body, no chain read.** The user hears "yes" → safe to delete old keys / commit
   the next event to their log.
6. **The body is pulled on-demand** only when the *content* is actually wanted (a witness serving a user who
   requests the event pulls it then, guided by the receipt-threshold).

**Not load-bearing that the user reach the selected witnesses** (Jason): any witness relays the body in and
reports the witnessed-status out; the selection is an internal mesh detail the user never touches.

**To pin at encode:** receipt structure gains `threshold` (+ the `(SAID, threshold)` agreement + match rule);
`federation-witnessing §1e`'s "counts toward an event's threshold" (`:272`) picks up the match check; the
position-deterministic-config + stale-witness-receipt rule stated; the routing-computed-on-receiving-node
mechanic in `vdtid-services`.

---

## 2. SAD-store kind filter — close the SAID→prefix correlation oracle

**The attack.** Event SAIDs float free of their prefix by design (`said ≠ prefix`; the opaque `anchors[]`
`said(v1)` commitment). From a **public** issuer IEL (readable by anyone with the issuer prefix) you can
harvest every `anchors[]` SAID (commitments to the issuer's cred-SEL events). Those are meant to be dead
ends. But **if the SAD store answers a fetch-by-SAID for an event body**, the attacker looks each one up →
gets the SEL v1 / `Icp` → recomputes `derive(owner, topic, data)` → recovers the cred-SEL prefix. Across all
the issuer's anchors, that **enumerates and de-anonymizes every credential it issued** (and holders), using
VDTI's own store as the inversion oracle.

**The fix (Jason): detect an event by `kind` and disallow it from the SAD store.** It enforces inv 16 (logs
are **prefix**-addressed, never fetched by SAID) *at the storage write boundary* — nothing legitimate needs
an event body in the SAD store (events live in the chain log). So fetch-by-SAID **physically cannot return an
event**, and a bug/malicious submit can't prime the oracle. Robust against the obvious bypass: stripping the
`kind` changes the content → changes the SAID → no longer matches the attacker's harvested *real* event SAID
→ lookup misses; the real event SAID always carries the real kind.

**Make `kind` required on SAD data (Jason).** Turns the hardening into a clean **per-kind store policy**
(allow content kinds, reject event kinds, mark any kind "opaque → not fetchable-by-SAID") and makes the kind
the authoritative classifier (no fragile shape-match). Requirements: **event-kinds and content-SAD-kinds in a
cleanly-partitioned value space** so "is this an event?" is unambiguous; making it required changes those
SADs' SAIDs (free at design stage); a `kind` on a public/fetchable SAD leaks nothing (type already public),
an opaque one isn't fetchable to read the kind. **Verify `kind` is actually used everywhere** against the SAD
spec before committing (Jason "thinks" it is).

**Preferred over the availability alternative (Jason).** SADs already carry availability (`nodes: []` → won't
propagate); the alternative would be to add an availability field to *events* to keep them out of the store.
The **kind filter is the better solution** — don't add an availability field to all events.

**Write it as the principle, not a bare kind list:** *"nothing whose SAID must stay opaque is fetchable by
SAID from the store"* — so a future SAD type that floats free is caught too. **Scope to events (by kind)
now** — the manifest-role SADs (roster/threshold delta, `pins`-SAD) also carry identifiers (member KEL
prefixes / tip SAIDs) but their SAIDs are reachable only *through* a chain you already have the prefix for
(not free-floating like `anchors[]` commitments), so they give the attacker nothing the IEL didn't; events
are the sharp case.

**To pin at encode:** the `vdtid-services` SAD-store write path rejects event-kinded submissions; inv 16 gains
the enforcement note (+ the "opaque-SAID ⇒ not SAID-fetchable" principle); `kind` required on SAD data
(pending the usage check).
