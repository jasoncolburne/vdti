# VDTI in plain english — running capture

**What this is.** Plain-language statements of the design rules, captured as we lock them so they survive
compaction and compile into a high-level overview at the end. This is the *narrative* layer — the
concepts, not the structural encoding. Structural detail lives in the event-kind tables
(`vdti-event-kinds.md`) and, once reconciled, the canon. (`vdti-subchain-model.md` is a **superseded
working draft** — it predates the decisions captured here; don't rely on it.) **Status: settled items only; append as we lock more.**
(Started 2026-07-07.)

---

## The shape of the thing

An identity is a **chain**: a numbered list of events that only its controller can extend. Some events
are ordinary activity; some change which keys are in control. **Witnesses** — servers that vouch for events
by signing off on them — make the history hard to rewrite: an event is trusted once enough witnesses have
vouched for it. A **federation** is a group of witnesses that serves a set of identities together. **Every identity is
federation-witnessed — there is no unwitnessed mode**; witnessing is what every guarantee below rests on.

## Identities and devices

An identity isn't a single key, and it isn't a group of people — it's **one person's identity**, an **IEL**:
a threshold over the **devices that one person controls**. The smallest one is a single device (a
*degenerate* identity — what a witness spins up from one key just to send and receive messages). That's the
valid floor.

For a real identity you want **more than one device.** That's where resilience comes from: if a device is
lost or compromised, the others vote it out and carry the identity forward. There's no separate "cold
reserve" doing this job — the guarantee comes from having other live devices on the same identity. You
*could* hold one device's rotation key somewhere separate, but it doesn't help — it just makes your own
recovery slower. More devices, not split-up keys.

Two boundaries to be clear about. **The threshold is over *devices*, not people** — an IEL's roster is your
own device set, and a device-threshold is not an identity-threshold. Multiple *people* (a team, an org)
aren't members of one IEL; that's the **policy** layer (below), which composes several identities. And these
are *recommendations*, not walls the system enforces: nothing can stop two people from sharing a key or one
device from hosting several identities — but the intended model is **one person ↔ one IEL ↔ their devices.**

## The two keys on a device

Each device holds two secrets, both in its hardware — no cold storage, no separate custody:

- The **signing key** — the everyday key, for ordinary activity.
- The **rotation key** — lets *that device* change its own signing key, e.g. if you suspect the signing
  key has leaked.

(There used to be a third, deeper reserve to protect the rotation key; it's gone — it protected nothing
you couldn't protect more simply.)

The split lets a device heal a suspected signing-key leak by itself. But healing a *fully* compromised
device — where an attacker can use both keys — is the **identity's** job, not the device's: the other
devices vote it out. So on a single-device identity a full compromise is the point of no return; on a
multi-device identity it isn't — which is exactly why you bind more than one.

## The core rule: conflicts

Normally there's one event per step in a chain. Sometimes two show up claiming the same step — a
**conflict**. What to do about the second one is the heart of the design. It turns on two questions, asked
in order — but first, one distinction that trips people up:

**Witnesses aren't "the group."** Witnesses are the servers that attest to *every* event; they're the ones
*applying* these rules. Where "the group" matters below, it means the identity's **own keys that had to
agree** to author the event — a user's own devices, or the federation's own members — never the witnesses.

**Question 1 — is it ordinary activity, or a key change?**
- **Ordinary activity** → witnesses take the first they see and drop the copies. Always. A conflict here is
  recoverable (the next key change buries the loser), so it never alarms.
- **A key change** → could be terminal (you can't un-change a key), so ask Question 2.

**Question 2 (key changes only) — could one key have signed the competing version, or did it take several
of the identity's keys agreeing?**
- **One key could** → take the first, drop the copy. This is **a device rotating its own key** (a KEL
  rotation) — and also a **solo identity's governance**, since its roster is one key, so one key authorizes
  a roster change. The trap: the key a device signs with today is the same secret that made its most recent
  key change, so a stolen signing key could forge a second version — and a stolen key must stay
  *recoverable*, not terminal. (Inert anyway: the stolen key can only forge *after* the real change revealed
  it, by which point the witnesses have already sealed that position.)
- **It took several** → keep both, raise the alarm. This is **a roster change on a multi-device identity**
  (several devices must agree — `t_govern ≥ 2`) or **anything the federation does**. No single stolen key
  can fake it, so a second version is proof the group was subverted — exactly what you want surfaced.

**Both kinds of identity live on both sides.** A multi-device personal identity uses "take the first" for
its devices' own key changes and "raise the alarm" for its group decisions. The **federation is the pure
case** — no ordinary activity, every decision a group decision, so *every* federation conflict is an alarm.

The one-line test: **could a single stolen key have faked this conflict, or would it take a group
betrayal?** Faked → throw the fake away and recover. Group betrayal → surface it loudly.

(From a single witness's seat it's simpler still: it checks its own history and won't sign twice at one
step. We only plan for a second getting backed because we can't assume every witness is honest — and a
corrupted one that does leaves its signature on both as the evidence.)

## What "disputed" means

**Disputed** is when a conflict is visible to everyone in the data — both versions have enough backing to
be trusted. Same word on every kind of chain, and it arises two ways: on a **group decision** the design
*records both* on purpose (the "raise the alarm" rule), so a subverted group surfaces at once; on anything
else honest witnesses take only the first, so a second version reaches backing only if an attacker
*corrupts enough witnesses* to force it — and forcing it leaves their double-signatures in the data as
proof. Either way, what you *do* about it depends on which kind of event conflicted:

- **Two pieces of ordinary activity** → recoverable. Your next key change keeps the real line and drops
  the other.
- **Two key changes** → not recoverable. You can't un-change a key, so you start a fresh identity.

## The fingerprint of a conflict

Every chain has a short **fingerprint** of its current state — a compact value two people can compare to
check they're looking at the same identity in the same state. When the chain is healthy there's a single
current tip, and the fingerprint is just *that tip* — its real identifier. When there's a conflict there's
no single tip, so the fingerprint becomes a **marker** that says *"no single tip here, and which kind of
conflict"* — temporary or permanent. That's all it needs to say:

- **A temporary conflict** (ordinary activity — recoverable): the marker says *"conflict here, the
  recoverable kind."* It clears itself — the next key change buries the loser and the fingerprint drops
  back to the single surviving tip.
- **A permanent conflict** (two key changes — not recoverable): the marker says *"conflict here, the
  terminal kind"* — start a fresh identity. Everyone holding the two clashing key changes reads the same
  verdict, so it doesn't matter *which* versions each one saw; the outcome (start fresh) is the same.

Crucially the marker does **not** try to spell out the competing versions. It can't, safely: if enough
witnesses are corrupted they can keep minting fresh competing versions, so any value that *listed* them
would keep changing and two honest parties would never settle on the same fingerprint. A plain marker is
**stable** — it doesn't move when a corrupt witness adds another version, and it doesn't need to, because
nobody has to assemble the full set: a recoverable conflict is cleared by the owner's key change (which
buries *every* losing version at once), and a permanent one just means "start fresh." Hiding a version
still can't help an attacker — someone who has only seen the single tip computes a *different* fingerprint
from someone who has seen the conflict, so the difference itself triggers a fetch and the conflict surfaces.

One line: **healthy → the fingerprint is the single tip; conflict → a stable marker of "no single tip, and
which kind" — never a list of the competing versions (that couldn't be kept stable, and isn't needed).**

## Recovery is just a key change

There's no special "recover" or "repair" operation. When your signing key is stolen, you rotate to a
fresh key, and that single rotation does everything: it locks the thief out (they don't have the new key)
and it buries their activity (anything not on the line leading to your rotation is discarded, and so is
anything built on it). You rotate at the **first** event that isn't yours, so however long a run the thief
piled on, it all hangs off that one point and dies at once — you go for the root, not their tip. Burying is
automatic and complete — everything below your key change that isn't on
the surviving line is dead, and anything grown from a dead point is dead too. No recovery key, no special
event, nothing to prove.

That's the single-device story — you rotating your own key. On a multi-device identity there's a second
kind: when a whole *device* is compromised (an attacker can use both its keys), the *other* devices remove
it — and that removal is itself a key change too (next section). Same idea at two levels: **recovery is
always just a key change that buries what came before.**

## Kicking out a bad member

On a group identity, when one member is compromised the others remove them with a single governance
change — a change to who's on the roster. Because a roster change is itself a key change, it drops the bad
member and buries whatever mess they made in one step; there's no window where they're half-out but still
dangerous. (This needs at least three members — with two, a compromised member can freeze you, so
two-member identities are flagged "add a third key.")

## Your devices, other people, extended reach — three different layers

Three distinct things get confused as "adding someone," and the design keeps them apart:

- **Your devices → the roster.** An identity's roster is the **devices you control** — a small, bounded set
  of co-signers that can change keys and govern. It is a threshold over *devices*, and it stays small on
  purpose: governance is easy to reason about and cheap to verify. It is **hard-capped at 32** as a DoS
  backstop — the verifier rebuilds the roster in memory as it walks, so an unbounded pile of adds would be a
  resource-exhaustion attack; any change that would push the live set past the cap is rejected. The intended
  size is *small*; the cap is just the backstop.
- **Other people → policy.** A team or an org is **not** members of one IEL — a device-threshold isn't an
  identity-threshold, and you can't collapse several people into one roster. Multiple parties are composed
  one layer up, in **policy**: it builds satisfaction rules like *"any 2 of Alice, Bob, Carol"* or weighted
  thresholds over the individual identities, and **each identity attests independently** on its own chain.
  That's where richer, weighted, multi-party governance lives.
- **Extended reach → delegation.** To hand authority to *many* downstream parties — sub-delegates, document
  editors, an org's wider reach — you don't grow the roster or write one big policy; you **delegate**: a
  separate, **unbounded** tree of grants, each revocable, with the root always able to pull the plug on
  anything below it.

Rule of thumb: **your devices = the roster (bounded); other people = policy (composed identities); unbounded
reach = delegation.** The roster stays small by design, which pushes scale onto policy and delegation — the
layers built for it.

## An issued artifact rides its owner's identity

A credential or document has its own little log, but every event on it is **anchored** to the identity that
issued it — each artifact event must be pinned to, *and named by,* a fresh event on the owner's identity
log. The identity log is both the artifact's clock and its authorization: an artifact event isn't valid
unless a matching identity event vouches for it, and an already-recorded identity event can't take on a new
artifact after the fact. Two things fall out, and they're the whole story:

- **An artifact can't go wrong on its own.** To write a competing artifact event, an attacker who stole the
  owner's key has to author a *fresh* identity event to anchor it — there's no way to hang new artifact
  content off an old, already-sealed identity point. So the attack always shows up as activity on the
  *identity*, at or after the point of compromise — never as a lone artifact fork the identity doesn't
  already reflect.
- **And it heals for free.** Because that malicious anchor sits at or above the compromise, the owner's
  recovery — a single key change at the first bad point — buries it, and every artifact event the anchor
  named dies with it: deadness spreads downward and crosses the anchor. No separate repair for artifacts,
  ever; recovering the artifact *is* recovering the identity.

So a stolen artifact-signing key is exactly as recoverable as a stolen identity signing key — it reduces to
the identity's own "rotate at the root and bury." Nothing new to learn.

## A credential is a document the issuer anchored, and revocation is a declaration on the issuer's own log

A credential is a one-time, immutable document. The issuer **anchors it** to its own identity log — one ordinary
entry that commits a **domain-tagged hash** of the credential's fingerprint (a tag that says "this is an issuance,"
then the fingerprint). That anchor *is* the proof it was validly issued: a credential with no matching anchor on
the issuer's current log was never really issued. There's no separate credential-log to maintain and nothing to
append (a thief who tries to scribble more achieves nothing). Issuing is ordinary activity, the cheapest key. **A
private credential stays private because its fingerprint never appears in the clear** — everything on the public
log (the issuance entry, and later a revocation entry) is a *hash* of it, and a private cred's fingerprint is
unguessable, so an onlooker can't work backward to it.

Revocation is a **declaration the issuer writes on its own identity log** — the same public, witnessed log a
verifier already walks and confirms is current in order to trust the issuer at all. To revoke, the issuer signs an
entry that names the credential (by a matching domain-tagged hash) and, for a delegate cutoff, how far back to
still honor. To check a credential you walk the issuer's **current** log and look for that name:

- **Named in a revocation entry** → revoked.
- **Not named anywhere on the fully-walked current log** → not revoked. This is a real answer, not a guess: being
  named is the *definition* of revoked, so "named nowhere" is exactly "not revoked". The only way to hide a
  revocation is to show you a **stale** log — and refusing a stale log is exactly what you already do before
  trusting the issuer at all. So revocation is **fail-secure by default**, riding the same freshness check as
  everything else.

There's also a **fast lookup**: the revocation entry doubles as a small content-addressed object a verifier can
fetch directly (one hop, no walk). A verifier can deliberately **opt down** to it for speed — the authoritative
node (which owns the data) uses it as its fast path, and a busy third-party server can fall back to it under a
time budget. That fast path *can* miss a withheld object (it fails open), so it's a chosen trade, never the
default: you opt down to it, never up.

This is **better** than the usual decentralized ceiling — KERI writes a revocation event to a log a verifier reads
locally, and a withheld one reads as "issued"; the web's OCSP soft-fails the same way. Here the revocation lives on
the issuer's already-witnessed log, so a careful verifier who confirms the log is current can't be fooled about
revocation without being fooled about the issuer's whole current state — and if it can't confirm that, it refuses.

## The one guarantee to remember: no silent forgery

The whole point of the system is this: **a break-in big enough to *force a forged branch* can't happen
quietly.** To make two competing versions both look real, an attacker has to get enough witnesses to
double-sign — and that is exactly what leaves the evidence behind: the witnesses that had to sign both are
sitting in the data doing so. So a forced fork is **always evidenced in the data** — the double-signed
receipts exist and can't be erased from the record. *Delivering* that evidence to a given party rides
receipt gossip: on a live identity it surfaces as a visible conflict (disputed); on a quiet one, an old
harvested signature can't be replayed onto a live chain (witness sign-offs only ever move forward in time).
The one caveat is **delivery, not existence** — a party eclipsed from the second branch stays locally
unaware until the receipts reach it, so the honest claim is "the evidence always exists," not "no party can
be unaware."

Be precise about what this does *not* cover. If an attacker steals the deepest reserve — the point of no
return — they don't need to fork at all: they can just *extend* the chain with a rotation to their own key.
Witnesses sign it willingly, as an ordinary next event. Nothing is forced, so nothing double-signs — it
isn't a conflict, and it isn't stale (the receipts are fresh). On a chain the owner is watching, the owner
sees a rotation they didn't make and raises it (turning it into a fork → disputed → start fresh). But on a
chain that's gone quiet, with no one watching, that takeover is **invisible to a third party** — it reads
as an ordinary rotation. So the honest guarantee is narrower: **no silent *forgery*** (no forced fork).
Catching a reserve-theft takeover on a dormant chain rests on **owner vigilance**, not on the witnesses —
and reserve theft is unrecoverable regardless, so the answer there is to start fresh.

And the outer edge, as always: an attacker who has corrupted *every* witness vouching for you at once
leaves no honest witness to trace it. That's the same limit every system of this kind has — if everyone
vouching for the truth is compromised, you've lost the trust you were building on.
