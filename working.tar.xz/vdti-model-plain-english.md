# VDTI in plain english — running capture

**What this is.** Plain-language statements of the design rules, captured as we lock them so they survive
compaction and compile into a high-level overview at the end. This is the *narrative* layer — the
concepts, not the structural encoding. Structural detail lives in the event-kind tables
(`vdti-event-kinds.md`) and, once reconciled, the canon. (`vdti-subchain-model.md` is a **superseded
working draft** — it predates the decisions captured here; don't rely on it.) **Status: settled items only; append as we lock more.**
(Started 2026-07-07.)

---

## The shape of the thing

An identity is a **chain**: a numbered list of events that only its controller can extend. Some events
are ordinary activity; some change which keys are in control. **Witnesses** — servers that vouch for events
by signing off on them — make the history hard to rewrite: an event is trusted once enough witnesses have
vouched for it. A **federation** is a group of witnesses that serves a set of identities together. **Every identity is
federation-witnessed — there is no unwitnessed mode**; witnessing is what every guarantee below rests on.

## Identities and devices

An identity isn't a single key — it's an **IEL**, and an IEL is a set of devices bound together. The
smallest one is a single device (a *degenerate* identity — what a witness spins up from one key just to
send and receive messages). That's the valid floor.

But for a real identity you want **more than one device.** That's where resilience comes from: if a device
is lost or compromised, the others vote it out and carry the identity forward. There's no separate "cold
reserve" doing this job — the guarantee comes from having other live devices on the same identity. You
*could* hold one device's rotation key somewhere separate, but it doesn't help — it just makes your own
recovery slower. More devices, not split-up keys.

Different jobs want different setups, so the design will recommend a few ready-made profiles — a solo
identity, a shared organizational identity, the federation itself — and developers pick the one that fits.

## The two keys on a device

Each device holds two secrets, both in its hardware — no cold storage, no separate custody:

- The **signing key** — the everyday key, for ordinary activity.
- The **rotation key** — lets *that device* change its own signing key, e.g. if you suspect the signing
  key has leaked.

(There used to be a third, deeper reserve to protect the rotation key; it's gone — it protected nothing
you couldn't protect more simply.)

The split lets a device heal a suspected signing-key leak by itself. But healing a *fully* compromised
device — where an attacker can use both keys — is the **identity's** job, not the device's: the other
devices vote it out. So on a single-device identity a full compromise is the point of no return; on a
multi-device identity it isn't — which is exactly why you bind more than one.

## The core rule: conflicts

Normally there's one event per step in a chain. Sometimes two show up claiming the same step — a
**conflict**. What to do about the second one is the heart of the design. It turns on two questions, asked
in order — but first, one distinction that trips people up:

**Witnesses aren't "the group."** Witnesses are the servers that attest to *every* event; they're the ones
*applying* these rules. Where "the group" matters below, it means the identity's **own keys that had to
agree** to author the event — a user's own devices, or the federation's own members — never the witnesses.

**Question 1 — is it ordinary activity, or a key change?**
- **Ordinary activity** → witnesses take the first they see and drop the copies. Always. A conflict here is
  recoverable (the next key change buries the loser), so it never alarms.
- **A key change** → could be terminal (you can't un-change a key), so ask Question 2.

**Question 2 (key changes only) — could one key have signed the competing version, or did it take several
of the identity's keys agreeing?**
- **One key could** → take the first, drop the copy. This is **a device rotating its own key** (a KEL
  rotation) — and also a **solo identity's governance**, since its roster is one key, so one key authorizes
  a roster change. The trap: the key a device signs with today is the same secret that made its most recent
  key change, so a stolen signing key could forge a second version — and a stolen key must stay
  *recoverable*, not terminal. (Inert anyway: the stolen key can only forge *after* the real change revealed
  it, by which point the witnesses have already sealed that position.)
- **It took several** → keep both, raise the alarm. This is **a roster change on a multi-device identity**
  (several devices must agree — `t_govern ≥ 2`) or **anything the federation does**. No single stolen key
  can fake it, so a second version is proof the group was subverted — exactly what you want surfaced.

**Both kinds of identity live on both sides.** A multi-device personal identity uses "take the first" for
its devices' own key changes and "raise the alarm" for its group decisions. The **federation is the pure
case** — no ordinary activity, every decision a group decision, so *every* federation conflict is an alarm.

The one-line test: **could a single stolen key have faked this conflict, or would it take a group
betrayal?** Faked → throw the fake away and recover. Group betrayal → surface it loudly.

(From a single witness's seat it's simpler still: it checks its own history and won't sign twice at one
step. We only plan for a second getting backed because we can't assume every witness is honest — and a
corrupted one that does leaves its signature on both as the evidence.)

## What "disputed" means

**Disputed** is when a conflict is visible to everyone in the data — both versions have enough backing to
be trusted. Same word on every kind of chain, and it arises two ways: on a **group decision** the design
*records both* on purpose (the "raise the alarm" rule), so a subverted group surfaces at once; on anything
else honest witnesses take only the first, so a second version reaches backing only if an attacker
*corrupts enough witnesses* to force it — and forcing it leaves their double-signatures in the data as
proof. Either way, what you *do* about it depends on which kind of event conflicted:

- **Two pieces of ordinary activity** → recoverable. Your next key change keeps the real line and drops
  the other.
- **Two key changes** → not recoverable. You can't un-change a key, so you start a fresh identity.

## The fingerprint of a conflict

Every chain has a short **fingerprint** of its current state — a compact value two people can compare to
check they're looking at the same identity in the same state. When there's a conflict, the fingerprint has
to reflect it, so no one mistakes a broken chain for a healthy one. How much it says depends on whether the
conflict is temporary or permanent:

- **A temporary conflict** (two pieces of ordinary activity — recoverable): the fingerprint just says
  *"there's a conflict here."* It doesn't spell out both versions, because the conflict is going to clear
  itself — the next key change buries the loser and the fingerprint moves on. Everyone who sees it agrees
  "conflicted, wait for it to resolve," and that's enough.
- **A permanent conflict** (two key changes — not recoverable): the fingerprint spells out **both versions
  in full.** This one won't clear, and everyone has to agree on *exactly* the same conflict, so no one can
  quietly hide a version. If someone withheld one, their fingerprint would come out different from everyone
  else's — which is itself the signal that they're hiding something, and prompts a fetch to get the whole
  picture.

One line: **a temporary conflict → the fingerprint just flags it (it'll clear itself); a permanent conflict
→ the fingerprint pins down exactly which versions are fighting (it won't clear, and no one gets to hide
one).**

## Recovery is just a key change

There's no special "recover" or "repair" operation. When your signing key is stolen, you rotate to a
fresh key, and that single rotation does everything: it locks the thief out (they don't have the new key)
and it buries their activity (anything not on the line leading to your rotation is discarded, and so is
anything built on it). You rotate at the **first** event that isn't yours, so however long a run the thief
piled on, it all hangs off that one point and dies at once — you go for the root, not their tip. Burying is
automatic and complete — everything below your key change that isn't on
the surviving line is dead, and anything grown from a dead point is dead too. No recovery key, no special
event, nothing to prove.

That's the single-device story — you rotating your own key. On a multi-device identity there's a second
kind: when a whole *device* is compromised (an attacker can use both its keys), the *other* devices remove
it — and that removal is itself a key change too (next section). Same idea at two levels: **recovery is
always just a key change that buries what came before.**

## Kicking out a bad member

On a group identity, when one member is compromised the others remove them with a single governance
change — a change to who's on the roster. Because a roster change is itself a key change, it drops the bad
member and buries whatever mess they made in one step; there's no window where they're half-out but still
dangerous. (This needs at least three members — with two, a compromised member can freeze you, so
two-member identities are flagged "add a third key.")

## Two ways to add people: the roster vs delegation

An identity's **roster** — the devices and parties that *directly control* it — is meant to stay **small
and bounded**: a handful of co-signers who can change keys and govern. That's the tight inner circle.

To extend authority to **many** parties — sub-delegates, document editors, an org's wider reach — you
don't grow the roster; you **delegate**. Delegation is a separate, **unbounded** mechanism: a tree of
grants, each one revocable, with the root always able to pull the plug on anything below it.

So the rule of thumb is **bounded control = the roster; unbounded reach = delegation.** Keeping the roster
small is deliberate — it keeps governance easy to reason about and cheap to verify, and it pushes scale
onto delegation, which is built for it. And the roster is **hard-capped** as a backstop: the verifier
rebuilds it in memory as it walks, so an unbounded pile of adds would be a resource-exhaustion attack —
any change that would push the live set past the cap is rejected. The intended size is *small*; the cap — **32** for any
identity's roster, the federation included — is just the DoS backstop.

## An issued artifact rides its owner's identity

A credential or document has its own little log, but that log is **anchored to the identity that issued
it** — each of the artifact's events is pinned to a point on the identity's log, which acts as its clock.
Two things fall out, and they're the whole story:

- **An artifact can't go wrong on its own.** Two conflicting versions of an artifact event could only
  exist if they're pinned to two conflicting points on the owner's identity — which means the *identity*
  forked, not the artifact. Under a healthy identity, the artifact stays in line by itself.
- **And it heals for free.** When the identity buries its own fork (the losing line dies), every artifact
  event pinned to that dead line dies with it — automatically, because deadness spreads downward and it
  crosses the pin. The artifact's fork clears the exact moment the identity's does. No separate repair for
  artifacts, ever.

Since a single owner controls the artifact's log, it plays by the same "back the first, refuse the rest"
rule as a personal identity — nothing new to learn.

## The one guarantee to remember: no silent breach

The whole point of the system is this: **a break-in big enough to create a trusted forgery can't happen
quietly.** To make a forged event look real, an attacker has to get enough witnesses to vouch for it — and
forcing that is exactly what leaves the evidence behind. The very witnesses that have to double-sign to
pull it off are sitting in the data doing so. So you can't be robbed in silence: a real breach shows up
either as a visible conflict (disputed) on a live identity, or, on an identity that's gone quiet, as a
staleness warning — an old harvested signature can't be replayed onto a live chain, because witness
sign-offs only ever move forward in time.

The one thing this *can't* catch is an attacker who has corrupted every witness vouching for you at once —
then there's no honest witness left to leave a trace. That's the edge of the guarantee, and it's the same
limit every system of this kind has: if everyone vouching for the truth is compromised, you've lost the
trust you were building on.
