# VDTI adversary cases — every attack on an Active chain

**What this is.** The soundness stress-test: every way an adversary can attack a healthy (Active) chain,
and why each one is contained. Companion to `vdti-model-plain-english.md` (the concepts) and
`vdti-event-kinds.md` (the kinds). Mechanics confirmed against the witnessing rules (federation-witnessing
§1e). (2026-07-07)

## Setup

- **Config** `{signers, threshold}`, with the majority floor `threshold > signers/2`. **Fork-cost** — the
  number of dishonest witnesses it takes to force a fork — `= 2·threshold − signers`. Examples use
  `{3, 2}`, fork-cost 1.
- All chains here are **witnessed** — there is no unwitnessed "direct mode."
- **Extend** = append at a *fresh* position (no competitor). **Fork** = a competitor at an *established*
  position.
- Each case assumes the adversary can already *author* the event — they hold the authoring capability: a
  **signing key** (content, and a single device's own rotation), a **rotation reserve** (a device's next
  rotation), or a threshold of the identity's members (**`t_use`** for identity-log content, **`t_govern`**
  for identity-log governance).
- **Witness behavior:** ordinary activity → *first-seen* (take the first, refuse copies). A **single-signer
  key change** — a KEL rotation, or a solo identity's `t_govern = 1` governance — → *first-seen* too (the
  Rot'@v_M fix). A **multi-signer key change** — a roster change needing `t_govern ≥ 2`, or federation
  governance — → *record both* → disputed.

## KEL — one device's key log (first-seen throughout)

| # | attack | needs | witnesses do | outcome |
|---|--------|-------|--------------|---------|
| 1 | **extend** w/ content | signing key | back it (only event there) | **Accepted.** The inherent blast radius of a stolen signing key — it can write content, nothing more. Recover by rotating at the **first** compromised position: privileged-buries-content wins there, so the whole run below it dies by descent and the key is locked out — one rotation, however long the run. |
| 2 | **fork** w/ content | signing key | already signed that position → **refuse** | **Inert** (zero honest receipts). |
| 3 | **extend** w/ seal | **reserve** | back it | **Takeover of this device's key log** — silent rotation to the attacker's key. The reserve is the point of no return *for one device*. |
| 4 | **fork** w/ seal | signing key¹ or reserve | already signed → **refuse** | **Inert.** *The attack the pivot fixes.* |

¹ The signing-key variant is **Rot'@v_M**: today's signing key *is* the secret that authored the current
epoch's rotation, so it can forge a competing one — but only *after* that rotation revealed the key, by
which point the witnesses have already sealed the position. It can only ever land at that one established
position, so it's always a *late* fork → refused. A competing rotation that isn't late needs the reserve.

**1–4 with fork-cost dishonest witnesses added:** 1 and 3 are accepted regardless (dishonest adds nothing).
**2 and 4 stay inert** — a *late* fork draws **zero** honest receipts, so it needs a **full threshold** of
dishonest witnesses (the assumption violated), not fork-cost. **Fork-cost never breaks a late fork.**

## IEL — an identity log (a group when multi-member: content first-seen, governance record-both)

| # | attack | needs | witnesses do | outcome |
|---|--------|-------|--------------|---------|
| 5 | **extend** w/ content | `t_use` members | back it | **Accepted.** Adversary writes identity-log content. Recover: honest members evict the compromised device(s). |
| 6 | **fork** w/ content | `t_use` members | first-seen → **refuse** | **Inert.** |
| 7 | **extend** w/ governance | `t_govern` members | back it | **Takeover** — controls governance (re-rosters the honest members out). `t_govern` compromise = point of no return for the identity. |
| 8 | **fork** w/ governance | `t_govern` members | **record both** → threshold | **Disputed → terminal.** Correctly surfaced: a second group decision is proof the quorum was subverted. Same compromise as 7. |

**5–8 with fork-cost dishonest witnesses added:** 5 and 7 accepted regardless; 6 stays inert (late fork,
full-threshold needed); 8 is already surfaced by honest witnesses — dishonest adds nothing.

**Case 8 assumes `t_govern ≥ 2`.** At `t_govern = 1` (a solo identity) a governance fork can't form — it
collapses to case 4 (inert): the competing decision would need a *second* witnessed rotation from the sole
member's KEL, and first-seen there refuses it. Disputed requires **≥ 2 members who can independently
produce witnessed authorizing rotations**, so the single-key-turns-terminal trap never reaches a one-key
identity.

*Backdate-safety for 8:* re-authoring a *past* governance decision needs its members' *reserves* (already
terminal), and a harvested-old-key path is blocked by witness-signature monotonicity — a receipt must be
both forward-of-the-tip and inside the closed old key-window, which is impossible on an active chain. So
recording both a *late* governance fork adds no everyday-key backdate.

## Case 9 — the race (different events to different witnesses, concurrent)

The only case where honest witnesses *split* (none has signed yet), and the only place fork-cost bites.
Two outcomes, nothing else:

- **(a) Fork.** To drive *two* events to threshold, the majority floor forces their two quorums to overlap;
  honest witnesses each back one, so the overlap **must be fork-cost dishonest double-signers** — left
  **attributable** (two receipts, one witness, conflicting events → eviction). Content → recoverable
  (buried + evict). Single-key seal → detected → terminal. Group seal → already disputed.
- **(b) Stall.** Split so no event reaches a majority: the position **stalls, fail-secure** — signed
  witnesses can't switch (first-seen is sticky). This is the CP corner of the floor — *a minority partition
  stalls, never forks; consistency over availability.* A **liveness** cost, not a safety break. Exit: a
  majority reconverges, or a burying seal attaches at the stalled tip, and honest content re-issues
  forward; once the stolen key is rotated out it can't keep racing.

## The pattern (why it holds)

1. **Extending never forks** — it's accepted, and the outcome is set entirely by *which key was stolen*: a
   content key → bounded blast radius (recover); a **seal capability (reserve / `t_govern`) → takeover**
   (3, 7 — the point of no return, **contained by multi-device identities**: one device's takeover isn't
   the identity's).
2. **Late forks are closed by first-seen** — zero honest receipts → needs a full threshold of dishonest
   witnesses → outside the assumption. **Fork-cost is powerless against a late fork.**
3. **Fork-cost only matters in the concurrent race (9)** — and there it buys a *detected, attributable*
   fork or a *recoverable stall*, never a silent one.
4. **The single-key vs group split is cases 4 vs 8, and it's forced** — co-witnessing a KEL seal fork would
   resurrect Rot'@v_M (a stolen everyday key → terminal); co-witnessing an identity-log governance fork is
   safe because no single key can fake a group decision.

## Residuals (the limits, stated)

- **Reserve / `t_govern` compromise = point of no return** (3, 7). Inherent; contained by binding more
  devices to the identity.
- **The stall (9b)** is a real liveness / DoS cost — serialized submission is the honest-side discipline;
  it is not a safety hole (the CP corner).
- **Eclipse** (withholding a branch or its receipts from a node) is the standing detection limit — receipts
  are off-chain, so detection needs them gossiped. Weaponizing even the inert Rot'@v_M requires
  eclipse-level control over a majority of the selected witnesses — not mere key theft.

## What we tried to break — the cross-tier co-sign

The rule that makes recovery work: **a witness's limit at one serial isn't "one event" — it's "one
content event *and* one key change"** (on a group chain, one content + two key changes). Content and a key
change are different tiers, so signing one of each isn't a double-sign — that's the *cross-tier co-sign*,
and it's what lets a recovery rotation get witnessed and bury content the witnesses already signed. We
attacked it three ways.

**Pass 1 — is the rule itself a hole?** The sharp part: normally a *late* event (one arriving after a
position is settled) draws zero honest backing, which is what makes late attacks fizzle — but the burying
rotation is itself a late event and it *does* draw backing, so "late ⇒ no backing" is not universal. It
holds anyway, because the only late event that pulls backing this way is a **key change**, and authoring
one needs the **rotation reserve** — which a signing-key thief doesn't have. Every attack died at "you'd
need the reserve" (already takeover) or "the same-tier copy is refused." **One thing this makes
mandatory:** a buried event *keeps* its witness backing, so trusting "enough backing ⇒ real" without
walking the chain would accept buried junk. **The full walk is mandatory; receipt-count is never a
shortcut for canonicity.**

**Pass 2 — interaction with `disputed`.** The alarm lives entirely in the *key-change* slots, never the
content slot; content at an alarmed position is just buried and can't mask or fake the alarm. You can't
disguise a key change as content to dodge the alarm (tier is fixed by the event kind). And the key-change
slot *count* (one vs two) **is** the "refuse the copy" vs "record both and alarm" rule — the co-sign
framework and the alarm are the same machinery. **A subtlety the majority floor closes:** if governance could be a *minority*
(`t_govern ≤ |roster|/2`), two *disjoint* quorums could sign competing decisions → alarmed with **no single
member to blame**. Requiring **majority governance** (`t_govern > |roster|/2` — the same floor as the
witnesses) makes any two quorums overlap (pigeonhole), so a fork always leaves a nameable double-dealer.
Governance carries that floor; the attribution loss is **closed, not tolerated**.

**Pass 3 — group chains + the three-witness race.** A group witness can hold three receipts at one serial
(content + two key changes); every weaponized combination died — content is always orthogonal (buried), and
**governance disputes are settled at the members' own keys, not by the witnesses**, so shuffling events
across witnesses in a race can't forge a dispute. A race can only ever yield a *recoverable* content fork
or a *stall* — **never an alarm** — and a recovery rotation always gets through a race (its slot is
separate from the content chaos). **The real hazard is the cheat-catching rule:** it must be **type-aware
and count-aware** (`≤1 content`; `≤1 privileged` single-key / `≤2` group; over either count is misbehavior,
cross-tier pairs never are). A lazy "signed two things at one serial → evict" rule would evict the *honest*
witnesses doing the legitimate content-plus-recovery co-sign — a self-inflicted DoS on the witness set —
and the three-witness race is exactly where that's triggered.

**Verdict:** no protocol break found across the three passes — disputes are member-key-driven (a race can't
forge one), event tiers are unfakeable (blame-assignment holds), honest witnesses self-limit (can't be
framed). What to carry into the build: **(1)** always walk the chain, never trust receipt-count as a
shortcut; **(2)** the cheat-catching rule counts by tier and by config caps. The design rule this pinned down: **the authority thresholds
carry the majority floor** (`t_govern` / `t_authorize` > `|roster|/2`, the same rule as the witnesses), so a
governance fork always names a culprit (`t_use`/content is exempt — first-seen and recoverable). This area
still deserves a fresh adversarial pass rather than a self-declared all-clear.
