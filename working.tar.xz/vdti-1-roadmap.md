# VDTI v1 Roadmap

## Current state (2026-07-01)

The **design is well ahead of the build** (no vdti runtime code yet — only `docs/design/`). The area-by-area
**design pass is complete and through five adversarial review rounds (all adjudicated + codified); doctrine-land is
underway**: the canonical design lives in `.working/vdti-invariants.md` + the `vdti-area-*.md` notes (document/policy ·
KEL · IEL · SEL · delegation · federation/witnessing · `vdtid` services). Read order: `.working/00-INDEX.md`.

- **Current design edge (2026-07-02):** **content-fork prevention** — a structural **majority floor
  `threshold > signers/2`** on the witness-config plus one-content-sibling-per-serial witnessing makes content
  divergence on witnessed chains **prevented, not detected** (priced at fork-cost `2·threshold − signers`;
  privileged forks still surface as `disputed:` — compromise evidence). With it, the repair's `forks` list
  collapsed to a **single `fork` root** and repair machinery re-scoped to the direct-mode/byzantine residual —
  folded across the canon (uncommitted; dual pass next, then the landed-doc encode). Earlier on this branch:
  `folds`→`forks` root-pointing + the **repair-completeness proof** are encoded + committed. Detail:
  `.working/00-INDEX.md`.

- **Federation / witnessing remodel — CONVERGED (2026-06-29).** The `Fed`→`Wit` + `Fcp`-marker reshape: one
  `Wit` kind at both layers (`Wit` anchors `Wit`; `Wit` IS the T3 rotation), the federation IEL `Fcp`-rooted +
  **self-attested** (cross-witnessed exclude-self) with the recoverability cap, the 365-day key-window auto-expiry,
  the freshness wall-clock overlay, and the clock carve-out. Hardened through **~15 dual-pass review rounds to a
  clean MERGE/MERGE**, folded across `vdti-invariants.md` + the `vdti-area-{kel,iel,federation-witnessing}.md` notes
  (`make all` green). **Supersedes the pre-reshape KEL/IEL taxonomies below** (KEL `Fed`→`Wit`; the federation IEL
  is `Fcp`-rooted self-attested, not an ordinary `Icp`). Spec → `archived/vdti-fed-wit-remodel.md`.
- **Design reviewed (rounds 1–5, all adjudicated + codified).** Headline refinements: a kill is always sealed and
  rides a dedicated **`Kil`** anchor (separated from `Evl`); divergence resolution is **by tier** (keep the ≤ 1
  privileged branch); the dormant-chain forgery is closed by **wipe + a federation clock** (an inline timestamp on each
  federation `Wit`'s `manifest.clock`) with staleness detection; the threshold bound **splits** into a hard security
  floor (`≥ 2`) and a recoverability ceiling (`≤ |roster| − 1`, advisory for users / hard for the federation); the
  **manifest is role-qualified, read kind-first** (`anchors`/`roster`/`clock`/`witnesses`/`delegates`/`issues`/
  `revokes`/`content`); **logs are referenced by prefix, SAIDs are commitments not lookup keys**; a **credential is
  its own per-cred SEL** whose `Icp`'s `data` IS the cred's SAID (no body pin; self-locating revocation).
- **Doctrine-land — vdti#12 (the policy primitive + doc reconciliation): MERGED to `main` (PR #13, 2026-06-24).**
  The document/policy layer (`id`/`del`/`pol` + `thr`/`wgt`/`and`; two evaluators; policy-on-documents,
  chain-events-structural) + the keep-all-data **divergence-detection model** + the IEL `Gov`→`Evl` rename,
  after a two-pass fidelity review.
- **KEL primitive (vdti#10 / PR #11) — DONE; design-complete + dual-pass reviewed to a clean MERGE, awaiting Jason's gh review.** The PR grew well past the KEL docs: the **whole landed `docs/design/` surface is reconciled to the remodel** (`Fed`→`Wit` + the new **inv 18** field-presence model — _events carry only changes; use the established state, not re-stated; no empty events_ — across `event-shape` / `protocol-doctrine` / `system-thesis` / `sad/` / `policy/`), plus the doc/drawing tooling (`lint-docs` / `lint-diagrams` (+`--prune`) / prettier, and a deterministic **canon snapshot** `docs/design/canon.tar.xz` via `make canon-tarball`). The six `kel/` docs
  (authored pre-reshape) reconciled to the post-#13 canon (data-local detection, the manifest role model, the
  `previousSeal`/`folded` spine, the `KelVerification` token reshape). Through a **4-round dual-pass review** that
  fixed two foundational soundness issues (a tier-2 `Rot` takeover → **reincept**, never archive-the-`Rot`; the
  repair `forks[]` is **validated, not trusted** — the verifier computes the archival set independently) **and**
  locked the page size (65 / fold 64 / single-event `[Rec]`); rounds 3–4 closed with **no soundness holes**. Then
  three design follow-ons landed (each dual-pass-reviewed → ADOPT): **`federationPin` optional on every event**
  (`Fed` reserved for a **rebind** — moving the federation *position* doesn't warrant T3, and it dropped events
  from the design); **`graceSeconds` dropped** (the witness currency gate is **exact-tip**); and the federation
  **`clock`** carried **inline** (no nested SAD). Plus **`pins`** (the IEL→KEL down-pins) made **top-level
  structural** (inv 4 + area-iel + the event-shape IEL grid) and the **threshold-declaration rule** locked
  (inv 12). **The SEL + delegation model is now worked out** (2026-06-26 — in event-shape + area-sel /
  area-delegation / inv 4): a SEL `owner` field + whole-content prefix, the `Icp` pin-free with re-pin via a
  serial-1 `Pin` (the SEL floor re-pin, `t_use`/T1; the SEL re-seal split into a new `Fld`, T2/fold), the **cred body `pin` dropped** (as-of = the anchoring
  position), delegation rescission as a lookup-SEL **`{Icp, Dec}`** carrying **`bound`** (ex-"cut-off") with the `Kil`'s
  `rescinds` / `revokes` split (both → a SEL `Dec`), multi-issuer via an **`issuers[]` SAD**, and witness key-SELs owned
  by a **derived degenerate restricted-IEL** (settled 2026-06-26). Then `iel/` · `sel/` · federation encode it (+ the
  pins-SAD byte-schema, walk semantics, the federationPin inheritance split).
- **SEL `Pin`/`Fld` review close-out + a new multi-party documents feature (2026-06-27).** The SEL `Pin`/`Fld`
  dual-pass review's last open item (**C7**) landed: `anchors` added to IEL `Evl` so a SEL `Fld` anchors there
  (symmetric with `Rpr`; it also lets the IEL's own re-seal `Evl`s double as SEL-fold anchors), plus the area-sel
  §1/§3 staleness and the **`ownerIelEvent → ownerPin`** custody rename (gate green). Separately, a **multi-party
  documents** feature was worked out — a collaborative, *evolving* document (a shared spreadsheet) as a **separate
  type** from credentials (NOT subsumed — the axes differ): an immutable **V0** constitution (`authors[]` +
  `custody.readPolicy`) + one SEL per author + a multi-parent **version DAG** (`ancestors[]`, an advisory
  per-version clock on the SAD; attribution via the owner-rooted SEL anchoring); policy-free except `readPolicy`. Captured in
  `.working/vdti-area-multi-party-documents.md` (canon); it **encodes to `docs/design/features/multi-party/documents.md`
  at the features building block, not before**. Dual-pass-reviewed + folded (both cold blockers resolved with Jason); a re-review of the folded note is underway.
- **Recovery / divergence-detection model — LANDED + POLISHED (2026-06-23).** Four model-review rounds settled the
  **data-local, branch-level** detection model (**keep-all-data** retain-as-bounded-evidence; the `previousSeal` +
  `folded` **spine** overlay; **FORCE-split** by provenance; the federation as a **propagation beacon**, never the
  terminal decider), translated into `protocol-doctrine` / `event-shape` / `system-thesis`, then **two docs-review
  passes** + the **IEL `Evl` rename** (evolve-state — named distinct from `t_govern`). Polished, lint-green,
  propagated to the `.working/` invariants + area notes (inv 4/13/16/17). **LANDED on `main` via PR #13
  (2026-06-24).** → `archived/vdti-keep-all-data-rework.md` (the §1–§13 decision log).
- **Landed on `main` (`docs/design/`):** system-thesis (vdti#4), protocol-doctrine (vdti#6), SAD primitive
  (vdti#8), event-shape (vdti#14). ⚠ event-shape + protocol-doctrine are **now partly pre-reshape**
  (`policyPin`, `dev`/`grp`, governance policy-kinds, `Rpr`-for-KEL) — reconciled in the land phase.
- **Superseded by the log-primitive reshape (2026-06):** the **pre-reshape** policy-DSL *design* (the device /
  roster-splice leaves, the governance policy-kinds), the `policyPin`/pinning model, and the creds `T_rev`
  issuance/revocation design. **Policy moved up to documents**; primitives carry no policy; a cred is a **per-cred
  SEL**; rescission/revocation are derived **lookup-SELs** / a cred-SEL `Dec`; federation is an **ordinary IEL** (no
  self-attestation carve-out). **vdti#12 / #13 are RE-SCOPED** (not abandoned) to land the **reshaped document/policy
  layer** + reconcile the docs it makes stale — see below.
- **Next — the doctrine-land phase. Reconcile ALL documentation, always — drift everywhere means we can't reason
  about our own design.** **vdti#12 first** — land the document/policy layer (`id`/`del`/`pol` + `thr`/`wgt`/`and`;
  two evaluators; policy-on-documents, chain-events-structural) **and** reconcile every landed doc carrying the old
  policy machinery (`event-shape.md`, `protocol-doctrine.md`, `custody.md` — strip `policyPin`, the device /
  roster-splice leaves, the governance policy-kinds). Then the per-primitive docs (`kel/`, `iel/`, `sel/`,
  federation, services) into `docs/design/` from the area notes. Then Phase 1+ build (below).

## Mission

**VDTI** — Verifiable Decentralized Trust Infrastructure.

- Users control their identity and data without relying on a central authority.
- Devices are decoupled from the identity that operates them.
- Identity and policy are first-class, composable primitives.
- Any verifier determines system-wide state — including attack exposure — by inspecting data from a single source.
- Contrast with KERI (Decentralized Key Management Infrastructure): system-wide state inference there requires out-of-band watcher infrastructure.
- A framework for building high-trust applications from the ground up.

## Audience

General-purpose. Any application requiring identity composes naturally on VDTI's primitives.

Three attestation modes drive most credential flows:

- **Property attestation** (you own X) — tickets, passes, goods-in-transit.
- **Identity attestation** (you are X) — age verification, travel, hiring.
- **Capability / certification attestation** (you've been verified to have X) — background checks, education, training, health records.

Adoption catalyst:

- Government issuing a foundational credential (digital passport / national ID equivalent).
- Once that exists, downstream issuers, IDV providers, and applications can compose on it.

Anchor use cases:

- **Government adoption** — acceptance-driven; no protocol-side monetization concern.
- **IDV / background-check / credential-issuance partnerships** — commercial; protocol stays open, revenue lives in apps + services + insurance built atop.

## Relationship to KERI / WebOfTrust

- Independent + technically comparable.
- Separate protocol, separate ecosystem.
- Encoding primitives absorbed into vdti (from kels' custom implementation) as the `encoding/` package; no upstream `cesr-rs` dependency.
- No wire compat with KERI verifiers.
- No upstream-contribution commitment.
- `docs/reference/keri-comparison.md` frames KERI as a peer / alternative approach to similar problems.

## License

- MIT, OSS.
- License file already in place in the repo.

## Repo layout

> ⚠ **Service shape updated for the reshape:** it's **`vdtid`** (chain-log **+** SAD store merged — events
> reference SADs by SAID, so a separate store is a per-SAD hop, several per request) **+** **`witnessd`** (the
> gossip / sync / witness daemon) — **not** the old `eventsd`/`sadd` split. And **policy lives up at the document
> layer**, not in the primitives. See `.working/vdti-area-vdtid-services.md`.

```
vdti/
  lib/
    encoding/                # vdti-encoding (absorbed from ../cesr-rs)
    storage/                 # vdti-storage (absorbed from ../verifiable-storage-rs; itself a workspace)
    cache/                   # vdti-cache (absorbed from ../cacheable)
    vdti/                    # vdti — protocol primitives (KEL/IEL/SEL) + verifier/merge/transfer engine + SAD store + gossip
    mail/                    # vdti-mail (application shim)
    exchange/                # vdti-exchange (application shim)
    creds/                   # vdti-creds (application shim)
    derive/                  # vdti-derive (KEL signed-events repo derive macros; KEL only — IEL/SEL anchor in KEL)
    ffi/                     # vdti-ffi (Rust → C bindings)
  services/
    vdtid/                   # thin binary over lib/vdti; chain-log + SAD store (postgres + object store); submit/merge
    witnessd/                # gossip / sync / witness daemon (anti-entropy, deferred-deps park, receipts; HSM consumer lib)
  cli/
    vdti/                    # CLI binary
  infrastructure/
    objects/                 # SeaweedFS deploy config
    database/                # postgres deploy config
    kvstore/                 # redis deploy config
    mock-hsm/                # HSM service + consumer lib (production HSM abstraction)
  examples/
    messaging/               # iOS/Android demo (ports current kels iOS app + adds messaging)
  docs/
    design/
    reference/
    operations/
    analysis/
  tests/
    bench/                   # benchmarks (SAD / IEL / SEL load testing)
    # plus e2e suite (port of kels clients/test/) under tests/
  AGENTS.md
  README.md
  LICENSE
```

**Conventions:**

- Library directories use short names (no `vdti-` prefix); Cargo.toml package names use the `vdti-` prefix for crates.io publishing.
- Service daemons use `d` suffix (`vdtid`, `witnessd`) — Unix daemon convention.
- CLI binary is `vdti` — what users type.
- Absorbed libraries (`lib/encoding/`, `lib/storage/`, `lib/cache/`) live under `lib/` alongside vdti-native libs. The absorbed-vs-native distinction lives in commit history and crate metadata, not directory layout.
- `lib/vdti/` is the protocol core: KEL / IEL / SEL primitives, the verifier / merge / transfer engine, the SAD store + custody, and gossip — **linked by both `vdtid` and consumers** (end-verifiability: a consumer verifies the data itself with the same library, trusting the data not the daemon). `mail/` / `exchange/` / `creds/` are application shims that depend on `vdti`; **policy is the document layer**, not a primitive.
- **`vdtid` merges the chain-log and the SAD store** into one daemon (kels split `kels`/`sadstore` ad hoc; now that events reference SADs by SAID, a separate store is an extra hop per SAD — several per request). `witnessd` is the separate gossip / sync / witness daemon (kels' `gossip` service, renamed).
- IEL and SEL events anchor in KEL events; they do not carry direct signatures. `lib/derive/` (`vdti-derive`) generates signed-event-repo macros for KEL only. IEL / SEL repos use `storage/`'s `Stored` / `Chained` primitives directly.
- `infrastructure/mock-hsm/` is a service that builds a consumer lib. Services needing signing keys (e.g. `witnessd`) import the consumer lib to talk to the HSM service. Same architecture in production — swap the HSM implementation behind the lib without touching service code.
- Garden orchestrates infra + services; `tests/` contains the e2e scenario suite (port of kels `clients/test/`); benchmarks live under `tests/bench/`.

## Operational decisions

Resolved during planning; recorded here as the operational baseline.

- **Auth model for SAD writes (`vdtid`)** — operator-configurable. Default: open + rate-limits always-on. Lockdown via vdti's own creds + document policy (specify required credential/policy for writes). Self-bootstrapping — vdti is its own auth substrate.
- **Configuration** — env vars only (kels precedent). Trusted federation IEL prefix is compile-time-baked + runtime env-var override.
- **Branching / release** — main + feature branches; semver from day one; tagged releases.
- **CI/CD** — GitHub Actions; 6-job shape (fmt, lint-terminology, deny, clippy, test, build). No git hooks (CI gates only). No coverage tracking at start; deferred to Phase 9 if/when an e2e-aware setup is worth building.
- **Audit trail** — multi-agent audit reviews from day one, with outputs in `.working/` (gitignored). `CHANGELOG.md` committed to repo as the public record.
- **Item filing** — lazy. Items filed as vdti issues when picked up; the roadmap is the authoritative pre-filing source.
- **Backlog organization** — tracker-style meta-issues for cross-cutting themes.
- **Contributor on-ramp** — `README.md` + `AGENTS.md` + `docs/`. Plus 4 issue templates (`doctrine`, `implementation`, `bug`, `tracker`) and a PR template. All produced in Phase 0.
- **Demo / pilot timeline** — no partner commitments; pure protocol-correctness ship.
- **License** — MIT throughout the repo, including `examples/messaging/`.

## v1 scope and phases

v1 ships when:

- E2E suite passes against vdti.
- Messaging-app example in `examples/messaging/` runs end-to-end on iOS.
- Federation bootstrap from clean state is documented + reproducible.

> ⚠ **The per-phase *design* specifics below predate the 2026-06 log-primitive reshape** (e.g. IEL `PoliciesSet` /
> 7-kind IEL, `Sea`/`Est` kinds, the federation self-attestation carve-out, policy-in-primitives). The
> current design is the `vdti-area-*.md` notes; the phases here are kept for **build *sequencing***, not current
> design detail — reconcile per-phase specifics from the area notes at land/build time. Phase 0 (design) is
> effectively the completed area-note design pass + the doctrine-land step (see Current state).

### Phase 0 — Design completion (docs + scaffolding, no code)

- Empty repo populated with a complete, audited doctrine before any code lands.
- The area-by-area design pass (`.working/vdti-area-*.md` + `vdti-invariants.md`) is the completed design; Phase 0 closes by **landing it into `docs/design/`** (the doctrine-land step) + the repo scaffolding below.

**Design-doc build order (dependency layering).** The design docs build in dependency layers; getting the order right is what keeps the build understandable (the goal — isolation is only a means):

`sad` → `event-shape` (shared chain/event structure) → `kel`/`iel`/`sel` primitives → `policy`/document layer (authorization language, on top of the primitives) → features (`creds`, `multi-party documents`, `mail`, `exchange`).

- **`event-shape.md` is the lynchpin.** Every chain primitive shares it. Post-reshape it needs the rewrite catalogued in the area notes (drop `policyPin` / `dev` / governance policy-kinds; `Rpr`→`Rec` on KEL; `federationBinding` → `federation`/`federationPin`; witness-config SAD).
- **The policy↔primitive dependency is inverted via verification tokens:** the document/policy layer *declares* the verification interface it consumes (what a verified chain token exposes — roster/threshold as-of, delegation chain, anchored SAIDs); the chain primitives *implement* it (their concrete `*Verification` tokens). Policy sits **above** the primitives and consumes their tokens; the primitives carry no policy.
- **Features are clean leaves.** `creds` (and later `multi-party documents` / `mail` / `exchange`) compose the document layer + primitives, depend only on landed interfaces — one PR each, no cycle. A credential is a **per-cred SEL** (data referencing identity, not an IEL/SEL/KEL kind); issuance = its `Icp`, revocation = its `Dec`. See `.working/vdti-area-document-policy.md`. A **multi-party document** (collaborative + evolving — a shared spreadsheet) is a *separate* feature over SEL + SAD: an immutable **V0** constitution (`authors[]` + `readPolicy`) + one SEL per author + a multi-parent **version DAG**; policy-free except `readPolicy`; **not** subsumed into creds (a co-author is not an issuer). See `.working/vdti-area-multi-party-documents.md`.

**Repo scaffolding:**

- `README.md`, `AGENTS.md`, `CHANGELOG.md` (stub).
- `.gitignore` (including `.working/`), `.terminology-forbidden` (vdti version).
- `.github/ISSUE_TEMPLATE/{doctrine,implementation,bug,tracker}.md`, `.github/pull_request_template.md`.
- `.github/workflows/ci.yml` (job slots; most fail on empty workspace, unblock as code lands).

**`docs/design/` — land the area-note design (per the doctrine-land step):**

- `system-thesis.md` — system thesis + adversarial-first framing. Canonical orientation; AGENTS.md links + quotes the load-bearing one-liners.
- Per-primitive docs `kel/` · `iel/` · `sel/` written from the area notes; `event-shape.md` + `protocol-doctrine.md` reconciled (strip superseded machinery).
- Federation as an ordinary IEL + the witnessing model (`docs/design/federation/{bootstrap,witnessing}.md`).
- Services/architecture doc (`vdtid` + `witnessd` + `lib/vdti`).
- Greenfield prose (no "previously X" / migration language); every cross-reference reconciled.

**`docs/reference/`** — lookup material: attestation modes (own / be / certified), KERI comparison, endpoints (when services land). Primitive specs live under `docs/design/primitives/`, not here.

**`docs/analysis/`** — attack-surface, scale, deployment, node-attack-surface, protocol-attack-surface.

**`docs/operations/`** — deployment, backup, node retirement, shadow-node patterns.

**Phase 0 acceptance — closing 5-axis audit:**

Single closing-pass audit certifies Phase 0 complete. Five axes:

1. **Security** — adversarial review. What attacks does each doctrine section address? Are arguments structural-soundness based (not invariant-protection based)? Every privileged operation, state transition, and trust boundary evaluated under adversarial input.
2. **Correctness** — internal consistency. Doctrine self-coheres across primitives. Cross-references resolve. Interlocking invariants maintained. Edge cases enumerated.
3. **Completeness** — gap detection. Every primitive, event kind, state, transition, error mode, and operation documented. Matrix docs are exhaustive.
4. **Readability** — prose quality. Clear; technical terms defined on first use; narrative coherent across sections.
5. **Accessibility (newcomer reach)** — someone with security / distributed-systems background lands in `docs/` and builds a mental model without prior kels exposure.

Phase 0 closes when the 5-axis audit produces zero structural findings.

### Phase 1 — Foundations (libraries + infrastructure)

- Bring up repo: README, LICENSE (done), Cargo workspace, CI scaffold (GitHub Actions).
- Garden integration for orchestration.
- `infrastructure/{objects,database,kvstore}/` configs (SeaweedFS, postgres, redis) so `garden up` spins up dev deps.
- Absorb cesr-rs as `lib/encoding/` (vdti-encoding) — port kels' custom encoding implementation.
- Absorb verifiable-storage-rs as `lib/storage/` (vdti-storage).
- Absorb cacheable as `lib/cache/` (vdti-cache).
- Naming convention setup: `vdti/{component}/v1/{category}/{name}` patterns as constants.
- CHANGELOG.md + release scaffold.

### Phase 2 — Core primitives (libraries)

- KEL primitive — taxonomy `Fcp / Icp / Ixn / Rot / Ror / Rec / Fed / Dec` (8 kinds). Three-state per-node machine (Active / Divergent / Decommissioned). No Cnt; locked-portion bound; divergence scoped to `Ixn`. Whole-content prefix derivation; `federation`/`federationPin` split; witness-config SAD `{threshold, signers}`.
- IEL primitive — taxonomy `Icp / Ixn / Evl / Del / Kil / Rpr / Dec` (7 kinds). **No policy** (policy is the document layer); threshold-vector `{t_use, t_govern, t_delegate, t_recover}` on the `Evl` roster delta; `Kil` is the sealed kill-anchor (`govern`/`delegate` slot); `Ixn` is the divergeable content/SEL-binding kind; federation = an ordinary (restricted) IEL `Icp`. See `.working/vdti-area-iel.md`.
- SEL primitive — single-owner data log; `Icp` (T1, no body pin) / `Pin` (floor re-pin, `t_use`/T1, not sealing) / `Ixn` / `Fld` (re-seal, `t_govern`/T2, folds) / `Dec` (kill: revocation @govern, rescission @delegate w/ `bound`) / `Rpr`. `derive(owner, topic, data)` prefix; the `Icp` floors via a serial-1 `Pin`; the SEL re-seals via `Fld`. See `.working/vdti-area-sel.md`.
- The transfer engine (`transfer_*_events`: verify / forward / streaming-with) — one source/sink/verifier-swappable walk.
- Verification tokens: structural-HARD / policy-SOFT, `queried`/`satisfied` SAIDs, `resume`; `policy_satisfied` type-level split (structural-only vs trust-bearing).
- Merge (`merge_events`) — re-verify (or `resume` from a cached token gated by effective-SAID); never trust the DB.

### Phase 3 — Service skeleton (binaries)

- `vdtid` binary: thin wrapper over `lib/vdti`; HTTP server; chain-log via postgres **+** SAD store via the object store (merged — no per-SAD hop); submit/merge handler (advisory lock + txn); typed-422 deferred-deps; effective-SAID computation.
- `witnessd` binary: gossip mesh + anti-entropy loops + the Redis-backed deferred-deps park/drain + receipt production; topics under `vdti/witness/v1/topics/*`.
- Open-write SAD storage with rate-limits; authenticated witness-to-witness comms.

### Phase 4 — Federation witnessing + bootstrap

- Receipt SAD shape (adjacent, `witnessedPrefix`/`Said`/`Serial`).
- Adjacent live/ignored tables keyed by `(prefix, serial)` in the chain log.
- Always-witness rule (reporters, not deciders).
- Threshold-two-events divergence detection with structural event re-verification.
- Deterministic witness selection by `(prefix, serial)`.
- Receipt-announcement topic in `witnessd`: `vdti/witness/v1/topics/receipt`.
- Federation = an ordinary IEL `Icp` (no self-attestation carve-out; config-pinned `FEDERATION_IEL_PREFIX` trust root).
- Federation context inheritance for IEL/SEL (via the KEL anchor's `federationPin`).
- Verification token surface: `witnessed`, `divergent`, `minority_dissent`, `witnessed_anchors`.
- Acceptance gating (currency gate, exact-tip) for non-witnesses; destruction-on-witnessing.
- `Fcp` / `Fed` event mechanics (founder pre-federation; federation declaration / params update / re-binding).
- Bootstrap ceremony (founder `Fcp → Rot` anchoring the federation `Icp`, atomic batch; no founder `Fed`).
- Inter-federation transfer with per-federation (non-transitive) witnessing.

### Phase 5 — Identity binding + federation runtime

- Document-layer `id(X)` resolution (identity-chain resolution via IEL tokens).
- Creds: issuer / issuee as identity prefix; per-cred SELs.
- Federation runtime core (federation IEL handling, bootstrap config, threshold enforcement).
- Lookup-SEL implementation (rescission / address / discovery) + identity DB schema.
- Operator CLI binary: federation membership commands (`Evl` batching), identity admin.
- User-facing references rework (identity, not KEL prefix).
- Bootstrap sync + anti-entropy.

### Phase 6 — Auxiliary primitives

- Multi-party documents (collaborative + evolving): immutable V0 `authors[]` constitution + one SEL per author + a multi-parent version DAG (`ancestors[]`); immutable `readPolicy` on every owned SAD; owner-rooting check load-bearing. See `.working/vdti-area-multi-party-documents.md`.
- Mail subsystem (envelope as SAD with custody; sender/recipient as identity prefix).
- Exchange + encap keys (chain keyed by identity).
- Custody-aware SAD compaction as first-class primitive.
- SAD reader-side custody verifier surface.
- Endorsement coordination protocol for multi-KEL SAD event anchoring.
- Mail push notifications (WebSocket).
- CascadingSadStore.
- Client-side token store (cache + effective-SAID gate + `resume`).
- `availability.once` single-prefix ReplicaSet match.

### Phase 7 — FFI + mobile bindings

- `vdti-ffi` crate: Rust core compiled with C-compatible API.
- cbindgen headers generation.
- Native wrappers: Swift package for iOS; Kotlin/Java for Android (if Android Keystore APIs ready, else fast-follow).
- Hardware-backed signing custody: Apple Secure Enclave (port from kels' work), Android Keystore.
- Build + distribution pipeline for mobile artifacts.

### Phase 8 — Examples (messaging app)

- Port kels iOS app code into `examples/messaging/`.
- Adapt to new FFI surface (`Fcp`/`Fed` events, config-pinned federation trust set, witnessing verification).
- Add messaging functionality: mail + exchange + encap keys composed into a usable messaging surface.
- iOS app primary target; Android version once mobile bindings exist.
- Preserve all functionality of current kels iOS app (identity ops, key ops, federation ops, creds, custody, etc.) + add messaging.

### Phase 9 — Tooling, ops, docs, e2e

- Port `clients/test/` e2e suite (or vdti equivalent) — every existing test scenario passes against vdti. Adapt for naming (kels → vdti), service consolidation, new event kinds, etc.
- New e2e scenarios: `test-witnessing.sh`, `test-divergence-detection.sh`, `test-inter-federation-transfer.sh`, `test-federation-bootstrap.sh`.
- Rewrites for obsoleted scenarios (e.g., `test-voting.sh` superseded by federation-as-identity).
- Telemetry / observability baseline.
- Benchmark tool (SAD/IEL/SEL load testing).
- Damaged-chain enumeration.
- Operations doc (deployment, backup, node retirement, shadow-node patterns).
- Canonical signed-event-body examples via CLI.
- Deferred-deps HTTP-status threading.
- IEL policy-failure reporting hygiene.
- Pre-resolve policies before submit tx.
- Per-crate docs (`README.md` + `design.md` + `attack-surface.md`).
- Documentation reorg + gap check.
- Federation-as-identity supporting-docs (deployment, scale, node-attack-surface, keri-comparison, protocol-attack-surface).
- KERI comparison: structural divergence detection + inter-federation portability framing.
- AGENTS.md.

## v1 acceptance criteria

v1 ships when:

1. **E2E suite passes**: `make test-all-deployments` (vdti-equivalent) passes against the vdti architecture, with all existing test scenarios ported + new vdti-specific scenarios added.
2. **Messaging-app example runs end-to-end on iOS**: ports kels iOS app surface, demonstrates all current crypto operations, adds working two-user messaging via mail + exchange.
3. **Federation bootstrap from clean state is documented + reproducible**: a CLI command sequence produces a running federation from zero. Documented in `docs/operations/`.
4. **All seven demo scenarios are exercisable** by an external evaluator: fresh federation bootstrap, end-user identity creation, two-user encrypted conversation, credential issuance + verification in conversation, witnessed events with verification, divergence detection (dev-test), inter-federation transfer.
5. **Per-crate docs published**: each lib + service has README + design + attack-surface.
6. **MIT-licensed source publicly accessible** in the vdti repo.

## Post-v1 / backlog

Items not in v1 but tracked for future:

- **Federation bridging**: a vdti deployment belonging to multiple federations for continuous cross-federation sync. Future capability per kels#216.
- **Owner-side KEL monitoring with auto-Rec on detected compromise** (kels#191 tracker).
- **Scale credential issuance** (kels#77 — design exploration only).
- **Apple SE internalization completion** if not fully landed in v1.
- **Self-referential schemas** (`$defs` + Reference variant) (kels#102).
- **SADStore deep existence check via disclosure paths** (kels#116).
- **Client-side dep-graph caching** strategy (kels#162).
- **Service access control** via `AuthorizedPayload<T>` (kels#82).
- **Scale SAD storage beyond 1 replica** (possibly subsumed by SeaweedFS).

## What's NOT carrying forward

Obsoleted by the post-kels#214 / post-kels#216 / post-kels#218 design + the vdti log-primitive reshape; vdti starts without these:

- Registry (kels#190 + kels#197 removed; vdti has no registry concept — a cred is its own per-cred SEL).
- Old gossip topic naming (`kels/gossip/*` → `vdti/witness/*`).
- Kels' `kels` + `sadstore` service shapes — **vdti merges both into `vdtid`** (one daemon over `lib/vdti`; the SAD store co-locates with the chain-log to avoid a per-SAD hop). `witnessd` is the separate gossip/witness daemon.
- **Policy in the chain primitives** (the reshape moved policy up to the document layer; KEL/IEL/SEL carry no policy — no `policyPin`, no IEL `PoliciesSet`, no `dev`/`grp`).
- Per-node Contested state (kels#214 removed).
- Federation-layer "contested" terminology → **disputed** in vdti (kels#214 used "irreconcilable").
- `is_contested` accessor (kels#207–209 removed).
- Upgrade rule (kels#214 removed).
- Static `TRUSTED_REGISTRY_PREFIXES` (replaced with the config-pinned federation IEL trusted set).
- `cesr-rs` external dependency (absorbed into vdti `encoding/`).

## Conventions

- Open issues from kels referenced as `kels#N` to distinguish from vdti's own issue numbers (to be assigned as items get filed).
- Order within phases is suggested but movable.
- Tracker references (kels#140, kels#159, kels#160, kels#161, kels#163, kels#164, kels#165, kels#190, kels#191) point at kels tracker issues for design rationale.
- Items not yet broken into vdti-specific issues live here as the authoritative roadmap until filed.
