# VDTI v1 Roadmap

## Current state (2026-07-10)

The **design is well ahead of the build** (no vdti runtime code yet). The design has been through a full
redesign: the **first-seen pivot** (a two-tier KEL — signing key + rotation reserve, no recovery key, no repair
event; recovery is a plain rotation; divergence reads _forked_ vs _disputed_), **fail-secure revocation** (a
`kills[]` declaration on the issuer's witnessed IEL; a credential is a direct-anchored SAD, no issuance log),
and a **layering principle** (the chain validates structure only; the feature layer owns topic meaning). It is
captured and pressure-tested in the machine-oriented canon (`docs/canon/`, 14 files), which is **committed and
whole-canon ship-reviewed** (2026-07-10). Read order: `.working/00-INDEX.md`; the human model is `MODEL.md`
(repo root).

**Leading edge — phase-2: reconcile the landed `docs/design/` docs to the ship-reviewed canon**, one concept
per PR in build order (dual-pass reviewed each).

- **Current PR** — the KEL primitive + `event-shape.md` + the other landed foundational docs
  (`protocol-doctrine` / `glossary` / `system-thesis` / the SAD layer / `policy`), reconciled to first-seen +
  fail-secure + layering.
- **Then, in build order** — IEL (write `iel/` fresh), SEL (write `sel/` fresh), policy/documents (credentials
  + revocation), federation (`witnessing.md`), the services/architecture doc, and the multi-party-documents
  feature.
- **Pinned at the encode** — the witness-selection and effective-SAID-synthetic byte formats (cross-node
  protocol constants), the policy-DSL composer mechanics, and a worked counter-example for the credential
  earliest-anchor floor.

_(**Prior design arcs — superseded, archived.** The road here, newest-first: the **first-seen pivot** +
**fail-secure rework** (the current canon); the **effective-SAID convergence** model; **content-fork prevention**
(the majority floor); the **federation / witnessing remodel** (`Fed`→`Wit`, the `Fcp` marker); the **SEL +
delegation** model + the **multi-party-documents** feature; the **KEL primitive** (vdti#10 / PR #11); the
**keep-all-data divergence** model; and the **document/policy layer** doctrine-land (vdti#12 / #13, merged to
`main`). Round-by-round detail lives in `.working/archived/` + `.working/00-INDEX.md`; the current design is
`docs/canon/`.)_

## Mission

**VDTI** — Verifiable Decentralized Trust Infrastructure.

- Users control their identity and data without relying on a central authority.
- Devices are decoupled from the identity that operates them.
- Identity and policy are first-class, composable primitives.
- Any verifier determines system-wide state — including attack exposure — by inspecting data from a single source.
- Contrast with KERI (Decentralized Key Management Infrastructure): system-wide state inference there requires out-of-band watcher infrastructure.
- A framework for building high-trust applications from the ground up.

## Audience

General-purpose. Any application requiring identity composes naturally on VDTI's primitives.

Three attestation modes drive most credential flows:

- **Property attestation** (you own X) — tickets, passes, goods-in-transit.
- **Identity attestation** (you are X) — age verification, travel, hiring.
- **Capability / certification attestation** (you've been verified to have X) — background checks, education, training, health records.

Adoption catalyst:

- Government issuing a foundational credential (digital passport / national ID equivalent).
- Once that exists, downstream issuers, IDV providers, and applications can compose on it.

Anchor use cases:

- **Government adoption** — acceptance-driven; no protocol-side monetization concern.
- **IDV / background-check / credential-issuance partnerships** — commercial; protocol stays open, revenue lives in apps + services + insurance built atop.

## Relationship to KERI / WebOfTrust

- Independent + technically comparable.
- Separate protocol, separate ecosystem.
- Encoding primitives absorbed into vdti (from kels' custom implementation) as the `encoding/` package; no upstream `cesr-rs` dependency.
- No wire compat with KERI verifiers.
- No upstream-contribution commitment.
- `docs/reference/keri-comparison.md` frames KERI as a peer / alternative approach to similar problems.

## License

- MIT, OSS.
- License file already in place in the repo.

## Repo layout

> ⚠ **Service shape updated for the reshape:** it's **`vdtid`** (chain-log **+** SAD store merged — events
> reference SADs by SAID, so a separate store is a per-SAD hop, several per request) **+** **`witnessd`** (the
> gossip / sync / witness daemon) — **not** the old `eventsd`/`sadd` split. And **policy lives up at the document
> layer**, not in the primitives. See `docs/canon/vdti-area-vdtid-services.md`.

```
vdti/
  lib/
    encoding/                # vdti-encoding (absorbed from ../cesr-rs)
    storage/                 # vdti-storage (absorbed from ../verifiable-storage-rs; itself a workspace)
    cache/                   # vdti-cache (absorbed from ../cacheable)
    vdti/                    # vdti — protocol primitives (KEL/IEL/SEL) + verifier/merge/transfer engine + SAD store + gossip
    mail/                    # vdti-mail (application shim)
    exchange/                # vdti-exchange (application shim)
    creds/                   # vdti-creds (application shim)
    derive/                  # vdti-derive (KEL signed-events repo derive macros; KEL only — IEL/SEL anchor in KEL)
    ffi/                     # vdti-ffi (Rust → C bindings)
  services/
    vdtid/                   # thin binary over lib/vdti; chain-log + SAD store (postgres + object store); submit/merge
    witnessd/                # gossip / sync / witness daemon (anti-entropy, deferred-deps park, receipts; HSM consumer lib)
  cli/
    vdti/                    # CLI binary
  infrastructure/
    objects/                 # SeaweedFS deploy config
    database/                # postgres deploy config
    kvstore/                 # redis deploy config
    mock-hsm/                # HSM service + consumer lib (production HSM abstraction)
  examples/
    messaging/               # iOS/Android demo (ports current kels iOS app + adds messaging)
  docs/
    design/
    reference/
    operations/
    analysis/
  tests/
    bench/                   # benchmarks (SAD / IEL / SEL load testing)
    # plus e2e suite (port of kels clients/test/) under tests/
  AGENTS.md
  README.md
  LICENSE
```

**Conventions:**

- Library directories use short names (no `vdti-` prefix); Cargo.toml package names use the `vdti-` prefix for crates.io publishing.
- Service daemons use `d` suffix (`vdtid`, `witnessd`) — Unix daemon convention.
- CLI binary is `vdti` — what users type.
- Absorbed libraries (`lib/encoding/`, `lib/storage/`, `lib/cache/`) live under `lib/` alongside vdti-native libs. The absorbed-vs-native distinction lives in commit history and crate metadata, not directory layout.
- `lib/vdti/` is the protocol core: KEL / IEL / SEL primitives, the verifier / merge / transfer engine, the SAD store + custody, and gossip — **linked by both `vdtid` and consumers** (end-verifiability: a consumer verifies the data itself with the same library, trusting the data not the daemon). `mail/` / `exchange/` / `creds/` are application shims that depend on `vdti`; **policy is the document layer**, not a primitive.
- **`vdtid` merges the chain-log and the SAD store** into one daemon (kels split `kels`/`sadstore` ad hoc; now that events reference SADs by SAID, a separate store is an extra hop per SAD — several per request). `witnessd` is the separate gossip / sync / witness daemon (kels' `gossip` service, renamed).
- IEL and SEL events anchor in KEL events; they do not carry direct signatures. `lib/derive/` (`vdti-derive`) generates signed-event-repo macros for KEL only. IEL / SEL repos use `storage/`'s `Stored` / `Chained` primitives directly.
- `infrastructure/mock-hsm/` is a service that builds a consumer lib. Services needing signing keys (e.g. `witnessd`) import the consumer lib to talk to the HSM service. Same architecture in production — swap the HSM implementation behind the lib without touching service code.
- Garden orchestrates infra + services; `tests/` contains the e2e scenario suite (port of kels `clients/test/`); benchmarks live under `tests/bench/`.

## Operational decisions

Resolved during planning; recorded here as the operational baseline.

- **Auth model for SAD writes (`vdtid`)** — operator-configurable. Default: open + rate-limits always-on. Lockdown via vdti's own creds + document policy (specify required credential/policy for writes). Self-bootstrapping — vdti is its own auth substrate.
- **Configuration** — env vars only (kels precedent). Trusted federation IEL prefix is compile-time-baked + runtime env-var override.
- **Branching / release** — main + feature branches; semver from day one; tagged releases.
- **CI/CD** — GitHub Actions; 6-job shape (fmt, lint-terminology, deny, clippy, test, build). No git hooks (CI gates only). No coverage tracking at start; deferred to Phase 9 if/when an e2e-aware setup is worth building.
- **Audit trail** — multi-agent audit reviews from day one, with outputs in `.working/` (gitignored). `CHANGELOG.md` committed to repo as the public record.
- **Item filing** — lazy. Items filed as vdti issues when picked up; the roadmap is the authoritative pre-filing source.
- **Backlog organization** — tracker-style meta-issues for cross-cutting themes.
- **Contributor on-ramp** — `README.md` + `AGENTS.md` + `docs/`. Plus 4 issue templates (`doctrine`, `implementation`, `bug`, `tracker`) and a PR template. All produced in Phase 0.
- **Demo / pilot timeline** — no partner commitments; pure protocol-correctness ship.
- **License** — MIT throughout the repo, including `examples/messaging/`.

## v1 scope and phases

v1 ships when:

- E2E suite passes against vdti.
- Messaging-app example in `examples/messaging/` runs end-to-end on iOS.
- Federation bootstrap from clean state is documented + reproducible.

> ⚠ **The per-phase *design* specifics below predate the 2026-06 log-primitive reshape** (e.g. IEL `PoliciesSet` /
> 7-kind IEL, `Sea`/`Est` kinds, the federation self-attestation carve-out, policy-in-primitives). The
> current design is the `vdti-area-*.md` notes; the phases here are kept for **build *sequencing***, not current
> design detail — reconcile per-phase specifics from the area notes at land/build time. Phase 0 (design) is
> effectively the completed area-note design pass + the doctrine-land step (see Current state).

### Phase 0 — Design completion (docs + scaffolding, no code)

- Empty repo populated with a complete, audited doctrine before any code lands.
- The area-by-area design pass (`.working/vdti-area-*.md` + `vdti-invariants.md`) is the completed design; Phase 0 closes by **landing it into `docs/design/`** (the doctrine-land step) + the repo scaffolding below.

**Design-doc build order (dependency layering).** The design docs build in dependency layers; getting the order right is what keeps the build understandable (the goal — isolation is only a means):

`sad` → `event-shape` (shared chain/event structure) → `kel`/`iel`/`sel` primitives → `policy`/document layer (authorization language, on top of the primitives) → features (`creds`, `multi-party documents`, `mail`, `exchange`).

- **`event-shape.md` is the lynchpin.** Every chain primitive shares it. Post-reshape it needs the rewrite catalogued in the area notes (drop `policyPin` / `dev` / governance policy-kinds; `Rpr`→`Rec` on KEL; `federationBinding` → `federation`/`federationPin`; witness-config SAD).
- **The policy↔primitive dependency is inverted via verification tokens:** the document/policy layer *declares* the verification interface it consumes (what a verified chain token exposes — roster/threshold as-of, delegation chain, anchored SAIDs); the chain primitives *implement* it (their concrete `*Verification` tokens). Policy sits **above** the primitives and consumes their tokens; the primitives carry no policy.
- **Features are clean leaves.** `creds` (and later `multi-party documents` / `mail` / `exchange`) compose the document layer + primitives, depend only on landed interfaces — one PR each, no cycle. A credential is a **per-cred SEL** (data referencing identity, not an IEL/SEL/KEL kind); issuance = its `Icp`, revocation = its `Trm`. See `docs/canon/vdti-area-document-policy.md`. A **multi-party document** (collaborative + evolving — a shared spreadsheet) is a *separate* feature over SEL + SAD: a **V0** constitution + a **creator-governed, per-period access list** (`editors`/`commenters` via `Gnt`←`Ath` grants) + one version SEL per editor + a multi-parent **version DAG**; policy-free except `readPolicy`; **not** subsumed into creds (a co-author is not an issuer). See `docs/canon/vdti-area-multi-party-documents.md`.

**Repo scaffolding:**

- `README.md`, `AGENTS.md`, `CHANGELOG.md` (stub).
- `.gitignore` (including `.working/`), `.terminology-forbidden` (vdti version).
- `.github/ISSUE_TEMPLATE/{doctrine,implementation,bug,tracker}.md`, `.github/pull_request_template.md`.
- `.github/workflows/ci.yml` (job slots; most fail on empty workspace, unblock as code lands).

**`docs/design/` — land the area-note design (per the doctrine-land step):**

- `system-thesis.md` — system thesis + adversarial-first framing. Canonical orientation; AGENTS.md links + quotes the load-bearing one-liners.
- Per-primitive docs `kel/` · `iel/` · `sel/` written from the area notes; `event-shape.md` + `protocol-doctrine.md` reconciled (strip superseded machinery).
- Federation as an ordinary IEL + the witnessing model (`docs/design/federation/{bootstrap,witnessing}.md`).
- Services/architecture doc (`vdtid` + `witnessd` + `lib/vdti`).
- Greenfield prose (no "previously X" / migration language); every cross-reference reconciled.

**`docs/reference/`** — lookup material: attestation modes (own / be / certified), KERI comparison, endpoints (when services land). Primitive specs live under `docs/design/primitives/`, not here.

**`docs/analysis/`** — attack-surface, scale, deployment, node-attack-surface, protocol-attack-surface.

**`docs/operations/`** — deployment, backup, node retirement, shadow-node patterns.

**Phase 0 acceptance — closing 5-axis audit:**

Single closing-pass audit certifies Phase 0 complete. Five axes:

1. **Security** — adversarial review. What attacks does each doctrine section address? Are arguments structural-soundness based (not invariant-protection based)? Every privileged operation, state transition, and trust boundary evaluated under adversarial input.
2. **Correctness** — internal consistency. Doctrine self-coheres across primitives. Cross-references resolve. Interlocking invariants maintained. Edge cases enumerated.
3. **Completeness** — gap detection. Every primitive, event kind, state, transition, error mode, and operation documented. Matrix docs are exhaustive.
4. **Readability** — prose quality. Clear; technical terms defined on first use; narrative coherent across sections.
5. **Accessibility (newcomer reach)** — someone with security / distributed-systems background lands in `docs/` and builds a mental model without prior kels exposure.

Phase 0 closes when the 5-axis audit produces zero structural findings.

### Phase 1 — Foundations (libraries + infrastructure)

- Bring up repo: README, LICENSE (done), Cargo workspace, CI scaffold (GitHub Actions).
- Garden integration for orchestration.
- `infrastructure/{objects,database,kvstore}/` configs (SeaweedFS, postgres, redis) so `garden up` spins up dev deps.
- Absorb cesr-rs as `lib/encoding/` (vdti-encoding) — port kels' custom encoding implementation.
- Absorb verifiable-storage-rs as `lib/storage/` (vdti-storage).
- Absorb cacheable as `lib/cache/` (vdti-cache).
- Naming convention setup: `vdti/{component}/v1/{category}/{name}` patterns as constants.
- CHANGELOG.md + release scaffold.

### Phase 2 — Core primitives (libraries)

- KEL primitive — taxonomy `Fcp / Icp / Ixn / Rot / Ror / Rec / Wit / Trm` (8 kinds). Three-state per-node machine (Active / Divergent / Terminated). No Cnt; locked-portion bound; divergence scoped to `Ixn`. Whole-content prefix derivation; `federation`/`federationPin` split; witness-config SAD `{threshold, signers}`.
- IEL primitive — taxonomy `Icp / Ixn / Evl / Ath / Rev / Dth / Rpr / Trm / Wit` (9 kinds). **No policy** (policy is the document layer); threshold-vector `{t_use, t_govern, t_authorize, t_recover}`; **`Ath`** authorizes a party (delegation via `delegates`, or a doc-membership grant via `anchors`→SEL `Gnt`); **`Rev`/`Dth`** are the sealed kill-anchors (revoke an owned artifact / deauthorize a grant — no `threshold` slot; each prices from one count); `Ixn` is the divergeable content/SEL-binding kind; federation = an ordinary (restricted) IEL. See `docs/canon/vdti-area-iel.md`.
- SEL primitive — single-owner data log; `Icp` (T1, no body pin) / `Pin` (floor re-pin, `t_use`/T1) / `Ixn` / `Gnt` (doc-membership grant, `t_authorize`/T2, `Ath`-anchored) / `Fld` (re-seal, `t_govern`/T2) / `Trm` (kill: revocation via `Rev`, rescission via `Dth`, carries `bound`) / `Rpr` (7 kinds). `derive(owner, topic, data)` prefix; the `Icp` floors via a serial-1 `Pin`; the SEL re-seals via `Fld`. See `docs/canon/vdti-area-sel.md`.
- The transfer engine (`transfer_*_events`: verify / forward / streaming-with) — one source/sink/verifier-swappable walk.
- Verification tokens: structural-HARD / policy-SOFT, `queried`/`satisfied` SAIDs, `resume`; `policy_satisfied` type-level split (structural-only vs trust-bearing).
- Merge (`merge_events`) — re-verify (or `resume` from a cached token gated by effective-SAID); never trust the DB.

### Phase 3 — Service skeleton (binaries)

- `vdtid` binary: thin wrapper over `lib/vdti`; HTTP server; chain-log via postgres **+** SAD store via the object store (merged — no per-SAD hop); submit/merge handler (advisory lock + txn); typed-422 deferred-deps; effective-SAID computation.
- `witnessd` binary: gossip mesh + anti-entropy loops + the Redis-backed deferred-deps park/drain + receipt production; topics under `vdti/witness/v1/topics/*`.
- Open-write SAD storage with rate-limits; authenticated witness-to-witness comms.

### Phase 4 — Federation witnessing + bootstrap

- Receipt SAD shape (adjacent, `witnessedPrefix`/`Said`/`Serial`).
- Adjacent live/ignored tables keyed by `(prefix, serial)` in the chain log.
- Always-witness rule (reporters, not deciders).
- Threshold-two-events divergence detection with structural event re-verification.
- Deterministic witness selection by `(prefix, serial)`.
- Receipt-announcement topic in `witnessd`: `vdti/witness/v1/topics/receipt`.
- Federation = an ordinary IEL `Icp` (no self-attestation carve-out; config-pinned `FEDERATION_IEL_PREFIX` trust root).
- Federation context inheritance for IEL/SEL (via the KEL anchor's `federationPin`).
- Verification token surface: `witnessed`, `divergent`, `minority_dissent`, `witnessed_anchors`.
- Acceptance gating (currency gate, exact-tip) for non-witnesses; destruction-on-witnessing.
- `Fcp` / `Wit` event mechanics (founder pre-federation; federation declaration / params update / re-binding).
- Bootstrap ceremony (founder `Fcp → Rot` anchoring the federation `Icp`, atomic batch; no founder `Wit`).
- Inter-federation transfer with per-federation (non-transitive) witnessing.

### Phase 5 — Identity binding + federation runtime

- Document-layer `id(X)` resolution (identity-chain resolution via IEL tokens).
- Creds: issuer / issuee as identity prefix; per-cred SELs.
- Federation runtime core (federation IEL handling, bootstrap config, threshold enforcement).
- Lookup-SEL implementation (rescission / address / discovery) + identity DB schema.
- Operator CLI binary: federation membership commands (`Evl` batching), identity admin.
- User-facing references rework (identity, not KEL prefix).
- Bootstrap sync + anti-entropy.

### Phase 6 — Auxiliary primitives

- Multi-party documents (collaborative + evolving): a V0 constitution + a **creator-governed, per-period membership list** (`editors`/`commenters` via `Gnt`←`Ath` grants) + one version SEL per editor + a multi-parent version DAG (`ancestors[]`); `readPolicy` gates reads; owner-rooting check load-bearing. See `docs/canon/vdti-area-multi-party-documents.md`.
- Mail subsystem (envelope as SAD with custody; sender/recipient as identity prefix).
- Exchange + encap keys (chain keyed by identity).
- Custody-aware SAD compaction as first-class primitive.
- SAD reader-side custody verifier surface.
- Endorsement coordination protocol for multi-KEL SAD event anchoring.
- Mail push notifications (WebSocket).
- CascadingSadStore.
- Client-side token store (cache + effective-SAID gate + `resume`).
- `availability.once` single-prefix replica-set match.

### Phase 7 — FFI + mobile bindings

- `vdti-ffi` crate: Rust core compiled with C-compatible API.
- cbindgen headers generation.
- Native wrappers: Swift package for iOS; Kotlin/Java for Android (if Android Keystore APIs ready, else fast-follow).
- Hardware-backed signing custody: Apple Secure Enclave (port from kels' work), Android Keystore.
- Build + distribution pipeline for mobile artifacts.

### Phase 8 — Examples (messaging app)

- Port kels iOS app code into `examples/messaging/`.
- Adapt to new FFI surface (`Fcp`/`Wit` events, config-pinned federation trust set, witnessing verification).
- Add messaging functionality: mail + exchange + encap keys composed into a usable messaging surface.
- iOS app primary target; Android version once mobile bindings exist.
- Preserve all functionality of current kels iOS app (identity ops, key ops, federation ops, creds, custody, etc.) + add messaging.

### Phase 9 — Tooling, ops, docs, e2e

- Port `clients/test/` e2e suite (or vdti equivalent) — every existing test scenario passes against vdti. Adapt for naming (kels → vdti), service consolidation, new event kinds, etc.
- New e2e scenarios: `test-witnessing.sh`, `test-divergence-detection.sh`, `test-inter-federation-transfer.sh`, `test-federation-bootstrap.sh`.
- Rewrites for obsoleted scenarios (e.g., `test-voting.sh` superseded by federation-as-identity).
- Telemetry / observability baseline.
- Benchmark tool (SAD/IEL/SEL load testing).
- Damaged-chain enumeration.
- Operations doc (deployment, backup, node retirement, shadow-node patterns).
- Canonical signed-event-body examples via CLI.
- Deferred-deps HTTP-status threading.
- IEL policy-failure reporting hygiene.
- Pre-resolve policies before submit tx.
- Per-crate docs (`README.md` + `design.md` + `attack-surface.md`).
- Documentation reorg + gap check.
- Federation-as-identity supporting-docs (deployment, scale, node-attack-surface, keri-comparison, protocol-attack-surface).
- KERI comparison: structural divergence detection + inter-federation portability framing.
- AGENTS.md.

## v1 acceptance criteria

v1 ships when:

1. **E2E suite passes**: `make test-all-deployments` (vdti-equivalent) passes against the vdti architecture, with all existing test scenarios ported + new vdti-specific scenarios added.
2. **Messaging-app example runs end-to-end on iOS**: ports kels iOS app surface, demonstrates all current crypto operations, adds working two-user messaging via mail + exchange.
3. **Federation bootstrap from clean state is documented + reproducible**: a CLI command sequence produces a running federation from zero. Documented in `docs/operations/`.
4. **All seven demo scenarios are exercisable** by an external evaluator: fresh federation bootstrap, end-user identity creation, two-user encrypted conversation, credential issuance + verification in conversation, witnessed events with verification, divergence detection (dev-test), inter-federation transfer.
5. **Per-crate docs published**: each lib + service has README + design + attack-surface.
6. **MIT-licensed source publicly accessible** in the vdti repo.

## Post-v1 / backlog

Items not in v1 but tracked for future:

- **Federation bridging**: a vdti deployment belonging to multiple federations for continuous cross-federation sync. Future capability per kels#216.
- **Owner-side KEL monitoring with auto-Rec on detected compromise** (kels#191 tracker).
- **Scale credential issuance** (kels#77 — design exploration only).
- **Apple SE internalization completion** if not fully landed in v1.
- **Self-referential schemas** (`$defs` + Reference variant) (kels#102).
- **SADStore deep existence check via disclosure paths** (kels#116).
- **Client-side dep-graph caching** strategy (kels#162).
- **Service access control** via `AuthorizedPayload<T>` (kels#82).
- **Scale SAD storage beyond 1 replica** (possibly subsumed by SeaweedFS).

## What's NOT carrying forward

Obsoleted by the post-kels#214 / post-kels#216 / post-kels#218 design + the vdti log-primitive reshape; vdti starts without these:

- Registry (kels#190 + kels#197 removed; vdti has no registry concept — a cred is its own per-cred SEL).
- Old gossip topic naming (`kels/gossip/*` → `vdti/witness/*`).
- Kels' `kels` + `sadstore` service shapes — **vdti merges both into `vdtid`** (one daemon over `lib/vdti`; the SAD store co-locates with the chain-log to avoid a per-SAD hop). `witnessd` is the separate gossip/witness daemon.
- **Policy in the chain primitives** (the reshape moved policy up to the document layer; KEL/IEL/SEL carry no policy — no `policyPin`, no IEL `PoliciesSet`, no `dev`/`grp`).
- Per-node Contested state (kels#214 removed).
- Federation-layer "contested" terminology → **disputed** in vdti (kels#214 used "irreconcilable").
- `is_contested` accessor (kels#207–209 removed).
- Upgrade rule (kels#214 removed).
- Static `TRUSTED_REGISTRY_PREFIXES` (replaced with the config-pinned federation IEL trusted set).
- `cesr-rs` external dependency (absorbed into vdti `encoding/`).

## Conventions

- Open issues from kels referenced as `kels#N` to distinguish from vdti's own issue numbers (to be assigned as items get filed).
- Order within phases is suggested but movable.
- Tracker references (kels#140, kels#159, kels#160, kels#161, kels#163, kels#164, kels#165, kels#190, kels#191) point at kels tracker issues for design rationale.
- Items not yet broken into vdti-specific issues live here as the authoritative roadmap until filed.
