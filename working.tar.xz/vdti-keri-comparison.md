# VDTI vs KERI — where we converged, where we differ, what to validate

**Status: DISCUSSION CAPTURE (2026-07-06).** Many claims are marked **[TO VALIDATE]** — my KERI
knowledge is **design-level** (KEL, witnesses, receipts, first-seen duplicity, ACDC, delegated +
group AIDs, weighted multi-sig, rotation/recovery), **not** deeply checked against keripy or the
whitepapers. Validate before banking any comparative claim. Reference impl: keripy at
`/Users/jason/github.com/WebOfTrust/keripy`.

## The honest starting point: the backbone is KERI

After a month of subtracting complexity — the repair-completeness proof, root-condemnation, the T3
reserve, explicit archival, all deleted in favor of **burying + the spine** — VDTI's core has
converged on KERI's proven model:

- a hash-chained key event log,
- witnesses giving receipts,
- first-seen duplicity detection,
- recovery by superseding rotation.

This is a **good** outcome, not a failure. That core is the minimal correct design for decentralized
key management; you land on it by subtracting, not by accident. The failure mode would have been
keeping the NIH machinery as false differentiation. So: **take the backbone as-is; differentiate
above it.**

## Where VDTI genuinely differs (and how sure we are)

### 1. The KEL/IEL split — identity is a threshold over device KELs

- **VDTI:** KEL = one device's key lifecycle (single locus). IEL = the identity, a threshold over
  member KELs. SEL = per-owner data logs.
- **KERI:** the identifier (AID) *is* the KEL; multi-sig and delegation are properties of that one log.
- **Claim:** separating the device axis (KEL) from the governance axis (IEL) is cleaner — a device
  rotating doesn't entangle identity governance, and the threshold is first-class and separate. The
  strongest form: **one reusable "threshold over KELs" primitive, used for BOTH identities and the
  federation** (below).
- **[TO VALIDATE]:** KERI has **weighted multi-sig, delegated AIDs, and group AIDs** that overlap the
  IEL's ground. Confirm the IEL is a structural improvement, not a rename of KERI delegation/group
  identifiers — and that KERI doesn't already unify identity + witness-pool the way the IEL does.

### 2. Federation as a restricted IEL → witnessing-as-a-service — **THE BIG CLAIM**

- **VDTI:** the federation is a restricted IEL — a governed, rotating, evictable threshold over
  witness KELs — with structural safety floors (roster ≥ 4, signers ≥ 3, majority, availability). A
  user binds to a federation and *consumes* witnessing; they never run witnesses.
- **Adoption thesis:** KERI's wall is that "be witnessed" and "run witnesses" are the same act, so
  every user needs infrastructure and the skill to run it — which is why it's stuck at expert/
  enterprise. VDTI splits them: **witnessing becomes a service run by trusted operators.**
- **Safety property (the non-obvious part):** you offload **operation, not trust**. End-verifiability
  keeps trust with your keys (an operator can't forge you — they never hold your keys); `< threshold`
  byzantine members are bounded and attributably evicted; the **floors make a malformed federation
  unhonored by the verifier**, so a non-expert can trust an operator *without auditing it*. That last
  point is why this session's byzantine/floor work is the adoption foundation, not just correctness
  hygiene.
- **[TO VALIDATE — the most important check, because it's the pitch]:** KERI witnesses **can already
  be run by third parties**, so "offload witnessing to operators" is not obviously novel. VDTI's
  actual contribution appears to be the **governance + trust-bounding around the witness pool** (the
  federation-as-IEL: rotation, eviction, the clock, the floors) that makes it *consumer-safe by
  construction*. **Confirm KERI lacks an equivalent governed, trust-bounded, first-class witness-pool
  primitive.** If KERI already enables a safe managed-witness service, the "huge win" is a
  better-formalized version of something KERI enables, not a new capability.

### 3. `said != prefix` (two-hash derivation)

- **VDTI:** an inception event's SAID ≠ its prefix (two separate hashes), so logging event SAIDs
  doesn't leak the prefix — correlation resistance.
- **[TO VALIDATE]:** check KERI's AID/SAID self-addressing derivation — whether a KERI AID has the
  same correlation exposure (coupling the inception SAID to the identifier) or already separates them.
  Real gap if coupled; parity if not.

### 4. Forked / Disputed formalization + effective-SAID — a formalization, not a new capability

- **VDTI:** an explicit Forked/Disputed state machine + effective-SAID synthetics (a queryable
  divergence state).
- **Honest read:** KERI already has **duplicity detection**; this is a cleaner *formalization* of the
  same concept, not a new capability. Modest differentiator. **[TO VALIDATE]** whether the
  queryable/synthetic-SAID framing offers anything KERI's duplicity handling doesn't.

### 5. Policy on documents + the SEL shape

- **VDTI:** a formalized policy layer on documents; SEL = structured per-owner data logs.
- **[TO VALIDATE]:** compare against **ACDC** (rules, edges, schema, graph) — whether VDTI's policy
  layer is a genuine gap or a different expression of what ACDC already does.

## Direct mode is a bad idea — two independent reasons

- **Technical (established):** an un-federated `Icp` forces the merge engine to handle multi-branch /
  retroactive-recovery cases it can't cleanly bound. Subtract the case, keep the guarantees.
- **Product (this discussion):** direct mode = "run your own witnessing / no federation" = *exactly*
  the KERI adoption problem. It reintroduces the burden the federation model exists to remove, so it
  contradicts the entire value proposition.

Both point the same way: forbid un-federated inception; every chain federated + witnessed from birth
(the `Fcp`-rooted infra is the substrate exception). **DECIDED (2026-07-07): direct mode is removed** —
every identity is federation-witnessed (reconciliation ledger §6).

## The defensible position

Take KERI's verifiable core as-is. Differentiate on **the KEL/IEL split** (one "threshold over KELs"
primitive, reused for identities and the federation) and **witnessing-as-a-service** (operators run
the witnesses; users keep their keys and end-verifiable data). *If* the [TO VALIDATE] items hold —
especially #2 — the pitch is **"KERI's proven backbone, with the operational burden lifted onto
operators who can't betray you,"** which is a stronger position than "a new protocol."

## Validation checklist (do against keripy / KERI + ACDC specs)

- [ ] IEL vs KERI delegated + group AIDs / weighted multi-sig — genuine structural gap? (#1)
- [ ] **Managed/third-party witnesses in KERI — is a governed, trust-bounded witness-pool service
      already possible?** (#2 — the pitch depends on this)
- [ ] KERI AID/SAID derivation — same prefix-correlation exposure, or already separated? (#3)
- [ ] Duplicity handling in KERI vs the Forked/Disputed + effective-SAID framing (#4)
- [ ] ACDC rules/edges vs the document-policy layer (#5)

## First-seen model — verify-against-keripy checklist (2026-07-07)

Added after the first-seen pivot + two-tier collapse this session. The VDTI side is framed from the
now-captured model (`vdti-model-plain-english.md` / `vdti-event-kinds.md` / `vdti-adversary-cases.md`);
the KERI answers need the keripy scan. **Questions, not claims** — don't bank the KERI side from memory.

- [ ] **First-seen, exact semantics.** We adopted per-witness first-seen (a witness signs the *first*
      event it sees at a position, *per tier*, and refuses later same-tier copies). Confirm KERI's
      first-seen is the same per-witness rule, and whether KERI has our **cross-tier co-sign**
      (`{≤1 content, ≤N privileged}` at one serial) or treats a position as strictly one-event.
- [ ] **Two tiers / no recovery key.** We collapsed to T1 (signing) / T2 (rotation) and **dropped the
      recovery key** — recovery is a plain rotation. Does KERI have a distinct recovery reserve beyond
      pre-rotation, or is pre-rotation its only reserve? (No recovery key ⇒ convergence; a recovery key
      ⇒ we diverged deliberately.)
- [ ] **Recovery = root-bury vs KERI superseding rotation.** We recover by rotating at the *first*
      compromised position (the whole run below dies by descent). Is KERI's superseding-recovery the same
      "attach at the root, deadness-descends" mechanic, or does it attach/supersede differently?
- [ ] **Disputed/forked outcome, not just detection.** KERI *detects* duplicity; we now formalize the
      **outcome** (content fork → recoverable/buried; key-change fork → terminal/reincept) plus the
      **observable-breach guarantee** (fork-cost = forced attributable double-signers). Does KERI
      formalize the terminal-vs-recoverable outcome, or stop at "duplicity detected, handle out-of-band"?
      (Sharpens checklist #4.)
- [ ] **SEL vs TEL/registry.** Our per-artifact SEL rides its owner IEL (the IEL is its clock). Map to
      KERI's **TEL** (transaction event log / credential registry) — same "data log anchored to a KEL"
      shape, or different? (Extends #5 from ACDC to the *log* layer.)
- [ ] **Witness/governance bounds.** We added a **roster cap (32)**, a **majority floor on governance**
      (`t_govern`/`t_authorize > |roster|/2`), and the **witness majority floor** (`threshold >
      signers/2`, fork-cost = `2·threshold − signers`). Does KERI constrain its witness threshold
      (`toad`) with a majority/attribution requirement, or leave it unconstrained? (Feeds #2 — the
      federation pitch rests on these being a real governance layer KERI lacks.)
- [ ] **Freshness + witness-sig monotonicity.** Our dormant-forgery defense: receipts must march forward
      in time, so a harvested *retired* witness key can't forge onto an active chain. Does KERI defend the
      harvested-old-witness-key attack, and how?
